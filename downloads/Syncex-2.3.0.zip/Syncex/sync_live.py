"""Experimental task-scoped live import. Never replaces an open SQLite database."""
import contextlib
import ctypes
from ctypes import wintypes
from datetime import datetime
import hashlib
import json
import os
from pathlib import Path
import shutil
import sqlite3
import threading
import uuid
import handoff as h
import history_chain as chain

RUNS = h.ROOT / 'live-sync'
FIELDS = ('title', 'name', 'updated_at', 'archived', 'is_pinned', 'thread_section_id',
          'model', 'reasoning_effort')


class Deferred(h.HandoffError):
    pass


def direction(source_profile, target_profile):
    if source_profile not in h.PROFILES or target_profile not in h.PROFILES or source_profile == target_profile:
        raise h.HandoffError('Choose two different configured profiles.')
    return h.PROFILES[source_profile], h.PROFILES[target_profile]


def home_path(home, value):
    path = Path(str(value).removeprefix('\\\\?\\')).resolve()
    if not path.is_relative_to(home.resolve()):
        raise h.HandoffError('A transcript points outside its profile.')
    return path


def rows_hash(rows):
    values = sorted(json.dumps(row, sort_keys=True, ensure_ascii=False) for row in rows)
    return hashlib.sha256('\n'.join(values).encode()).hexdigest()


@contextlib.contextmanager
def exclusive_file(path):
    """Windows share-mode lock excludes app readers/writers for the whole operation."""
    import msvcrt
    k = ctypes.WinDLL('kernel32', use_last_error=True)
    k.CreateFileW.argtypes = [wintypes.LPCWSTR, wintypes.DWORD, wintypes.DWORD,
                             ctypes.c_void_p, wintypes.DWORD, wintypes.DWORD, wintypes.HANDLE]
    k.CreateFileW.restype = wintypes.HANDLE
    k.CloseHandle.argtypes = [wintypes.HANDLE]
    path.parent.mkdir(parents=True, exist_ok=True)
    existed = path.exists()
    handle = k.CreateFileW(str(path), 0xC0000000, 0, None, 3 if existed else 1, 0x80, None)
    if handle == ctypes.c_void_p(-1).value:
        error = ctypes.get_last_error()
        if error in (32, 33, 80, 183):
            raise Deferred('The receiving app has this history file open or it changed during preparation. Retry after the receiving app exits.')
        raise OSError(error, 'Cannot lock the receiving history file', str(path))
    try:
        fd = msvcrt.open_osfhandle(handle, os.O_RDWR | os.O_BINARY)
    except BaseException:
        k.CloseHandle(handle)
        raise
    with os.fdopen(fd, 'r+b') as stream:
        yield stream, existed


def stream_hash(stream):
    stream.seek(0)
    value = hashlib.file_digest(stream, 'sha256').hexdigest()
    stream.seek(0)
    return value


def replace_stream(stream, source):
    stream.seek(0)
    with source.open('rb') as src:
        shutil.copyfileobj(src, stream)
    stream.truncate()
    stream.flush()
    os.fsync(stream.fileno())


@contextlib.contextmanager
def target_db(target_profile='Secondary'):
    home = h.PROFILES[target_profile]
    conn = sqlite3.connect((home / 'state_5.sqlite').as_uri() + '?mode=rw', uri=True, timeout=3)
    conn.row_factory = sqlite3.Row
    try:
        conn.execute('ATTACH DATABASE ? AS history_db', ((home / 'thread_history_1.sqlite').as_uri() + '?mode=rw',))
        conn.execute('ATTACH DATABASE ? AS catalog_db', ((home / 'sqlite' / 'codex-dev.db').as_uri() + '?mode=rw',))
        conn.execute('PRAGMA foreign_keys=ON')
        yield conn
    finally:
        conn.close()


def capture(conn, ids, history_ids=None):
    marks = ','.join('?' for _ in ids)
    result = {}
    for table in h.STATE_TABLES:
        if table in ('thread_sections', 'projects', 'project_roots', 'project_idempotency_keys'):
            result[table] = h.table_rows(conn, table)
        elif table == 'thread_spawn_edges':
            result[table] = h.table_rows(conn, table, f'parent_thread_id IN ({marks}) OR child_thread_id IN ({marks})', ids + ids)
        else:
            key = 'id' if table == 'threads' else 'thread_id'
            result[table] = h.table_rows(conn, table, f'{key} IN ({marks})', ids)
    history_ids = history_ids or ids
    history_marks = ','.join('?' for _ in history_ids)
    for table in h.HISTORY_TABLES:
        result[table] = h.table_rows(conn, 'history_db.' + table, f'thread_id IN ({history_marks})', history_ids)
    result['catalog'] = h.table_rows(conn, 'catalog_db.local_thread_catalog', f"host_id='local' AND thread_id IN ({marks})", ids)
    return result


def write_rows(conn, tables, ids, catalog, restore=False, history_ids=None):
    marks = ','.join('?' for _ in ids)
    for table in ('thread_dynamic_tools', 'thread_artifacts'):
        conn.execute('DELETE FROM ' + table + f' WHERE thread_id IN ({marks})', ids)
    conn.execute(f'DELETE FROM thread_spawn_edges WHERE parent_thread_id IN ({marks}) OR child_thread_id IN ({marks})', ids + ids)
    history_ids = history_ids or ids
    history_marks = ','.join('?' for _ in history_ids)
    for table in h.HISTORY_TABLES:
        conn.execute('DELETE FROM history_db.' + table + f' WHERE thread_id IN ({history_marks})', history_ids)
    if restore:
        conn.execute('DELETE FROM threads WHERE id IN (' + marks + ')', ids)
    for table in h.STATE_TABLES:
        h.insert_rows(conn, 'main', table, tables[table], replace=table not in ('thread_sections', 'projects', 'project_roots', 'project_idempotency_keys'))
    for table in h.HISTORY_TABLES:
        h.insert_rows(conn, 'history_db', table, tables[table])
    conn.execute(f"DELETE FROM catalog_db.local_thread_catalog WHERE host_id='local' AND thread_id IN ({marks})", ids)
    h.insert_rows(conn, 'catalog_db', 'local_thread_catalog', catalog, replace=True)
    if catalog:
        conn.execute("UPDATE catalog_db.local_thread_catalog_sync_state SET observation_sequence=MAX(observation_sequence,?) WHERE host_id='local'", (max(row['observation_sequence'] for row in catalog),))
    conn.execute('UPDATE catalog_db.local_thread_catalog_metadata SET catalog_revision=catalog_revision+1 WHERE id=1')
    conn.execute("UPDATE catalog_db.local_thread_catalog_sync_state SET last_full_reconciled_at=0 WHERE host_id='local'")
    for db in ('main', 'history_db', 'catalog_db'):
        if conn.execute('PRAGMA ' + db + '.foreign_key_check').fetchall():
            raise h.HandoffError('Imported history failed a database reference check.')


def make_catalog(conn, tables):
    columns = list(conn.execute('PRAGMA catalog_db.table_info(local_thread_catalog)'))
    defaults = {col[1]: conn.execute('SELECT ' + col[4]).fetchone()[0] if col[4] is not None else None for col in columns}
    result = []
    for row in tables['threads']:
        if row['source'] == 'vscode' and not row['archived']:
            item = dict(defaults)
            item.update(host_id='local', thread_id=row['id'], display_title=row.get('name') or row['title'],
                        source_created_at=row['created_at'], source_updated_at=row['updated_at'],
                        cwd=str(row['cwd']).removeprefix('\\\\?\\'), source_kind=row['source'], model_provider=row['model_provider'],
                        git_branch=row['git_branch'], observation_sequence=conn.execute("SELECT observation_sequence+1 FROM catalog_db.local_thread_catalog_sync_state WHERE host_id='local'").fetchone()[0], missing_candidate=0,
                        thread_source=row['thread_source'], source_recency_at=row['recency_at'],
                        project_id=row['project_id'], conversation_origin=None)
            result.append(item)
    return result


def import_snapshot(info, progress=lambda value: None, target_profile='Secondary', guard=None):
    _, home = direction(info['source'], target_profile)
    run = RUNS / (datetime.now().strftime('%Y%m%d-%H%M%S') + '-' + uuid.uuid4().hex[:8])
    run.mkdir(parents=True)
    paths, locks, created, journal = {}, {}, [], None
    committed = False
    with h.scratch() as stage, contextlib.ExitStack() as stack:
        manifest = chain.load_package(info, stage)
        if Path(manifest['source_home']).resolve() != h.PROFILES[info['source']].resolve():
            raise h.HandoffError('The snapshot belongs to a different source profile directory.')
        ids = [row['id'] for row in manifest['tables']['threads']]
        history_ids = manifest.get('history_ids', ids)
        if guard:
            guard.check_source(manifest)
        with h.read_db(home / 'state_5.sqlite') as state:
            old_rows = {r['id']: dict(r) for r in state.execute('SELECT * FROM threads')}
            for table in h.STATE_TABLES:
                if [list(x) for x in h.signature(state, table)] != manifest['schema'][table]:
                    raise h.HandoffError('App database schemas differ; update both apps first.')
        try:
            for item in manifest['files']:
                rel = item['relative_path']
                dest = home_path(home, home / rel)
                # Only the active rollout replaces the visible task's pointer.
                # Ancestral files use independent storage IDs and their own paths.
                owner = item.get('owner_thread_id', item['thread_id'])
                prior_row = old_rows.get(owner) if item.get('active', True) else None
                prior = home_path(home, prior_row['rollout_path']) if prior_row else dest
                expected = {str(path): paths[str(path)]['before_sha256'] if str(path) in locks
                            else h.digest(path) if path.exists() else None for path in (prior, dest)}
                if prior_row and prior.exists():
                    terminal = h.tail_status(prior)
                    if terminal and terminal[0] == 'task_started':
                        raise Deferred(f'This task is running in {target_profile}. Finish or stop its reply, then retry.')
                    reviewed_choice = guard is not None and guard.allow_branch_replacement
                    if not reviewed_choice and prior_row and h.prefix_relation(stage / rel, prior) == 'extends':
                        raise Deferred(f'{target_profile} already has a newer extended transcript; it was preserved.')
                    incoming = next(row for row in manifest['tables']['threads'] if row['id'] == owner)
                    if not reviewed_choice and prior_row and prior_row['updated_at'] > incoming['updated_at'] and h.prefix_relation(prior, stage / rel) != 'extends':
                        raise Deferred(f'{target_profile} has a newer task; it was preserved.')
                for path in (prior, dest):
                    key = str(path)
                    if key in locks:
                        continue
                    stream, existed = stack.enter_context(exclusive_file(path))
                    locks[key] = stream
                    if not existed:
                        created.append(path)
                    backup = run / 'before-files' / path.relative_to(home.resolve())
                    if existed:
                        backup.parent.mkdir(parents=True, exist_ok=True)
                        with backup.open('wb') as out:
                            stream.seek(0)
                            shutil.copyfileobj(stream, out)
                        before_hash = stream_hash(stream)
                        if h.digest(backup) != before_hash:
                            raise Deferred(f'{target_profile} history changed while backing it up.')
                    else:
                        before_hash = None
                    if before_hash != expected[key]:
                        raise Deferred(f'{target_profile} changed this transcript during preparation. Retry the import.')
                    paths[key] = {'path': key, 'backup': str(backup) if existed else None,
                                  'before_sha256': before_hash, 'after_sha256': before_hash}
                    if guard:
                        guard.check_file(path, before_hash, backup if existed else None, stage / rel if path == dest else None)
                paths[str(dest)]['after_sha256'] = item['sha256']
                item['target'] = str(dest)
            # Also hold unchanged receiving ancestors while checking the plan.
            # A retry can otherwise change a linked file outside the incoming set.
            if guard:
                for path, expected_hash in guard.target_files.items():
                    path = home_path(home, path)
                    if str(path) in locks:
                        continue
                    stream, existed = stack.enter_context(exclusive_file(path))
                    if not existed:
                        created.append(path)
                    if not existed or stream_hash(stream) != expected_hash:
                        raise Deferred('Receiving history changed after comparison; retry sync.')
            # The history projection must describe the exact captured transcript.
            sizes = {item['thread_id']: item['size'] for item in manifest['files']}
            for row in manifest['tables']['thread_history_projection_state']:
                if row['next_rollout_byte_offset'] != sizes[row['thread_id']]:
                    raise Deferred('Source history is still being saved or its transcript/index disagree. No live import was made.')
            for row in manifest['tables']['threads']:
                row['rollout_path'] = next(item['target'] for item in manifest['files']
                                           if item.get('owner_thread_id', item['thread_id']) == row['id'] and item.get('active', True))
            progress('Importing ' + ' '.join(info['title'].split())[:70] + '…')
            with target_db(target_profile) as conn:
                conn.execute('BEGIN IMMEDIATE')
                try:
                    before = capture(conn, ids, history_ids)
                    if guard:
                        guard.check_target(conn, before)
                    current_rows = {row['id']: row for row in before['threads']}
                    if any(current_rows.get(tid) != old_rows.get(tid) for tid in ids):
                        raise Deferred(f'{target_profile} changed this task during preparation. Retry the import.')
                    for table in h.HISTORY_TABLES:
                        sig = [(r[1], r[2], r[3], r[5]) for r in conn.execute('PRAGMA history_db.table_info(' + table + ')')]
                        if [list(x) for x in sig] != manifest['schema'][table]:
                            raise h.HandoffError('History database schemas differ.')
                    catalog = make_catalog(conn, manifest['tables'])
                    h.atomic_json(run / 'before-rows.json', before)
                    after = dict(manifest['tables'], catalog=catalog)
                    h.atomic_json(run / 'after-rows.json', after)
                    journal = {'status': 'applying', 'created': h.now(), 'thread_id': info['thread_id'],
                               'source': info['source'], 'target': target_profile,
                               'title': info['title'], 'ids': ids, 'history_ids': history_ids, 'files': list(paths.values()),
                               'before_rows_sha256': h.digest(run / 'before-rows.json'),
                               'after_rows_sha256': h.digest(run / 'after-rows.json'), 'snapshot': info}
                    h.atomic_json(run / 'journal.json', journal)
                    for item in manifest['files']:
                        replace_stream(locks[item['target']], stage / item['relative_path'])
                    write_rows(conn, manifest['tables'], ids, catalog, history_ids=history_ids)
                    for item in manifest['files']:
                        if stream_hash(locks[item['target']]) != item['sha256']:
                            raise h.HandoffError('Imported transcript verification failed.')
                    # Save exact post-import rows for recovery without reverting unrelated work.
                    h.atomic_json(run / 'after-rows.json', capture(conn, ids, history_ids))
                    journal['after_rows_sha256'] = h.digest(run / 'after-rows.json')
                    h.atomic_json(run / 'journal.json', journal)
                    conn.commit()
                    committed = True
                    journal['status'] = 'completed'
                    h.atomic_json(run / 'journal.json', journal)
                except BaseException:
                    conn.rollback()
                    if journal and not committed:
                        for path, item in paths.items():
                            if item['backup']:
                                replace_stream(locks[path], Path(item['backup']))
                        journal['status'] = 'rolled_back'
                        h.atomic_json(run / 'journal.json', journal)
                    raise
            return {'id': info['thread_id'], 'title': info['title'], 'backup': str(run),
                    'records': len(ids), 'history_files': len(manifest['files'])}
        finally:
            stack.close()
            if not committed and (journal is None or journal.get('status') == 'rolled_back'):
                for path in created:
                    path.unlink(missing_ok=True)


def recover_live(target_profile=None):
    restored = []
    for journal_path in RUNS.glob('*/journal.json'):
        journal = json.loads(journal_path.read_text(encoding='utf-8'))
        if journal['status'] != 'applying':
            continue
        receiving = journal.get('target', 'Secondary')
        if target_profile is not None and receiving != target_profile:
            continue
        direction(journal.get('source', journal['snapshot']['source']), receiving)
        run = journal_path.parent
        for name in ('before', 'after'):
            if h.digest(run / (name + '-rows.json')) != journal[name + '_rows_sha256']:
                raise h.HandoffError('Recovery rows failed verification.')
        before = json.loads((run / 'before-rows.json').read_text(encoding='utf-8'))
        after = json.loads((run / 'after-rows.json').read_text(encoding='utf-8'))
        remove = []
        with contextlib.ExitStack() as stack, target_db(receiving) as conn:
            locks = {}
            for item in journal['files']:
                path = home_path(h.PROFILES[receiving], item['path'])
                stream, existed = stack.enter_context(exclusive_file(path))
                locks[str(path)] = stream
                if existed and stream_hash(stream) not in (item['before_sha256'], item['after_sha256']):
                    raise h.HandoffError('History changed after the interrupted import; automatic recovery stopped.')
                if item['backup']:
                    backup = Path(item['backup']).resolve()
                    if not backup.is_relative_to(run.resolve()) or h.digest(backup) != item['before_sha256']:
                        raise h.HandoffError('Transcript recovery backup failed verification.')
            conn.execute('BEGIN IMMEDIATE')
            history_ids = journal.get('history_ids', journal['ids'])
            current = capture(conn, journal['ids'], history_ids)
            for table in ('threads', 'thread_dynamic_tools', 'thread_artifacts', 'thread_spawn_edges', *h.HISTORY_TABLES, 'catalog'):
                if rows_hash(current[table]) not in (rows_hash(before[table]), rows_hash(after[table])):
                    raise h.HandoffError('The receiving task has changed since import; recovery preserved it for review.')
            for item in journal['files']:
                if item['backup']:
                    replace_stream(locks[item['path']], Path(item['backup']))
                else:
                    remove.append(Path(item['path']))
            write_rows(conn, before, journal['ids'], before['catalog'], restore=True, history_ids=history_ids)
            conn.commit()
            journal['status'] = 'recovered'
            h.atomic_json(journal_path, journal)
        for path in remove:
            path.unlink(missing_ok=True)
        restored.append(str(run))
    return restored


def linked_history_matches(source_home, target_home, row, old):
    """An identical active file does not imply its ancestor files/rows were copied."""
    source_files = chain.layout(source_home, row)
    target_files = chain.layout(target_home, old)
    if len(source_files) == len(target_files) == 1:
        return True
    source_by_id = {r['thread_id']: r for r in source_files}
    target_by_id = {r['thread_id']: r for r in target_files}
    if source_by_id.keys() != target_by_id.keys():
        return False
    for storage, item in source_by_id.items():
        other = target_by_id[storage]
        if item['size'] != other['size'] or h.digest(item['path']) != h.digest(other['path']):
            return False
    ids = sorted(source_by_id)
    marks = ','.join('?' for _ in ids)
    with h.read_db(source_home / 'thread_history_1.sqlite') as src, h.read_db(target_home / 'thread_history_1.sqlite') as dst:
        for table in h.HISTORY_TABLES:
            if rows_hash(h.table_rows(src, table, f'thread_id IN ({marks})', ids)) != rows_hash(h.table_rows(dst, table, f'thread_id IN ({marks})', ids)):
                return False
    return True


def import_live(progress=lambda value: None, source_profile='Primary', target_profile='Secondary', cancel=None):
    source_home, target_home = direction(source_profile, target_profile)
    if any(json.loads(p.read_text())['status'] == 'applying' for p in RUNS.glob('*/journal.json')):
        raise h.HandoffError('Recover the previous interrupted live import before starting another.')
    for pattern in (h.ROOT / 'one-time-sync', h.DATA / 'transfers'):
        if any(json.loads(p.read_text())['status'] in ('applying', 'recovery_required') for p in pattern.glob('*/journal.json')):
            raise h.HandoffError('An earlier offline import needs recovery in its original launcher.')
    with h.read_db(source_home / 'state_5.sqlite') as src, h.read_db(target_home / 'state_5.sqlite') as dst:
        source = {r['id']: dict(r) for r in src.execute('SELECT * FROM threads')}
        target = {r['id']: dict(r) for r in dst.execute('SELECT * FROM threads')}
        edges = h.table_rows(src, 'thread_spawn_edges')
    report = {'started': h.now(), 'source': source_profile, 'target': target_profile, 'mode': 'experimental_live', 'imported': [], 'deferred': [], 'preserved_newer_target': [], 'unchanged': 0}
    if target_profile == 'Secondary':
        report['preserved_newer_Alt'] = report['preserved_newer_target']
    for root in source.values():
        if cancel is not None and cancel.is_set():
            report['cancelled'] = True
            break
        if root['source'] != 'vscode':
            continue
        ids = {root['id']}
        while True:
            more = {e['child_thread_id'] for e in edges if e['parent_thread_id'] in ids}
            if more <= ids:
                break
            ids |= more
        changed, newer = False, False
        for tid in ids:
            row, old = source.get(tid), target.get(tid)
            if row is None:
                changed = True
                continue
            if old is None:
                changed = True
                continue
            a = home_path(source_home, row['rollout_path'])
            b = home_path(target_home, old['rollout_path'])
            relation = h.prefix_relation(b, a)
            if (relation == 'conflict' and h.prefix_relation(a, b) == 'extends'
                    or relation in ('same', 'conflict') and old['updated_at'] > row['updated_at']):
                newer = True
            elif relation != 'same' or any(row.get(key) != old.get(key) for key in FIELDS):
                changed = True
            else:
                try:
                    changed |= not linked_history_matches(source_home, target_home, row, old)
                except (h.HandoffError, OSError):
                    # Let snapshot/import give this task a specific deferred reason.
                    changed = True
        if newer:
            report['preserved_newer_target'].append({'id': root['id'], 'ids': sorted(ids), 'title': root.get('name') or root['title']})
        elif not changed:
            report['unchanged'] += 1
        else:
            try:
                progress('Capturing ' + ' '.join(root['title'].split())[:70] + '…')
                info = chain.snapshot_thread(source_profile, root['id'])
                result = import_snapshot(info, progress, target_profile=target_profile)
                report['imported'].append(result)
            except (h.HandoffError, sqlite3.OperationalError) as error:
                report['deferred'].append({'id': root['id'], 'ids': sorted(ids), 'title': root.get('name') or root['title'], 'reason': str(error)})
                if any(json.loads(p.read_text())['status'] == 'applying' for p in RUNS.glob('*/journal.json')):
                    raise h.HandoffError('Import interrupted; use Recover interrupted import before continuing.') from error
        h.atomic_json(RUNS / 'latest-result.json', report)
    report['finished'] = h.now()
    h.atomic_json(RUNS / 'latest-result.json', report)
    return report




