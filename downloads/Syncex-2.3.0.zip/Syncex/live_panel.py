"""Tk controls for native live connection and history preservation."""
import os
import queue
import threading
from datetime import datetime
from pathlib import Path
import tkinter as tk
from tkinter import ttk
import handoff as h
import live_mode
import sync_latest as latest


class LivePanel:
    def __init__(self, parent, selected_ids, catalog=()):
        self.ids = frozenset(selected_ids)
        self.cancel = threading.Event()
        self.events = queue.Queue()
        self.running = False
        self.closing = False
        self.switch_target = None
        self.folder = h.ROOT / 'live-mode'
        self.window = tk.Toplevel(parent)
        self.window.title('Syncex — Live connection')
        self.window.geometry('1120x740')
        self.window.minsize(900, 620)
        self.window.transient(parent)
        self.window.grab_set()
        frame = ttk.Frame(self.window, padding=18)
        frame.pack(fill='both', expand=True)
        ttk.Label(frame, text='Live mode', font=('Segoe UI', 20, 'bold')).pack(anchor='w')
        ttk.Label(frame, text=f'{len(self.ids)} selected task(s) · native stream relay + history checkpoints',
                  font=('Segoe UI', 10, 'bold')).pack(anchor='w', pady=5)
        ttk.Label(frame, wraplength=1040, text=(
            'Connect starts a shared live relay before opening both apps on the selected task. '
            'Messages and outputs stream through the desktop’s owner/follower connection. '
            'Keep this panel open. Raw records and completed checkpoints are preserved separately.')).pack(anchor='w', pady=6)
        ttk.Label(frame, wraplength=1040, text=(
            'Initial connection requires finishing replies and quitting both apps once. '
            'The chosen execution account opens first; the other window follows it. '
            'Conflicts wait for review. Persistent profile copies still wait for the receiver to close.')).pack(anchor='w', pady=4)
        names = {row['id']:row['title'] for row in catalog}
        self.open_ids = [row['id'] for row in catalog if row['id'] in self.ids]
        self.open_ids += sorted(self.ids - set(self.open_ids))
        task_row = ttk.Frame(frame)
        task_row.pack(fill='x', pady=4)
        ttk.Label(task_row, text='Open both apps on:').pack(side='left', padx=(0,8))
        self.open_task = ttk.Combobox(task_row, state='readonly', values=[
            names.get(tid, tid)+'  ('+tid[:8]+')' for tid in self.open_ids])
        self.open_task.pack(side='left', fill='x', expand=True)
        self.open_task.current(0)
        self.tree = ttk.Treeview(frame, columns=('task', 'roles', 'state'), show='headings', height=9)
        for key, title, width in [('task', 'Task', 280), ('roles', 'Last reported role / account', 440), ('state', 'Saved history', 180)]:
            self.tree.heading(key, text=title)
            self.tree.column(key, width=width)
        self.tree.pack(fill='both', expand=True, pady=8)
        self.tree.bind('<<TreeviewSelect>>', lambda event: self.details())
        self.report = {'tasks': []}
        self.output = tk.Text(frame, height=11, wrap='word', state='disabled')
        self.output.pack(fill='x')
        self.status = tk.StringVar(value='Starting Live mode…')
        ttk.Label(frame, textvariable=self.status, wraplength=1040).pack(anchor='w', pady=8)
        row = ttk.Frame(frame)
        row.pack(fill='x')
        self.start_button = ttk.Button(row, text='Connect both apps live', command=self.start)
        self.start_button.pack(side='left')
        self.stop_button = ttk.Button(row, text='Stop', command=self.stop, state='disabled')
        self.stop_button.pack(side='left', padx=6)
        self.preserve_button=ttk.Button(row,text='Preserve only',command=self.preserve)
        self.preserve_button.pack(side='left',padx=6)
        ttk.Button(row, text='Open live backups', command=self.open_backups).pack(side='left', padx=6)
        account_row = ttk.Frame(frame)
        account_row.pack(fill='x', pady=(6,0))
        self.switch_buttons = []
        for profile in latest.PROFILES:
            button = ttk.Button(account_row, text='Execute as ' + h.ACCOUNTS[profile], command=lambda p=profile: self.switch(p))
            button.pack(side='left', padx=6)
            self.switch_buttons.append(button)
        ttk.Label(frame, wraplength=1040, text=(
            'Execute as reconnects both apps with the chosen account as owner. Password entry may be required. '
            'Stop or close disconnects the live relay and ends preservation; finish replies first. '
            'No app is killed. Backups are retained. Preserve only runs the original checkpoint watcher.')).pack(anchor='w', pady=(10, 0))
        self.window.protocol('WM_DELETE_WINDOW', self.close)
        self.poll_id = self.window.after(100, self.poll)
        self.status.set('Choose Connect both apps live, or Preserve only. The live connection needs both apps to quit once.')

    def open_backups(self):
        self.folder.mkdir(parents=True, exist_ok=True)
        os.startfile(self.folder)

    def begin(self, operation):
        self.cancel.clear()
        self.running = True
        self.start_button.configure(state='disabled')
        self.preserve_button.configure(state='disabled')
        self.open_task.configure(state='disabled')
        self.stop_button.configure(state='normal')
        def run():
            try:
                result = operation()
                self.events.put(('finished', result))
            except Exception as exc:
                self.events.put(('error', str(exc)))
        threading.Thread(target=run, daemon=True).start()

    def start(self):
        if self.running:
            return
        import windows_launch
        account=windows_launch.current_account().casefold()
        owner=next((p for p in latest.PROFILES if h.ACCOUNTS[p].casefold()==account),latest.PROFILES[0])
        self.connect(owner)

    def connect(self,owner):
        import live_connection
        primary=self.open_ids[self.open_task.current()]
        self.status.set('Preparing the real-time connection…')
        self.begin(lambda:live_connection.connect(self.ids,owner,self.cancel,
            lambda text:self.events.put(('status',text)),lambda value:self.events.put(('report',value)),primary=primary))

    def preserve(self):
        if self.running:return
        self.status.set('Preserving history only; live relay is off.')
        self.begin(lambda:live_mode.Engine(self.ids,self.cancel).run(lambda value:self.events.put(('report',value))))

    def stop(self):
        self.switch_target = None
        self.cancel.set()
        self.status.set('Stopping after the current safe operation…')

    def switch(self, target):
        self.switch_target = target
        self.cancel.set()
        self.status.set('Preparing switch. Finish replies before quitting the apps.')
        for button in self.switch_buttons:
            button.configure(state='disabled')
        if not self.running:
            self.begin_switch()

    def begin_switch(self):
        target, self.switch_target = self.switch_target, None
        self.connect(target)

    def details(self):
        ids = set(self.tree.selection())
        lines = list(self.report.get('errors', []))
        bridge=self.report.get('bridge')
        if bridge:
            lines.append(f"Live relay: {len(bridge['clients'])} clients; {bridge['stream_updates']} stream updates forwarded; {bridge['requests']} requests routed.")
            lines.extend(bridge.get('errors',[]))
        for row in self.report.get('tasks', []):
            if ids and row['id'] not in ids:
                continue
            lines.extend([row['title'], row.get('detail', ''), 'Task ID: ' + row['id']])
            if sum(value['role'] == 'owner' for value in row['roles'].values()) > 1:
                lines.append('Both apps have reported ownership. These are past observations. Use Execute as for a controlled restart after finishing replies.')
            for profile, detail in row['profiles'].items():
                lines.append(f"  {profile}: {detail['journal_bytes']:,} bytes preserved; " +
                             ('checkpoint ' + detail['checkpoint'] if detail['checkpoint'] else 'waiting for completed checkpoint'))
                if detail.get('detail'):
                    lines.append('    ' + detail['detail'])
            lines.append('')
        self.output.configure(state='normal')
        self.output.delete('1.0', 'end')
        self.output.insert('1.0', '\n'.join(lines))
        self.output.configure(state='disabled')

    def render(self, report):
        self.report = report
        self.folder = Path(report['folder'])
        selected = self.tree.selection()
        self.tree.delete(*self.tree.get_children())
        for row in report['tasks']:
            roles = '; '.join(value['account'] + ': ' + value['role'] + ' at ' + datetime.fromtimestamp(value['time']).strftime('%H:%M:%S')
                              for value in row['roles'].values()) or 'Unavailable'
            self.tree.insert('', 'end', iid=row['id'], values=(' '.join(row['title'].split())[:100], roles,
                {'synced': 'Saved in both', 'waiting': 'Pending', 'conflict': 'Review conflict'}[row['state']]))
        self.tree.selection_set([value for value in selected if self.tree.exists(value)])
        self.details()
        bridge=report.get('bridge')
        if bridge:
            primary=bridge['primary']
            following=any(row['following'] and row['profile']==bridge['follower'] for row in bridge['followers'].get(primary,[]))
            streamed=bridge['last_stream'].get(primary,{}).get('profile')==bridge['owner']
            label='Live connection active' if following and streamed else 'Relay running; waiting to observe follower updates'
        else:label='History preservation only'
        self.status.set(('Needs attention — ' if report['errors'] else label+' — ')+report['updated'])

    def poll(self):
        try:
            while True:
                kind, value = self.events.get_nowait()
                if kind == 'report':
                    self.render(value)
                elif kind == 'status':
                    self.status.set(value)
                else:
                    self.running = False
                    self.start_button.configure(state='normal')
                    self.preserve_button.configure(state='normal')
                    self.open_task.configure(state='readonly')
                    self.stop_button.configure(state='disabled')
                    for button in self.switch_buttons:
                        button.configure(state='normal')
                    if kind == 'error':
                        self.switch_target = None
                        self.status.set(value)
                    elif self.switch_target and not self.closing:
                        self.begin_switch()
                    elif value and value.get('status') == 'opened':
                        self.status.set('Opened as ' + value['account'] + '. Open the selected task there. Click Start to resume monitoring.')
                    elif value and value.get('status') == 'needs_review':
                        self.status.set('Connection paused. Resolve the pending history before opening the apps.')
                        self.output.configure(state='normal')
                        self.output.delete('1.0', 'end')
                        self.output.insert('1.0', '\n'.join(row['title'] + ': ' + row.get('reason', 'Changes still pending')
                            for key in ('conflicts', 'deferred', 'planned') for row in value['report'].get(key, [])))
                        self.output.configure(state='disabled')
                    else:
                        self.status.set('Live mode stopped. Preserved history remains in the shared folder.')
        except queue.Empty:
            pass
        if self.closing and not self.running:
            self.window.destroy()
            return
        self.poll_id = self.window.after(100, self.poll)

    def close(self):
        self.closing = True
        self.stop()


def show(parent, selected_ids, catalog=()):
    panel = LivePanel(parent, selected_ids, catalog)
    parent.wait_window(panel.window)
