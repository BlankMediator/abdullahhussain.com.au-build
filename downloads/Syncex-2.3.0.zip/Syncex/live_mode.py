"""Live preservation and conservative replication of selected desktop tasks.

No model requests or private IPC writes. The desktop owns live streaming.
All profile mutations go through the existing locked, journalled importer.
"""
from datetime import datetime, timezone, timedelta
import ctypes
from ctypes import wintypes
import hashlib
import json
import os
from pathlib import Path
import re
import shutil
import sqlite3
import threading
import time
import uuid
import zipfile

import handoff as h
import history_chain as chain
import sync_latest as latest
import sync_live as importer
import sync_profiles as combined
import repair_sidebar as sidebar

INTERVAL = 5
CHUNK = 1024 * 1024


def token(value):
    return hashlib.sha256(json.dumps(value, sort_keys=True, ensure_ascii=False).encode()).hexdigest()


def save(path, value):
    """Publish a flushed record only after its referenced data is durable."""
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_name(path.name + '.' + uuid.uuid4().hex + '.tmp')
    try:
        with temporary.open('x', encoding='utf-8') as stream:
            json.dump(value, stream, ensure_ascii=False, indent=2)
            stream.flush()
            os.fsync(stream.fileno())
        os.replace(temporary, path)
    finally:
        temporary.unlink(missing_ok=True)


def prefix_hash(path, length):
    digest = hashlib.sha256()
    with path.open('rb') as stream:
        while length:
            data = stream.read(min(CHUNK, length))
            if not data:
                return None
            digest.update(data)
            length -= len(data)
    return digest.hexdigest()


class Journal:
    """Append complete raw records; retain a new generation on any divergence.

    These are recovery evidence, not an importable paginated history snapshot.
    A committed offset permits safe recovery from an interrupted append.
    """
    def __init__(self, folder):
        self.folder = folder
        self.seen = {}

    def capture(self, profile, home, item):
        source = chain.checked_path(home, item['path'])
        key = token([profile, str(home), str(source)])
        folder = self.folder / key
        manifest = folder / 'latest.json'
        before = source.stat()
        signature = (before.st_size, before.st_mtime_ns)
        if self.seen.get(key, (None,))[0] == signature:
            return self.seen[key][1]
        old = json.loads(manifest.read_text(encoding='utf-8')) if manifest.exists() else None
        previous = None
        if old:
            previous = folder / (str(uuid.UUID(old['generation'])) + '.jsonl')
            size = old['bytes']
            source_extends = prefix_hash(source, size) == old['sha256']
            valid = previous.exists() and prefix_hash(previous, size) == old['sha256'] and source_extends
        else:
            valid = False
        generation = old['generation'] if valid else str(uuid.uuid4())
        destination = folder / (generation + '.jsonl')
        offset = old['bytes'] if valid else 0
        folder.mkdir(parents=True, exist_ok=True)
        digest = hashlib.sha256()
        # Hash/compare the committed prefix again on the same source handle used
        # for the append. Do not trust a renamed file from an earlier handle.
        with source.open('rb') as src, destination.open('r+b' if valid else 'xb') as dst:
            remaining = offset
            while remaining:
                data = src.read(min(CHUNK, remaining))
                if not data:
                    raise importer.Deferred('Transcript changed during live capture; retrying.')
                digest.update(data)
                remaining -= len(data)
            if valid and digest.hexdigest() != old['sha256']:
                raise importer.Deferred('Transcript was replaced during live capture; retrying.')
            dst.seek(offset)
            # Discard only uncommitted bytes left by an interrupted append.
            dst.truncate(offset)
            end = offset
            remaining = max(0, before.st_size - offset)
            while remaining:
                data = src.read(min(CHUNK, remaining))
                if not data:
                    break
                dst.write(data)
                remaining -= len(data)
                newline = data.rfind(b'\n')
                if newline >= 0:
                    end = dst.tell() - len(data) + newline + 1
            dst.truncate(end)
            dst.flush()
            os.fsync(dst.fileno())
        value = {'version': 1, 'profile': profile, 'source_home': str(home),
                 'source_path': str(source), 'storage_id': item['thread_id'],
                 'task_id': item['owner_thread_id'], 'generation': generation,
                 'bytes': end, 'sha256': prefix_hash(destination, end),
                 'path': str(destination), 'captured': h.now(),
                 'requires_review': bool(old and (old.get('requires_review') or not source_extends)),
                 'kind': 'raw recovery evidence; not an importable checkpoint'}
        # A rewrite while reading must never become a trusted checkpoint.
        if prefix_hash(source, end) != value['sha256']:
            raise importer.Deferred('Transcript changed during live capture; retrying.')
        save(folder / (generation + '.json'), value)
        save(manifest, value)
        after = source.stat()
        if (after.st_size, after.st_mtime_ns) == signature:
            self.seen[key] = (signature, value)
        return value


def process_started(pid):
    """Creation time prevents recycled process IDs from reviving old log roles."""
    kernel = ctypes.WinDLL('kernel32', use_last_error=True)
    kernel.OpenProcess.argtypes = [wintypes.DWORD, wintypes.BOOL, wintypes.DWORD]
    kernel.OpenProcess.restype = wintypes.HANDLE
    kernel.GetProcessTimes.argtypes = [wintypes.HANDLE] + [ctypes.POINTER(wintypes.FILETIME)] * 4
    kernel.GetProcessTimes.restype = wintypes.BOOL
    kernel.CloseHandle.argtypes = [wintypes.HANDLE]
    handle = kernel.OpenProcess(0x1000, False, pid)
    if not handle:
        raise ctypes.WinError(ctypes.get_last_error())
    try:
        values = [wintypes.FILETIME() for _ in range(4)]
        if not kernel.GetProcessTimes(handle, *(ctypes.byref(v) for v in values)):
            raise ctypes.WinError(ctypes.get_last_error())
        return ((values[0].dwHighDateTime << 32) + values[0].dwLowDateTime) / 10_000_000 - 11644473600
    finally:
        kernel.CloseHandle(handle)


def parse_roles(data, ids, started):
    result = {}
    for line in data.splitlines():
        if 'thread_stream_role_changed ' not in line:
            continue
        fields = dict(re.findall(r'(\w+)=([^\s]+)', line))
        tid, role = fields.get('conversationId'), fields.get('role')
        if tid not in ids:
            continue
        try:
            stamp = datetime.fromisoformat(line.split(' ', 1)[0].replace('Z', '+00:00')).timestamp()
        except ValueError:
            continue
        if stamp >= started and (tid not in result or stamp > result[tid]['time']):
            result[tid] = {'role': role if role in ('owner', 'follower') else 'unknown', 'time': stamp}
    return result


class RoleObserver:
    """Optional log evidence only; never used to authorize a history import."""
    def __init__(self):
        self.cache = {}

    def read(self, ids):
        result = {tid: {} for tid in ids}
        tree = sidebar.app_process_tree()
        now = datetime.now(timezone.utc)
        for profile, home in h.PROFILES.items():
            # Custom CODEX_HOME need not be inside the Windows profile. In that
            # case logging is unavailable rather than guessed from a label.
            log_root = home.parent / 'AppData/Local/Codex/Logs'
            wanted = sidebar.canonical_account(h.ACCOUNTS[profile]).casefold()
            pids = {}
            for pid in tree:
                try:
                    if sidebar.process_owner(pid).casefold() == wanted:
                        pids[pid] = process_started(pid)
                except (OSError, h.HandoffError):
                    continue
            for day in (now, now - timedelta(days=1)):
                directory = log_root / day.strftime('%Y/%m/%d')
                for path in directory.glob('codex-desktop-*-t0-*.log'):
                    match = re.search(r'-(\d+)-t0-', path.name)
                    pid = int(match[1]) if match else None
                    if pid not in pids:
                        continue
                    stat = path.stat()
                    cache_key = (str(path), stat.st_size, stat.st_mtime_ns, pids[pid], tuple(sorted(ids)))
                    if cache_key not in self.cache:
                        with path.open('rb') as stream:
                            stream.seek(max(0, stat.st_size - 4 * CHUNK))
                            data = stream.read().decode('utf-8', errors='replace')
                        # Bound memory across rotations and long-running sessions.
                        if len(self.cache) > 64:
                            self.cache.clear()
                        self.cache[cache_key] = parse_roles(data, ids, pids[pid])
                    for tid, observation in self.cache[cache_key].items():
                        if observation['time'] > result[tid].get(profile, {}).get('time', 0):
                            result[tid][profile] = dict(observation, pid=pid, account=h.ACCOUNTS[profile])
        return result


class ClosedReceiverGuard(latest.Guard):
    def __init__(self, source, target, ids):
        super().__init__(source, target, ids)
        self.target_profile = target['profile']

    def check_target(self, conn, before):
        sidebar.require_profile_closed(self.target_profile)
        super().check_target(conn, before)


class Engine:
    def __init__(self, selected_ids, cancel=None):
        self.ids = {h.checked_id(value) for value in selected_ids}
        if not self.ids:
            raise ValueError('Select at least one task for Live mode.')
        self.cancel = cancel or threading.Event()
        identity = {p: {'home': str(v.resolve()), 'account': h.ACCOUNTS[p]} for p, v in h.PROFILES.items()}
        self.folder = h.ROOT / 'live-mode' / token(identity)[:20]
        self.folder.mkdir(parents=True, exist_ok=True)
        self.state_path = self.folder / 'checkpoints.json'
        self.state = json.loads(self.state_path.read_text(encoding='utf-8')) if self.state_path.exists() else {'version': 1, 'profiles': identity, 'tasks': {}}
        if self.state.get('version') != 1 or self.state.get('profiles') != identity:
            raise ValueError('Live checkpoint settings do not match these profiles.')
        self.journal = Journal(self.folder / 'journals')
        self.observer = RoleObserver()
        self.closed_since = {}

    def checkpoint(self, root, profile, view):
        fingerprint = token({'rows': view['rows'], 'files': [(f['relative_path'], f['sha256']) for f in view['files'].values()],
                             'history': view['history'], 'edges': view['edges']})
        records = self.state['tasks'].setdefault(root, {})
        old = records.get(profile)
        if old and old['fingerprint'] == fingerprint:
            archive = Path(old['snapshot']['archive'])
            if archive.is_file() and h.digest(archive) == old['snapshot']['sha256']:
                return old
        if old:
            # A relaunch or external copy can move BOTH profiles backwards.
            # Never call that synchronized or supersede the newer checkpoint.
            with h.scratch() as stage:
                previous = chain.load_package(old['snapshot'], stage)
                layouts = {}
                for item in previous['files']:
                    item = dict(item, path=str(stage / item['relative_path']))
                    layouts.setdefault(item.get('owner_thread_id', item['thread_id']), []).append(item)
                previous_view = {'rows': {row['id']: row for row in previous['tables']['threads']}, 'layouts': layouts}
                if not latest.contains(view, previous_view):
                    raise importer.Deferred('Saved checkpoint contains a different or newer history. Preserved for recovery; review before syncing.')
        info = chain.snapshot_thread(profile, root)
        # Bind checkpoint identity to the comparison used by the importer.
        with zipfile.ZipFile(info['archive']) as archive:
            latest.Guard(view, view, set(view['rows'])).check_source(json.loads(archive.read('manifest.json')))
        destination = self.folder / 'checkpoints' / (info['sha256'] + '.zip')
        destination.parent.mkdir(parents=True, exist_ok=True)
        if not destination.exists():
            temporary = destination.with_suffix('.' + uuid.uuid4().hex + '.tmp')
            try:
                with Path(info['archive']).open('rb') as src, temporary.open('xb') as dst:
                    shutil.copyfileobj(src, dst)
                    dst.flush()
                    os.fsync(dst.fileno())
                if h.digest(temporary) != info['sha256']:
                    raise h.HandoffError('Live checkpoint checksum failed.')
                os.replace(temporary, destination)
            finally:
                temporary.unlink(missing_ok=True)
        if h.digest(destination) != info['sha256']:
            raise h.HandoffError('Saved live checkpoint checksum failed; preserved for review.')
        info = dict(info, archive=str(destination))
        record = {'fingerprint': fingerprint, 'snapshot': info, 'captured': h.now()}
        records[profile] = record
        save(self.state_path, self.state)
        return record

    def tick(self):
        report = {'updated': h.now(), 'folder': str(self.folder), 'tasks': [], 'errors': []}
        with combined.worker_lock():
            initial = {p: latest.index(p) for p in latest.PROFILES}
            try:
                roles = self.observer.read(self.ids)
            except (OSError, h.HandoffError, ValueError) as exc:
                roles = {}
                report['errors'].append('Live role observation unavailable: ' + str(exc))
            for root in sorted(self.ids):
                if self.cancel.is_set():
                    break
                ids = set().union(*(latest.descendants(root, edges) for _, edges in initial.values()))
                main = next((rows[root] for rows, _ in initial.values() if root in rows), None)
                entry = {'id': root, 'title': (main.get('name') or main['title']) if main else root,
                         'roles': roles.get(root, {}), 'profiles': {}, 'state': 'waiting'}
                report['tasks'].append(entry)
                if not main:
                    entry['detail'] = 'Task no longer found in either profile.'
                    continue
                views, checkpoints = {}, {}
                for profile in latest.PROFILES:
                    detail = {'journal_bytes': 0, 'checkpoint': None}
                    entry['profiles'][profile] = detail
                    try:
                        rows, edges = initial[profile]
                        for tid in sorted(ids & rows.keys()):
                            for item in chain.layout(h.PROFILES[profile], rows[tid]):
                                captured = self.journal.capture(profile, h.PROFILES[profile], item)
                                detail['journal_bytes'] += captured['bytes']
                                if captured.get('requires_review'):
                                    raise importer.Deferred('This transcript was shortened or replaced. Earlier live records are preserved; review before syncing.')
                        view = latest.view(profile, ids, rows, edges)
                        if root in rows:
                            if not latest.descendants(root, edges) <= rows.keys():
                                raise importer.Deferred('A supporting task is still being saved.')
                            record = self.checkpoint(root, profile, view)
                            checkpoints[profile] = record['snapshot']
                            detail['checkpoint'] = record['captured']
                        views[profile] = view
                    except (h.HandoffError, OSError, sqlite3.Error, ValueError) as exc:
                        detail['detail'] = str(exc)
                if len(views) != len(latest.PROFILES):
                    entry['detail'] = 'Preserving live records; waiting for complete, indexed histories.'
                    continue
                try:
                    decision, source, reason = latest.choose(*(views[p] for p in latest.PROFILES))
                    if decision == 'conflict':
                        entry.update(state='conflict', detail=reason + ' Stop Live mode and use the merge controls.')
                    elif decision == 'unchanged':
                        entry.update(state='synced', detail='Saved histories verified in both profiles.')
                    else:
                        src = source['profile']
                        dst = next(p for p in latest.PROFILES if p != src)
                        entry.update(source=src, target=dst, detail=f'Checkpoint saved. Waiting for {dst} to close.')
                        apps = sidebar.profile_apps(dst)
                        if apps:
                            self.closed_since.pop(dst, None)
                            if getattr(apps, 'unknown', ()):
                                entry['detail'] = 'Checkpoint saved. Windows could not identify an app owner; close both apps to copy.'
                            continue
                        quiet = self.closed_since.setdefault(dst, time.monotonic())
                        if time.monotonic() - quiet < 2 or self.cancel.is_set():
                            continue
                        if not ids <= source['rows'].keys():
                            raise importer.Deferred('Neither profile contains the complete supporting-task group.')
                        latest.pending_recovery()
                        sidebar.require_profile_closed(dst)
                        info = checkpoints[src]
                        importer.import_snapshot(info, target_profile=dst, guard=ClosedReceiverGuard(source, views[dst], ids))
                        # Re-read before reporting durability; the source can start
                        # another turn while the previous checkpoint is imported.
                        fresh = {p: latest.view(p, ids, *latest.index(p)) for p in latest.PROFILES}
                        verdict = latest.choose(*(fresh[p] for p in latest.PROFILES))[0]
                        entry.update(state='synced' if verdict == 'unchanged' else 'waiting',
                                     detail='Saved histories verified in both profiles.' if verdict == 'unchanged' else 'Checkpoint copied; newer changes remain.')
                except (h.HandoffError, OSError, sqlite3.Error, ValueError) as exc:
                    entry.update(state='waiting', detail=str(exc))
            save(self.folder / 'status.json', report)
        return report

    def run(self, publish):
        while not self.cancel.is_set():
            try:
                publish(self.tick())
            except Exception as exc:
                publish({'updated': h.now(), 'folder': str(self.folder), 'tasks': [], 'errors': [str(exc)]})
            if self.cancel.wait(INTERVAL):
                break


def handover(selected_ids, target, cancel, progress):
    """Release both native app owners by exit, copy, then launch one account."""
    if target not in latest.PROFILES or not selected_ids:
        raise ValueError('Select tasks and a configured target profile.')
    progress('Finish the current replies, then quit BOTH apps with Ctrl+Q. Keep this launcher open.')
    if not sidebar.wait_for_profiles_exit(latest.PROFILES, cancel, progress):
        return {'status': 'cancelled'}
    engine = Engine(selected_ids, cancel)
    engine.closed_since = {p: time.monotonic() - 3 for p in latest.PROFILES}
    result = engine.tick()
    if cancel.is_set():
        return {'status': 'cancelled'}
    problems = [row for row in result['tasks'] if row['state'] != 'synced']
    if problems or result['errors']:
        return {'status': 'needs_review', 'report': {'deferred': [
            {'title': row['title'], 'reason': row.get('detail', 'Pending')} for row in problems] +
            [{'title': 'Live mode', 'reason': error} for error in result['errors']]}}
    for profile in latest.PROFILES:
        sidebar.require_profile_closed(profile)
    # launch() uses the existing credential flow and verifies standard tokens.
    import profile_config
    opened = profile_config.launch(target)
    return {'status': 'opened', 'account': opened['account'], 'report': result}
