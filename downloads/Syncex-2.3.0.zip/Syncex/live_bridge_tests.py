"""Synthetic routing and real disposable named-pipe tests. No desktop launches."""
import ctypes as c
from ctypes import wintypes as w
import json
import struct
import threading
import time
import unittest
import uuid
from unittest.mock import patch
import live_bridge as b

TASK='11111111-1111-4111-8111-111111111111'
OTHER='22222222-2222-4222-8222-222222222222'


class RoutingTests(unittest.TestCase):
    def setUp(self):
        self.router=b.Router({TASK})
        self.left_messages=[];self.right_messages=[]
        self.left=self.router.add('Left',self.left_messages.append)
        self.right=self.router.add('Right',self.right_messages.append)
        for peer in (self.left,self.right):
            self.router.receive(peer,{'type':'request','method':'initialize','requestId':'init','params':{'clientType':'desktop'}})
        self.left_messages.clear();self.right_messages.clear()

    def packet(self,**changes):
        value={'type':'broadcast','method':'thread-stream-state-changed','version':11,
               'params':{'hostId':'local','conversationId':TASK,'change':{'type':'patches','patches':[]}}}
        value.update(changes);return value

    def test_stream_forwarded_immediately_and_source_cannot_be_spoofed(self):
        self.router.receive(self.left,self.packet(sourceClientId='forged'))
        self.assertEqual(self.right_messages[-1]['sourceClientId'],self.left['id'])
        self.assertEqual(self.router.status()['stream_updates'],1)

    def test_other_task_not_shared(self):
        value=self.packet();value['params']['conversationId']=OTHER
        self.router.receive(self.left,value)
        self.assertEqual(self.right_messages,[])

    def test_unknown_protocol_version_not_shared(self):
        self.router.receive(self.left,self.packet(version=99))
        self.assertEqual(self.right_messages,[])

    def test_remote_host_not_shared(self):
        value=self.packet();value['params']['hostId']='remote'
        self.router.receive(self.left,value)
        self.assertEqual(self.right_messages,[])

    def test_unrelated_same_account_functionality_preserved(self):
        messages=[];same=self.router.add('Left',messages.append)
        self.router.receive(same,{'type':'request','method':'initialize','requestId':'init','params':{}})
        messages.clear()
        self.router.receive(self.left,{'type':'broadcast','method':'query-cache-invalidate','params':{},'version':0})
        self.assertEqual(messages[-1]['method'],'query-cache-invalidate')
        self.assertFalse(any(x.get('method')=='query-cache-invalidate' for x in self.right_messages))

    def request(self):
        self.router.receive(self.left,{'type':'request','method':'thread-owner-discovery','version':1,
            'requestId':'original','params':{'hostId':'local','conversationId':TASK}})
        return self.right_messages[-1]

    def test_discovery_then_response_preserves_id_and_no_duplicate_action(self):
        discovery=self.request()
        self.router.receive(self.right,{'type':'client-discovery-response','requestId':discovery['requestId'],'response':{'canHandle':True}})
        request=self.right_messages[-1]
        self.assertEqual(request['type'],'request')
        reply={'type':'response','requestId':request['requestId'],'resultType':'success','method':'thread-owner-discovery','result':{'supportsUntrustedAppInput':True}}
        self.router.receive(self.right,reply);self.router.receive(self.right,reply)
        responses=[x for x in self.left_messages if x.get('type')=='response']
        self.assertEqual(len(responses),1)
        self.assertEqual(responses[0]['requestId'],'original')
        self.assertEqual(responses[0]['handledByClientId'],self.right['id'])

    def test_wrong_client_cannot_answer_discovery_or_request(self):
        discovery=self.request()
        self.router.receive(self.left,{'type':'client-discovery-response','requestId':discovery['requestId'],'response':{'canHandle':True}})
        self.assertEqual(self.right_messages[-1]['type'],'client-discovery-request')
        self.router.receive(self.right,{'type':'client-discovery-response','requestId':discovery['requestId'],'response':{'canHandle':True}})
        request=self.right_messages[-1]
        self.router.receive(self.left,{'type':'response','requestId':request['requestId'],'resultType':'success'})
        self.assertFalse(self.left_messages)

    def test_disconnect_reports_failure_without_replaying(self):
        self.request();self.router.remove(self.right)
        responses=[x for x in self.left_messages if x.get('type')=='response']
        self.assertEqual(responses[-1]['error'],'no-client-found')
        self.assertFalse(self.router.pending)

    def test_request_timeout_cleans_pending_discoveries(self):
        self.request()
        for value in self.router.pending.values():value['deadline']=0
        self.router.expire()
        self.assertEqual(self.left_messages[-1]['error'],'request-timeout')
        self.assertFalse(self.router.discoveries)

    def test_client_cannot_forge_router_lifecycle_broadcast(self):
        self.router.receive(self.left,{'type':'broadcast','method':'client-status-changed','params':{}})
        self.assertEqual(self.right_messages,[])


class NativePipeTests(unittest.TestCase):
    def setUp(self):
        import windows_launch as launch
        self.account=launch.current_account()
        self.pipe=r'\\.\pipe\profile-sync-test-'+uuid.uuid4().hex
        self.server=b.PipeServer({TASK},{'Current':self.account},{},self.pipe,verify_apps=False).start()
        self.addCleanup(self.server.close)
        self.k=b.kernel()
        self.k.CreateFileW.argtypes=[w.LPCWSTR,w.DWORD,w.DWORD,c.c_void_p,w.DWORD,w.DWORD,w.HANDLE]
        self.k.CreateFileW.restype=w.HANDLE
        self.k.WaitNamedPipeW.argtypes=[w.LPCWSTR,w.DWORD]

    def client(self):
        for _ in range(30):
            handle=self.k.CreateFileW(self.pipe,0xC0000000,0,None,3,0x40000000,None)
            if handle!=c.c_void_p(-1).value:
                self.addCleanup(self.k.CloseHandle,handle);return handle
            time.sleep(.02)
        self.fail('Could not connect disposable pipe')

    def send(self,handle,value,fragmented=False):
        data=b.frame(value)
        for block in ([data[:2],data[2:7],data[7:]] if fragmented else [data]):
            self.assertEqual(self.server.io('write',handle,block,len(block)),len(block))

    def read(self,handle):
        # Wait on a worker so a failing protocol test cannot hang the test runner.
        output=[]
        def receive():
            try:
                length=struct.unpack('<I',self.server.read_exact(handle,4))[0]
                output.append(json.loads(self.server.read_exact(handle,length)))
            except Exception as exc:output.append(exc)
        thread=threading.Thread(target=receive,daemon=True);thread.start();thread.join(3)
        if thread.is_alive():self.server.close()
        self.assertFalse(thread.is_alive(),'Pipe response timed out: '+str(self.server.status()))
        if isinstance(output[0],Exception):raise output[0]
        return output[0]

    def initialize(self,handle,number):
        self.send(handle,{'type':'request','method':'initialize','requestId':number,'params':{'clientType':'test'}},fragmented=True)
        result=self.read(handle)
        self.assertEqual(result['resultType'],'success')
        return result['result']['clientId']

    def test_native_framing_two_clients_and_live_broadcast(self):
        left=self.client();self.initialize(left,'one')
        right=self.client();self.initialize(right,'two')
        self.assertEqual(self.read(left)['method'],'client-status-changed')
        self.send(left,{'type':'broadcast','method':'thread-stream-state-changed','version':11,
                       'params':{'conversationId':TASK,'hostId':'local','change':{'type':'patches','text':'synthetic live output'}}})
        message=self.read(right)
        self.assertEqual(message['params']['change']['text'],'synthetic live output')
        # Both native clients run as the current account: do not claim cross-account delivery.
        self.assertEqual(self.server.status()['stream_updates'],0)

    def test_second_router_cannot_take_existing_pipe(self):
        other=b.PipeServer({TASK},{'Current':self.account},{},self.pipe,verify_apps=False)
        with self.assertRaises(b.BridgeError):other.start()

    def test_stop_releases_pipe_for_restart(self):
        self.server.close()
        self.assertFalse(self.server.accept_thread.is_alive())
        replacement=b.PipeServer({TASK},{'Current':self.account},{},self.pipe,verify_apps=False).start()
        replacement.close()


if __name__=='__main__':unittest.main(verbosity=2)
