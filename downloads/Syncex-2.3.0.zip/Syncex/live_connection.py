"""Controlled native live-session startup plus durable preservation."""
import time
import handoff as h
import live_mode
import live_bridge
import profile_config
import repair_sidebar
import sync_latest


def connect(selected_ids, owner, cancel, progress, publish, primary=None):
    ids={h.checked_id(tid) for tid in selected_ids}
    if not ids or owner not in sync_latest.PROFILES:
        raise ValueError('Select tasks and a configured execution account.')
    primary = h.checked_id(primary) if primary else sorted(ids)[0]
    if primary not in ids:
        raise ValueError('The task to open must be included in the selected tasks.')
    for app in set(h.APPS.values()):
        live_bridge.check_bundle(app)
    progress('Finish replies, then quit BOTH apps with Ctrl+Q. The live relay must start first. Keep this launcher open.')
    if not repair_sidebar.wait_for_profiles_exit(sync_latest.PROFILES,cancel,progress):
        return {'status':'cancelled'}
    engine=live_mode.Engine(ids,cancel)
    engine.closed_since={p:time.monotonic()-3 for p in sync_latest.PROFILES}
    report=engine.tick()
    pending=[row for row in report['tasks'] if row['state']!='synced']
    if pending or report['errors']:
        publish(report)
        return {'status':'needs_review','report':{'deferred':[
            {'title':row['title'],'reason':row.get('detail','History not synchronized')} for row in pending] +
            [{'title':'Live setup','reason':error} for error in report['errors']]}}
    if cancel.is_set():return {'status':'cancelled'}
    for profile in sync_latest.PROFILES:repair_sidebar.require_profile_closed(profile)
    server=live_bridge.PipeServer(ids,h.ACCOUNTS,h.APPS).start()
    try:
        url='codex://threads/'+primary
        progress('Live relay ready. Opening the execution app as '+h.ACCOUNTS[owner]+'…')
        profile_config.launch(owner,open_url=url)
        deadline=time.monotonic()+30
        actual_owner=None
        while not cancel.is_set() and time.monotonic()<deadline:
            actual_owner=server.discover_owner(primary,owner,timeout=3)
            if actual_owner:break
            progress('Waiting for the selected task to load in '+h.ACCOUNTS[owner]+'…')
            if cancel.wait(.5):break
        if cancel.is_set():return {'status':'cancelled'}
        if not actual_owner:
            raise live_bridge.BridgeError('The execution app opened, but ownership of the selected task was not confirmed. The other app was not opened. Open the task in the execution app and reconnect after finishing its reply.')
        follower=next(p for p in sync_latest.PROFILES if p!=owner)
        progress('Execution owner confirmed. Opening the follower as '+h.ACCOUNTS[follower]+'…')
        profile_config.launch(follower,open_url=url)
        connected_at=time.monotonic()
        def update(value):
            bridge=server.status()
            value['bridge']=dict(bridge,owner=owner,follower=follower,primary=primary)
            value.setdefault('errors',[]).extend(bridge['errors'])
            if not bridge['listening']:
                value.setdefault('errors',[]).append('Live relay listener stopped. Stop, finish replies and reconnect both apps.')
            elif time.monotonic()-connected_at>60 and not any(
                    row['following'] and row['profile']==follower for row in bridge['followers'].get(primary,[])):
                value['errors'].append('The second app has not confirmed following the selected task. Open that task in both apps and check the relay details. Live mirroring is not verified.')
            publish(value)
        progress('Both app windows verified. Watching for native follower attachment and live updates…')
        engine.run(update)
        return {'status':'stopped'}
    finally:
        server.close()
