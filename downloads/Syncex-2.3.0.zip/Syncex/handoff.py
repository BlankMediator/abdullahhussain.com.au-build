"""Local Codex snapshots and conservative, offline transfers between two profiles.

No network, credentials, running-app termination, or whole-directory mirroring.
The runtime uses only Python's standard library.
"""
from __future__ import annotations
import argparse
import contextlib
import ctypes
from ctypes import wintypes
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import re
import shutil
import sqlite3
import subprocess
import sys
import tempfile
import time
import uuid
import zipfile

ROOT = Path(__file__).resolve().parent
DATA = ROOT / 'data'
PROFILES = {}
ACCOUNTS = {}
APP = Path()
STATE_TABLES = ('thread_sections', 'projects', 'project_roots', 'project_idempotency_keys',
                'threads', 'thread_dynamic_tools', 'thread_spawn_edges', 'thread_artifacts')
HISTORY_TABLES = ('thread_turns', 'thread_items', 'thread_history_projection_state', 'thread_realtime_items')
TERMINAL = {'task_complete', 'turn_aborted'}
ID_RE = re.compile(r'^[0-9a-f]{8}(?:-[0-9a-f]{4}){3}-[0-9a-f]{12}$', re.I)


class HandoffError(RuntimeError):
    pass


def now():
    return datetime.now(timezone.utc).isoformat()


def checked_id(value):
    if not isinstance(value, str) or not ID_RE.fullmatch(value):
        raise HandoffError('Invalid chat identifier.')
    return value


def norm(value):
    return os.path.normcase(str(value).removeprefix('\\\\?\\')).rstrip('\\/')


def digest(path):
    with Path(path).open('rb') as f:
        return hashlib.file_digest(f, 'sha256').hexdigest()


def atomic_json(path, obj):
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_name(path.name + '.' + uuid.uuid4().hex + '.tmp')
    try:
        tmp.write_text(json.dumps(obj, ensure_ascii=False, indent=2), encoding='utf-8')
        os.replace(tmp, path)
    finally:
        tmp.unlink(missing_ok=True)


def log(message):
    DATA.mkdir(parents=True, exist_ok=True)
    with (DATA / 'activity.log').open('a', encoding='utf-8') as f:
        f.write(now() + ' ' + message + '\n')


@contextlib.contextmanager
def scratch():
    # Inherit the shared folder's ACL. Python 3.14's 0700 temporary-directory
    # ACL excludes the restricted Windows token used by Codex's sandbox.
    parent = DATA / 'scratch'
    parent.mkdir(parents=True, exist_ok=True)
    path = parent / uuid.uuid4().hex
    path.mkdir()
    try:
        yield path
    finally:
        if path.resolve().parent != parent.resolve() or path.is_symlink():
            raise HandoffError('Unsafe scratch cleanup path.')
        shutil.rmtree(path)


def coordinator():
    DATA.mkdir(parents=True, exist_ok=True)
    c = sqlite3.connect(DATA / 'coordination.sqlite', timeout=25)
    c.row_factory = sqlite3.Row
    c.execute('CREATE TABLE IF NOT EXISTS owners (thread_id TEXT PRIMARY KEY, profile TEXT NOT NULL, updated TEXT NOT NULL)')
    c.commit()
    return c


@contextlib.contextmanager
def owned_lock(thread_id, profile, claim=False):
    c = coordinator()
    try:
        c.execute('BEGIN IMMEDIATE')
        row = c.execute('SELECT profile FROM owners WHERE thread_id=?', (thread_id,)).fetchone()
        if row and row[0] != profile:
            raise HandoffError(f'This chat belongs to {row[0]}. Use Continue in other app to hand it back before sending here.')
        if claim:
            c.execute('INSERT INTO owners VALUES (?,?,?) ON CONFLICT(thread_id) DO UPDATE SET updated=excluded.updated', (thread_id, profile, now()))
        yield c
        c.commit()
    except BaseException:
        c.rollback()
        raise
    finally:
        c.close()


@contextlib.contextmanager
def read_db(path):
    """Use SQLite's reader; stable copy fallback only if there is no live WAL."""
    temp = None
    conn = None
    try:
        try:
            conn = sqlite3.connect(path.as_uri() + '?mode=ro', uri=True, timeout=8)
            conn.execute('SELECT count(*) FROM sqlite_master').fetchone()
        except sqlite3.OperationalError:
            if conn is not None:
                conn.close()
            wal = Path(str(path) + '-wal')
            if wal.exists() and wal.stat().st_size:
                raise HandoffError('Cannot read a database with an active write log: ' + path.name)
            temp = scratch()
            copy = temp.__enter__() / path.name
            before = path.stat()
            shutil.copyfile(path, copy)
            after = path.stat()
            if (before.st_size, before.st_mtime_ns) != (after.st_size, after.st_mtime_ns) or (wal.exists() and wal.stat().st_size):
                raise HandoffError('Database changed during the snapshot; retry after the turn finishes.')
            conn = sqlite3.connect(copy)
        conn.row_factory = sqlite3.Row
        conn.execute('BEGIN')
        yield conn
    finally:
        if conn is not None:
            conn.close()
        if temp is not None:
            temp.__exit__(None, None, None)


def table_rows(c, table, where='', args=()):
    return [dict(r) for r in c.execute('SELECT * FROM ' + table + (' WHERE ' + where if where else ''), args)]


def signature(c, table):
    return [(r[1], r[2], r[3], r[5]) for r in c.execute('PRAGMA table_info(' + table + ')')]


def tail_status(path):
    """Use the installed build's persisted lifecycle markers, never a quiet timer."""
    size = path.stat().st_size
    with path.open('rb') as f:
        start = max(0, size - 8 * 1024 * 1024)
        f.seek(start)
        if start:
            f.readline()
        status = None
        for line in f:
            try:
                record = json.loads(line)
            except (ValueError, UnicodeError):
                return None
            payload = record.get('payload', {})
            if record.get('type') == 'event_msg' and payload.get('type') in TERMINAL | {'task_started'}:
                status = (payload['type'], payload.get('turn_id'))
    return status


def snapshot_thread(profile, thread_id, expected_turn=None, offline=False):
    checked_id(thread_id)
    home = PROFILES[profile]
    with owned_lock(thread_id, profile):
        return _snapshot(profile, thread_id, home, expected_turn, offline)


def _snapshot(profile, thread_id, home, expected_turn, offline):
    with read_db(home / 'state_5.sqlite') as state:
        root = state.execute('SELECT * FROM threads WHERE id=?', (thread_id,)).fetchone()
        if not root:
            raise HandoffError('Chat not found in the selected source profile.')
        if root['source'] != 'vscode':
            raise HandoffError('Select a main desktop chat, not a supporting agent record.')
        ids = {thread_id}
        all_edges = table_rows(state, 'thread_spawn_edges')
        while True:
            more = {e['child_thread_id'] for e in all_edges if e['parent_thread_id'] in ids}
            if more <= ids:
                break
            ids |= more
        ids = sorted(ids)
        marks = ','.join('?' for _ in ids)
        threads = table_rows(state, 'threads', f'id IN ({marks})', ids)
        actual_ids = {r['id'] for r in threads}
        if actual_ids != set(ids):
            raise HandoffError('A descendant chat record is missing; no incomplete snapshot was saved.')
        tables = {'threads': threads,
                  'thread_dynamic_tools': table_rows(state, 'thread_dynamic_tools', f'thread_id IN ({marks})', ids),
                  'thread_artifacts': table_rows(state, 'thread_artifacts', f'thread_id IN ({marks})', ids),
                  'thread_spawn_edges': [e for e in all_edges if e['parent_thread_id'] in actual_ids and e['child_thread_id'] in actual_ids]}
        # Older builds kept project assignments in desktop global state. Translate those
        # references into the current project_id column without copying app settings.
        all_projects = table_rows(state, 'projects')
        all_roots = table_rows(state, 'project_roots')
        global_path = home / '.codex-global-state.json'
        glob = json.loads(global_path.read_text(encoding='utf-8')) if global_path.exists() else {}
        legacy = glob.get('app-server-project-id-by-legacy-project-id-by-host', {}).get('local:' + str(home), {})
        roots = sorted(all_roots, key=lambda r: len(r['path']), reverse=True)
        for row in threads:
            if row['project_id'] is None:
                explicit = glob.get('thread-project-assignments', {}).get(row['id'], {}).get('projectId')
                if explicit:
                    row['project_id'] = legacy.get(explicit, explicit)
                else:
                    cwd = norm(row['cwd'])
                    row['project_id'] = next((r['project_id'] for r in roots if cwd == norm(r['path']) or cwd.startswith(norm(r['path']) + '\\')), None)
        pids = {r['project_id'] for r in threads if r['project_id']}
        sections = {r['thread_section_id'] for r in threads if r['thread_section_id']}
        tables.update({'projects': [r for r in all_projects if r['id'] in pids],
                       'project_roots': [r for r in all_roots if r['project_id'] in pids],
                       'project_idempotency_keys': [r for r in table_rows(state, 'project_idempotency_keys') if r['project_id'] in pids],
                       'thread_sections': [r for r in table_rows(state, 'thread_sections') if r['id'] in sections]})
        schema = {t: signature(state, t) for t in STATE_TABLES}
    files = []
    for row in threads:
        path = Path(row['rollout_path'].removeprefix('\\\\?\\'))
        try:
            rel = path.relative_to(home)
        except ValueError:
            raise HandoffError('A transcript points outside its own profile; resolve that before transferring.')
        if rel.parts[0] not in ('sessions', 'archived_sessions') or path.suffix != '.jsonl':
            raise HandoffError('Unexpected transcript location.')
        status = tail_status(path)
        if not offline and (not status or status[0] not in TERMINAL):
            raise HandoffError('The chat or one of its agents has not finished yet.')
        if row['id'] == thread_id and expected_turn and (not status or status[1] != expected_turn):
            raise HandoffError('Waiting for the requested turn to be fully saved.')
        stat = path.stat()
        files.append({'thread_id': row['id'], 'relative_path': rel.as_posix(), 'path': str(path),
                      'size': stat.st_size, 'mtime_ns': stat.st_mtime_ns, 'terminal': status})
    with read_db(home / 'thread_history_1.sqlite') as history:
        for table in HISTORY_TABLES:
            tables[table] = table_rows(history, table, f'thread_id IN ({marks})', ids)
            schema[table] = signature(history, table)
    sizes = {f['thread_id']: f['size'] for f in files}
    for row in tables['thread_history_projection_state']:
        if row['next_rollout_byte_offset'] > sizes[row['thread_id']]:
            raise HandoffError('History projection is ahead of its transcript; retry after it finishes saving.')
    dest = DATA / 'snapshots' / profile / thread_id
    dest.mkdir(parents=True, exist_ok=True)
    stamp = datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%S') + '-' + uuid.uuid4().hex[:8]
    archive = dest / (stamp + '.zip')
    temp = dest / (stamp + '.tmp')
    manifest = {'version': 1, 'source': profile, 'thread_id': thread_id, 'title': root['title'],
                'created': now(), 'source_home': str(home), 'schema': schema, 'tables': tables, 'files': files,
                'offline': offline, 'app_build': '26.908.70816'}
    try:
        with zipfile.ZipFile(temp, 'w', zipfile.ZIP_DEFLATED, compresslevel=3) as z:
            for item in files:
                src = Path(item['path'])
                item['sha256'] = digest(src)
                z.write(src, 'rollouts/' + item['relative_path'])
                stat = src.stat()
                if (stat.st_size, stat.st_mtime_ns) != (item['size'], item['mtime_ns']):
                    raise HandoffError('Transcript changed during snapshot; retry after the turn finishes.')
            z.writestr('manifest.json', json.dumps(manifest, ensure_ascii=False))
        os.replace(temp, archive)
        info = {'source': profile, 'thread_id': thread_id, 'title': root['title'], 'created': manifest['created'],
                'archive': str(archive), 'sha256': digest(archive), 'bytes': archive.stat().st_size}
        atomic_json(dest / 'latest.json', info)
        # Keep two complete immutable snapshots per chat. Never prune transfer backups.
        old = sorted(dest.glob('*.zip'), key=lambda p: p.stat().st_mtime, reverse=True)
        for path in old[2:]:
            if path.resolve().parent != dest.resolve():
                raise HandoffError('Unsafe snapshot cleanup path.')
            path.unlink()
        log(f'Snapshot saved: {profile} {thread_id}')
        return info
    finally:
        temp.unlink(missing_ok=True)








def backup_db(src, dst):
    dst.parent.mkdir(parents=True, exist_ok=True)
    with read_db(src) as c, contextlib.closing(sqlite3.connect(dst)) as out:
        c.backup(out)


def prefix_relation(old, new):
    """Never choose a winner from timestamps. Only allow an identical/extended log."""
    if not old.exists():
        return 'new'
    with old.open('rb') as a, new.open('rb') as b:
        while True:
            x, y = a.read(1024 * 1024), b.read(1024 * 1024)
            if x == y:
                if not x:
                    return 'same'
                continue
            if not x:
                return 'extends'
            if y.startswith(x) and len(x) < 1024 * 1024 and not a.read(1):
                return 'extends'
            return 'conflict'


def load_package(info, staging):
    archive = Path(info['archive'])
    if digest(archive) != info['sha256']:
        raise HandoffError('Snapshot checksum failed. No history was changed.')
    with zipfile.ZipFile(archive) as z:
        manifest = json.loads(z.read('manifest.json'))
        if manifest['version'] != 1 or manifest['thread_id'] != info['thread_id'] or manifest['source'] != info['source']:
            raise HandoffError('Snapshot identity/version mismatch.')
        if set(manifest['tables']) != set(STATE_TABLES + HISTORY_TABLES):
            raise HandoffError('Unexpected snapshot tables.')
        for item in manifest['files']:
            checked_id(item['thread_id'])
            rel = Path(item['relative_path'])
            if rel.is_absolute() or '..' in rel.parts or rel.parts[0] not in ('sessions', 'archived_sessions') or rel.suffix != '.jsonl':
                raise HandoffError('Unsafe transcript path in snapshot.')
            out = staging / rel
            out.parent.mkdir(parents=True, exist_ok=True)
            with z.open('rollouts/' + rel.as_posix()) as src, out.open('wb') as dst:
                shutil.copyfileobj(src, dst)
            if out.stat().st_size != item['size'] or digest(out) != item['sha256']:
                raise HandoffError('Transcript checksum failed.')
    return manifest


def insert_rows(c, db, table, rows, replace=False):
    columns = [r[1] for r in c.execute('PRAGMA ' + db + '.table_info(' + table + ')')]
    keys = [r[1] for r in sorted(c.execute('PRAGMA ' + db + '.table_info(' + table + ')').fetchall(), key=lambda r: r[5]) if r[5]]
    for row in rows:
        if list(row) != columns:
            raise HandoffError('Database columns changed: ' + table)
        sql = 'INSERT INTO ' + db + '.' + table + ' (' + ','.join(columns) + ') VALUES (' + ','.join('?' for _ in columns) + ') ON CONFLICT (' + ','.join(keys) + ') DO '
        updates = [col + '=excluded.' + col for col in columns if col not in keys]
        sql += 'UPDATE SET ' + ','.join(updates) if replace and updates else 'NOTHING'
        c.execute(sql, list(row.values()))


















