"""Isolated launch/setup checks; never create users, change live ACLs, or use real passwords."""
import copy
import ctypes
import json
import os
from pathlib import Path
import tempfile
from types import SimpleNamespace
import unittest
from unittest.mock import Mock,patch
import windows_launch as launch
import setup_support as setup


def error(code):
    value=OSError('simulated Windows error');value.winerror=code;return value


class LaunchTests(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory();self.addCleanup(self.tmp.cleanup);self.root=Path(self.tmp.name)
        self.app=self.root/'ChatGPT.exe';self.app.write_bytes(b'synthetic')
        self.profile={'account':r'PC\Target','home':str(self.root/'home'),'app':str(self.app)}
        for name,kwargs in [('canonical',{'side_effect':lambda a:a}),('current_account',{'return_value':r'PC\Target'}),
                            ('elevated',{'return_value':False})]:
            p=patch.object(launch,name,**kwargs);p.start();self.addCleanup(p.stop)

    def test_same_user_needs_no_password(self):
        with patch.object(launch,'start_standard_app',return_value={'pid':17,'ready':'visible-window'}),patch.object(launch,'prompt_credential') as prompt:
            self.assertEqual(launch.account_action(self.profile,self.root)['pid'],17)
            prompt.assert_not_called()

    def test_invalid_password_does_not_grant_desktop_access(self):
        with launch.Secret() as secret,patch.object(launch,'verify_credential',side_effect=error(1326)), \
             patch.object(launch,'allow_desktop_access') as access,patch.object(launch,'native') as native:
            with self.assertRaises(OSError):launch.spawn_account_helper(r'PC\Target',secret,['pythonw.exe'])
            access.assert_not_called();native.assert_not_called()

    def test_desktop_permission_failure_stops_before_helper_creation(self):
        with launch.Secret() as secret,patch.object(launch,'verify_credential'), \
             patch.object(launch,'allow_desktop_access',side_effect=launch.LaunchError('desktop access')), \
             patch.object(launch,'native') as native:
            with self.assertRaisesRegex(launch.LaunchError,'desktop access'):
                launch.spawn_account_helper(r'PC\Target',secret,['pythonw.exe'])
            native.assert_not_called()

    def test_headless_missing_credential_stops_without_prompt(self):
        with patch.object(launch,'current_account',return_value=r'PC\Other'),patch.object(launch,'read_credential',return_value=None), \
             patch.object(launch,'prompt_credential') as prompt,patch.object(Path,'is_file',return_value=True):
            with self.assertRaisesRegex(launch.LaunchError,'No saved Windows password'):
                launch.account_action(self.profile,self.root,allow_prompt=False)
            prompt.assert_not_called()

    def fake_spawn(self,account,secret,command):
        self.assertNotIn('synthetic-password',repr(command))
        report=Path(command[command.index('--report')+1])
        report.write_text(json.dumps({'ok':True,'result':{'account':account,'elevated':False,'pid':18}}))

    def test_saved_password_opens_other_account_without_prompt_and_is_zeroed(self):
        secret=launch.Secret();secret.buffer.value='synthetic-password'
        with patch.object(launch,'current_account',return_value=r'PC\Other'),patch.object(launch,'read_credential',return_value=secret), \
             patch.object(launch,'spawn_account_helper',side_effect=self.fake_spawn),patch.object(launch,'prompt_credential') as prompt, \
             patch.object(Path,'is_file',return_value=True):
            self.assertEqual(launch.account_action(self.profile,self.root)['pid'],18)
            prompt.assert_not_called()
        self.assertEqual(secret.buffer.value,'')

    def test_elevated_current_user_also_takes_authenticated_route(self):
        secret=launch.Secret();secret.buffer.value='synthetic-password'
        with patch.object(launch,'elevated',return_value=True),patch.object(launch,'read_credential',return_value=secret), \
             patch.object(launch,'spawn_account_helper',side_effect=self.fake_spawn),patch.object(Path,'is_file',return_value=True), \
             patch.object(launch,'start_standard_app') as direct:
            self.assertEqual(launch.account_action(self.profile,self.root)['pid'],18)
            direct.assert_not_called()

    def test_wrong_password_is_not_saved_and_buffer_is_zeroed(self):
        secret=launch.Secret();secret.buffer.value='synthetic-password';secret.remember=True
        with patch.object(launch,'current_account',return_value=r'PC\Other'),patch.object(launch,'read_credential',return_value=secret), \
             patch.object(launch,'spawn_account_helper',side_effect=error(1326)),patch.object(launch,'save_credential') as save, \
             patch.object(Path,'is_file',return_value=True):
            with self.assertRaisesRegex(launch.LaunchError,'Windows sign-in failed'):
                launch.account_action(self.profile,self.root)
            save.assert_not_called()
        self.assertEqual(secret.buffer.value,'')

    def test_opt_in_save_occurs_only_after_windows_accepts_login(self):
        secret=launch.Secret();secret.remember=True;order=[]
        def spawn(*args):order.append('authenticated');self.fake_spawn(*args)
        with patch.object(launch,'current_account',return_value=r'PC\Other'),patch.object(launch,'read_credential',return_value=secret), \
             patch.object(launch,'spawn_account_helper',side_effect=spawn),patch.object(launch,'save_credential',side_effect=lambda *a:order.append('saved')), \
             patch.object(Path,'is_file',return_value=True):
            launch.account_action(self.profile,self.root)
        self.assertEqual(order,['authenticated','saved'])

    def test_mismatched_helper_identity_is_rejected(self):
        secret=launch.Secret()
        def spawn(account,password,command):self.fake_spawn(r'PC\Wrong',password,command)
        with patch.object(launch,'current_account',return_value=r'PC\Other'),patch.object(launch,'read_credential',return_value=secret), \
             patch.object(launch,'spawn_account_helper',side_effect=spawn),patch.object(Path,'is_file',return_value=True):
            with self.assertRaisesRegex(launch.LaunchError,'identity/privilege'):
                launch.account_action(self.profile,self.root)

    def test_launch_environment_is_local_and_does_not_inherit_admin_compatibility(self):
        with patch.dict(os.environ,{'__COMPAT_LAYER':'RUNASADMIN','CODEX_HOME':'wrong'}):
            env=launch.standard_environment('chosen')
            self.assertNotIn('__COMPAT_LAYER',env);self.assertEqual(env['CODEX_HOME'],'chosen')
            self.assertEqual(os.environ['__COMPAT_LAYER'],'RUNASADMIN')

    def kernel(self):
        k=SimpleNamespace(CreateProcessW=Mock(),ResumeThread=Mock(return_value=0),
                          TerminateProcess=Mock(),CloseHandle=Mock())
        def create(*args):
            p=args[-1]._obj;p.hProcess=11;p.hThread=12;p.dwProcessId=13;return 1
        k.CreateProcessW.side_effect=create
        return k

    def test_elevated_app_is_terminated_while_still_suspended(self):
        k=self.kernel()
        with patch.object(launch,'native',return_value=(k,None)),patch.object(launch,'check_existing_apps'), \
             patch.object(launch,'require_standard',side_effect=[None,launch.LaunchError('elevated')]):
            with self.assertRaisesRegex(launch.LaunchError,'elevated'):launch.start_standard_app(self.app,self.root)
        self.assertTrue(k.CreateProcessW.call_args.args[5]&4)
        k.ResumeThread.assert_not_called();k.TerminateProcess.assert_called_once_with(11,1)

    def test_failed_token_check_does_not_resume_the_app(self):
        k=self.kernel()
        with patch.object(launch,'native',return_value=(k,None)),patch.object(launch,'check_existing_apps'), \
             patch.object(launch,'require_standard',side_effect=[None,error(5)]):
            with self.assertRaises(OSError):launch.start_standard_app(self.app,self.root)
        k.ResumeThread.assert_not_called();k.TerminateProcess.assert_called_once()

    def test_elevation_required_never_invokes_shell_uac_fallback(self):
        k=self.kernel()
        def create(*args):ctypes.set_last_error(740);return 0
        k.CreateProcessW.side_effect=create
        with patch.object(launch,'native',return_value=(k,None)),patch.object(launch,'check_existing_apps'), \
             patch.object(launch,'require_standard'),patch.object(os,'startfile') as shell:
            with self.assertRaisesRegex(launch.LaunchError,'No UAC fallback'):launch.start_standard_app(self.app,self.root)
            shell.assert_not_called()

    def test_missing_app_never_reaches_process_creation(self):
        with patch.object(launch,'require_standard'),patch.object(launch,'native') as native:
            with self.assertRaisesRegex(launch.LaunchError,'missing'):launch.start_standard_app(self.root/'missing.exe',self.root)
            native.assert_not_called()

    def test_existing_elevated_instance_blocks_reopening(self):
        with patch.object(launch,'check_existing_apps',side_effect=launch.LaunchError('Quit that app')), \
             patch.object(launch,'require_standard'),patch.object(launch,'native') as native:
            with self.assertRaisesRegex(launch.LaunchError,'Quit that app'):launch.start_standard_app(self.app,self.root)
            native.assert_not_called()


class SetupTests(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory();self.addCleanup(self.tmp.cleanup);self.root=Path(self.tmp.name)
        app=self.root/'ChatGPT.exe';app.write_bytes(b'synthetic')
        computer=os.environ['COMPUTERNAME']
        self.plan={'config':{'version':1,'shared_folder':str(self.root/'shared'),'profiles':[
            {'name':n,'account':computer+'\\'+n,'home':str(self.root/n/'.codex'),'app':str(app)} for n in ('Left','Right')]},
            'create_missing':False,'automatic_homes':[True,True],'program':str(Path(setup.__file__).parent)}
        p=patch.object(setup,'profile_home',side_effect=lambda a:self.root/a.rsplit('\\',1)[-1]);p.start();self.addCleanup(p.stop)
        p=patch.object(launch,'allow_desktop_access');p.start();self.addCleanup(p.stop)

    def test_missing_accounts_require_explicit_creation_choice(self):
        with patch.object(setup,'profile_home',side_effect=error(1332)):
            with self.assertRaises(OSError):setup.validate_plan(copy.deepcopy(self.plan))
            plan=copy.deepcopy(self.plan);plan['create_missing']=True
            setup.validate_plan(plan)

    def test_domain_accounts_use_manual_setup(self):
        self.plan['config']['profiles'][0]['account']=r'DOMAIN\Left'
        with self.assertRaisesRegex(ValueError,'local accounts'):setup.validate_plan(self.plan)

    def test_system_root_cannot_be_permission_target(self):
        for path in (Path(self.root.anchor),Path(os.environ['SystemRoot']),Path.home()):
            with self.assertRaises(ValueError):setup.safe_folder(path)

    def test_windows_profile_root_cannot_be_codex_home(self):
        self.plan['config']['profiles'][0]['home']=str(self.root/'Left')
        with self.assertRaisesRegex(ValueError,'profile root'):setup.validate_plan(self.plan)

    def test_linked_ancestor_is_rejected_before_resolution(self):
        target=self.root/'junction'/'data'
        with patch.object(setup,'linked',side_effect=lambda p:Path(p).name=='junction'):
            with self.assertRaisesRegex(ValueError,'linked path'):setup.safe_folder(target)

    def test_missing_app_fails_before_any_account_changes(self):
        self.plan['config']['profiles'][0]['app']=str(self.root/'missing.exe')
        with patch.object(setup,'create_local_user') as create:
            with self.assertRaisesRegex(ValueError,'installed app'):setup.apply_plan(self.plan,self.root,[])
            create.assert_not_called()

    def test_admin_setup_refuses_normal_token(self):
        with patch.object(launch,'elevated',return_value=False),patch.object(setup,'create_local_user') as create:
            with self.assertRaisesRegex(RuntimeError,'Administrator approval'):setup.apply_plan(self.plan,self.root,[])
            create.assert_not_called()

    def test_existing_accounts_are_not_recreated_and_actual_home_is_used(self):
        events=[]
        with patch.object(launch,'elevated',return_value=True),patch.object(setup,'account_sid',return_value='S-1-5-21-123'), \
             patch.object(setup,'initialize_profile',side_effect=lambda a:self.root/('real-'+a.rsplit('\\',1)[-1])), \
             patch.object(setup,'create_local_user') as create,patch.object(setup,'grant_access') as grant:
            result=setup.apply_plan(self.plan,self.root,events)
            create.assert_not_called();self.assertTrue(grant.called)
            self.assertEqual(result['profiles'][0]['home'],str(self.root/'real-Left'/'.codex'))

    def test_custom_home_is_preserved(self):
        self.plan['automatic_homes']=[False,False];expected=copy.deepcopy(self.plan['config']['profiles'])
        with patch.object(launch,'elevated',return_value=True),patch.object(setup,'account_sid',return_value='S-1-5-21-123'), \
             patch.object(setup,'initialize_profile',return_value=self.root/'windows-assigned'),patch.object(setup,'grant_access'):
            result=setup.apply_plan(self.plan,self.root,[])
            self.assertEqual(result['profiles'],expected)

    def test_permissions_are_not_written_if_backup_fails(self):
        folder=self.root/'permissions-target';folder.mkdir();backup=self.root/'backups';backup.mkdir()
        failure=SimpleNamespace(returncode=1,stdout=b'',stderr=b'backup refused')
        with patch.object(setup.subprocess,'run',return_value=failure) as run:
            with self.assertRaisesRegex(RuntimeError,'back up'):setup.grant_access(folder,['S-1-5-21-123'],'M',backup,0,[])
            self.assertEqual(run.call_count,1)

    def test_partial_acl_failure_is_recorded_with_backup(self):
        folder=self.root/'target';folder.mkdir();backup=self.root/'backup';backup.mkdir();events=[]
        with patch.object(setup.subprocess,'run',side_effect=[SimpleNamespace(returncode=0,stdout=b'ok',stderr=b''),
                SimpleNamespace(returncode=1,stdout=b'partial',stderr=b'access denied')]):
            with self.assertRaisesRegex(RuntimeError,'incomplete'):setup.grant_access(folder,['S-1-5-21-123'],'M',backup,0,events)
        self.assertEqual(events[0]['exit_code'],1);self.assertTrue((backup/'0-grant.log').exists())

    def test_modified_review_request_is_rejected_before_apply(self):
        request=self.root/'request.json';request.write_text(json.dumps(self.plan));report=self.root/'result.json'
        with patch.object(setup.sys,'argv',['setup_support.py','--apply',str(request),'wrong',str(report)]), \
             patch.object(setup,'apply_plan') as apply:
            setup.admin_main();apply.assert_not_called()
        self.assertFalse(json.loads(report.read_text())['ok'])


if __name__=='__main__':
    unittest.main(verbosity=2)
