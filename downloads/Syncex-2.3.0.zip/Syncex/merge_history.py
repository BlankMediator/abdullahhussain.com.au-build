"""Reviewed, journaled history rewrites. Original branches remain in pinned ZIPs.

Turns retain their internal record order. A stable topological sort preserves
each branch's order, using timestamps only between independent turns. Divergent
versions of the SAME turn remain separately labelled variants, never fabricated
into a single original answer. No model requests or tool calls are executed.
"""
import copy
from datetime import datetime, timezone
import hashlib
import heapq
import json
from pathlib import Path
import shutil
import sqlite3
import time
import uuid
import zipfile
import handoff as h
import history_chain as chain
import sync_latest as latest
import sync_live as live
import conflict_choices as choices
import repair_sidebar as sidebar


def canonical(value):
    return json.dumps(value, sort_keys=True, ensure_ascii=False, separators=(',', ':'))


def stamp(value):
    try:
        return datetime.fromisoformat(value.replace('Z', '+00:00')).timestamp()
    except (ValueError, AttributeError, TypeError):
        return None


def read_views(root):
    indexes = {p: latest.index(p) for p in latest.PROFILES}
    ids = set().union(*(latest.descendants(root, e) for _, e in indexes.values()))
    if not any(root in rows and rows[root]['source'] == 'vscode' for rows, _ in indexes.values()):
        raise h.HandoffError('Select an existing desktop task.')
    views = {p: latest.view(p, ids, *indexes[p]) for p in latest.PROFILES}
    if any(root not in v['rows'] and v['rows'] for v in views.values()):
        raise live.Deferred('A profile has supporting tasks without their main task. Repair that task group before rewriting.')
    if not ids <= set().union(*(v['rows'] for v in views.values())):
        raise live.Deferred('A supporting task is missing. Finish its work and retry.')
    return ids, views


def records(view, owner):
    layout = view['layouts'][owner]
    for n in reversed(range(len(layout))):
        part = layout[n]
        limit = part['size'] if n == 0 else layout[n-1]['history_base']['end_byte_offset']
        ordinal = (part.get('history_base') or {}).get('end_ordinal_exclusive', 0)
        with Path(part['path']).open('rb') as stream:
            while stream.tell() < limit:
                offset = stream.tell()
                raw = stream.readline(limit - offset)
                record = json.loads(raw)
                yield {'record': record, 'key': (view['profile'], part['thread_id'], ordinal),
                       'path': part['path'], 'offset': offset, 'length': len(raw)}
                ordinal += 1


def branch_turns(view, owner):
    turns, header, pending, current = [], None, [], None
    by_turn = {}
    for ref in records(view, owner):
        record = ref.pop('record')
        payload = record.get('payload', {})
        kind = record.get('type')
        if kind == 'session_meta':
            header = header or record
            continue
        # A compaction resets the model's prior context. Replaying that reset
        # after merging would hide messages. Keep it in the original backups;
        # the rewritten transcript retains the complete pre-compaction history.
        if kind == 'compacted':
            continue
        if kind == 'event_msg' and payload.get('type') == 'task_started':
            current = {'id': payload['turn_id'], 'refs': pending, 'profile': view['profile'],
                       'timestamp': stamp(record.get('timestamp')), 'aliases': []}
            pending = []
            turns.append(current)
            by_turn[current['id']] = current
        ref['hash'] = hashlib.sha256(canonical({k: v for k, v in record.items() if k not in ('timestamp', 'ordinal')}).encode()).hexdigest()
        ref['time'] = stamp(record.get('timestamp'))
        recipient = by_turn.get(payload.get('turn_id'), current) if kind == 'event_msg' and payload.get('type') == 'item_completed' else current
        if recipient is None:
            pending.append(ref)
        else:
            recipient['refs'].append(ref)
    if pending:
        # Old files without task_started cannot be indexed unambiguously.
        raise h.HandoffError('This history has messages outside a recorded turn. It needs manual review; no rewrite was made.')
    for turn in turns:
        turn['hashes'] = [r['hash'] for r in turn['refs']]
        turn['key'] = turn['id'] + ':' + hashlib.sha256(''.join(turn['hashes']).encode()).hexdigest()
    return header, turns


def ordered_turns(branches):
    nodes, sequences, warnings = {}, [], []
    by_id = {}
    for profile, turns in branches.items():
        sequence = []
        for turn in turns:
            candidates = by_id.setdefault(turn['id'], [])
            matched = next((old for old in candidates if old['hashes'] == turn['hashes']), None)
            if matched is None:
                candidates.append(turn)
                nodes[turn['key']] = turn
                matched = turn
            else:
                matched['aliases'].append(turn)
            sequence.append(matched['key'])
        sequences.append(sequence)
    edges = {key: set() for key in nodes}
    indegree = {key: 0 for key in nodes}
    for seq in sequences:
        for a, b in zip(seq, seq[1:]):
            if a != b and b not in edges[a]:
                edges[a].add(b)
                indegree[b] += 1
    def priority(key):
        t = nodes[key]
        return (t['timestamp'] if t['timestamp'] is not None else float('-inf'), t['profile'], key)
    ready = [priority(k) for k, n in indegree.items() if n == 0]
    heapq.heapify(ready)
    result = []
    while ready:
        _, _, key = heapq.heappop(ready)
        result.append(nodes[key])
        for child in edges[key]:
            indegree[child] -= 1
            if indegree[child] == 0:
                heapq.heappush(ready, priority(child))
    if len(result) != len(nodes):
        raise h.HandoffError('The branches disagree about turn order. No automatic rewrite is possible without choosing an order manually.')
    for tid, variants in by_id.items():
        if len(variants) > 1:
            warnings.append('Turn ' + tid + ' has different versions. Both are retained as separate turns; shared text within those variants may repeat.')
            for t in variants:
                t['variant'] = True
    times = [t['timestamp'] for t in result]
    if None in times or len(times) != len(set(times)):
        warnings.append('Some start times are missing or equal. Branch order is preserved; ties use a stable profile/ID order. Review the preview.')
    return result, warnings


def preview(root, progress=lambda text: None):
    ids, views = read_views(root)
    result = {'id': root, 'tokens': {p: choices.fingerprint(v) for p, v in views.items()}, 'tasks': [], 'warnings': []}
    for owner in sorted(ids):
        progress('Preparing merge preview for ' + owner)
        branches = {p: branch_turns(v, owner)[1] for p, v in views.items() if owner in v['rows']}
        turns, warnings = ordered_turns(branches)
        item = {'id': owner, 'turns': []}
        for t in turns:
            excerpt = ''
            for ref in t['refs']:
                with Path(ref['path']).open('rb') as f:
                    f.seek(ref['offset']); r = json.loads(f.read(ref['length']))
                p = r.get('payload', {})
                if r.get('type') == 'response_item' and p.get('type') == 'message' and p.get('role') in ('user', 'assistant'):
                    content = p.get('content', [])
                    excerpt = '\n'.join(x.get('text', '') for x in content if isinstance(x, dict)) if isinstance(content, list) else str(content)
                    if excerpt.strip(): break
            item['turns'].append({'id': t['id'], 'key': t['key'], 'profile': t['profile'], 'timestamp': t['timestamp'],
                                  'variant': t.get('variant', False), 'excerpt': excerpt[:600]})
        result['tasks'].append(item)
        result['warnings'].extend(warnings)
    result['title'] = max((v['metadata'][root] for v in views.values() if root in v['rows']), key=latest.version)['name']
    return result


def pin(profile, root, view, directory):
    if root in view['rows']:
        return choices.pin_snapshot(profile, root, view, directory)
    # No task on this side is itself an important precondition.
    info = {'absent': True, 'profile': profile, 'thread_id': root, 'token': choices.fingerprint(view)}
    h.atomic_json(directory / (profile + '.json'), info)
    return info


def copy_attachments(paths, directory):
    result = []
    for value in paths:
        source = Path(value).resolve(strict=True)
        if not source.is_file():
            raise h.HandoffError('Select individual files, not directories.')
        before = (source.stat().st_size, source.stat().st_mtime_ns)
        digest = h.digest(source)
        dest = directory / 'attachments' / digest / source.name
        dest.parent.mkdir(parents=True, exist_ok=True)
        shutil.copyfile(source, dest)
        if h.digest(dest) != digest or before != (source.stat().st_size, source.stat().st_mtime_ns):
            raise live.Deferred('A selected attachment changed while being copied. Retry the preview.')
        result.append({'name': source.name, 'path': str(dest), 'sha256': digest, 'bytes': before[0]})
    return result


def rewrite_ids(value, mapping):
    if isinstance(value, list):
        return [rewrite_ids(v, mapping) for v in value]
    if not isinstance(value, dict):
        return value
    return {k: mapping.get(v, v) if k in ('id', 'turn_id', 'turnId', 'call_id', 'callId', 'item_id', 'itemId') and isinstance(v, str)
            else rewrite_ids(v, mapping) for k, v in value.items()}


def generate_owner(owner, views, directory, note, import_id):
    variants = {p: branch_turns(v, owner) for p, v in views.items() if owner in v['rows']}
    turns, warnings = ordered_turns({p: v[1] for p, v in variants.items()})
    newest = max((v['rows'][owner] for v in views.values() if owner in v['rows']), key=latest.version)
    header = next((v[0] for v in variants.values() if v[0]), None)
    if header is None:
        raise h.HandoffError('Missing session metadata. This history format cannot be rewritten safely.')
    header = copy.deepcopy(header)
    header['payload'].update(id=owner, history_mode='paginated')
    header['payload'].pop('history_base', None)
    storage = str(uuid.uuid4())
    created = datetime.now(timezone.utc)
    rel = created.strftime('sessions/%Y/%m/%d/rollout-%Y-%m-%dT%H-%M-%S-') + storage + '.jsonl'
    path = directory / rel
    path.parent.mkdir(parents=True, exist_ok=True)
    tables = {t: [] for t in h.HISTORY_TABLES}
    provenance = []
    covered_items = set()
    ordinal = 0
    with path.open('wb') as out:
        def write(record):
            nonlocal ordinal
            n, offset = ordinal, out.tell()
            record = dict(record, ordinal=ordinal)
            out.write((json.dumps(record, ensure_ascii=False, separators=(',', ':')) + '\n').encode('utf-8'))
            ordinal += 1
            return n, offset
        write(header)
        for t in turns:
            start_n, start_offset = ordinal, out.tell()
            new_turn = str(uuid.uuid5(uuid.UUID(import_id), owner + t['key'])) if t.get('variant') else t['id']
            mapping = {t['id']: new_turn}
            if t.get('variant'):
                # Namespace variant IDs to keep function calls and indexed items distinct.
                for ref in t['refs']:
                    with Path(ref['path']).open('rb') as src:
                        src.seek(ref['offset']); record = json.loads(src.read(ref['length']))
                    payload = record.get('payload', {})
                    for k in ('id', 'call_id'):
                        if isinstance(payload.get(k), str):
                            mapping.setdefault(payload[k], str(uuid.uuid5(uuid.UUID(import_id), t['key'] + payload[k])))
                for v in views.values():
                    for row in v['history']['thread_items']:
                        if row['turn_id'] == t['id']:
                            mapping.setdefault(row['item_id'], str(uuid.uuid5(uuid.UUID(import_id), t['key'] + row['item_id'])))
            positions = {}
            variant_note = None
            for ref in t['refs']:
                with Path(ref['path']).open('rb') as src:
                    src.seek(ref['offset']); record = json.loads(src.read(ref['length']))
                positions[ref['key']] = write(rewrite_ids(record, mapping))
                if t.get('variant') and record.get('type') == 'event_msg' and record.get('payload', {}).get('type') == 'task_started':
                    label = ('[Imported variant by Syncex] This version of turn ' + t['id'] + ' came from ' + t['profile'] +
                             '. Another version is retained separately. Any repeated prompt belongs to the original branch.')
                    iid = str(uuid.uuid4())
                    write({'type': 'response_item', 'timestamp': record.get('timestamp') or h.now(),
                                  'payload': {'type': 'message', 'id': iid, 'role': 'user', 'content': [{'type': 'input_text', 'text': label}]}})
                    note_ms = int((t['timestamp'] or time.time()) * 1000)
                    n, _ = write({'type': 'event_msg', 'timestamp': record.get('timestamp') or h.now(), 'payload': {
                        'type': 'item_completed', 'thread_id': owner, 'turn_id': new_turn,
                        'item': {'type': 'UserMessage', 'id': iid, 'client_id': None, 'content': [{'type': 'text', 'text': label, 'text_elements': []}]},
                        'started_at_ms': note_ms, 'completed_at_ms': note_ms}})
                    variant_note = {'thread_id': storage, 'turn_id': new_turn, 'item_id': iid, 'rollout_ordinal': n,
                        'created_at_ms': int((t['timestamp'] or time.time()) * 1000), 'item_type': 'userMessage', 'updated_at_ordinal': n,
                        'item_json': json.dumps({'type': 'userMessage', 'id': iid, 'content': [{'type': 'text', 'text': label, 'text_elements': []}]})}
            for alias in t['aliases']:
                for a, b in zip(alias['refs'], t['refs']):
                    positions[a['key']] = positions[b['key']]
            end_n, end_offset = ordinal, out.tell()
            seen_items = {}
            candidates = []
            for profile, v in views.items():
                if owner not in v['rows']: continue
                storages = {p['thread_id'] for p in v['layouts'][owner]}
                for row in v['history']['thread_turns']:
                    if row['thread_id'] in storages and row['turn_id'] == t['id'] and (profile, row['thread_id'], row['rollout_ordinal']) in positions:
                        candidates.append(row)
                for row in v['history']['thread_items']:
                    key = (profile, row['thread_id'], row['rollout_ordinal'])
                    if row['turn_id'] != t['id'] or key not in positions: continue
                    covered_items.add((profile, row['thread_id'], row['turn_id'], row['item_id']))
                    data = copy.deepcopy(row)
                    data.update(thread_id=storage, turn_id=new_turn, item_id=mapping.get(row['item_id'], row['item_id']),
                                rollout_ordinal=positions[key][0])
                    data['updated_at_ordinal'] = positions.get((profile, row['thread_id'], row['updated_at_ordinal']), positions[key])[0]
                    data['item_json'] = json.dumps(rewrite_ids(json.loads(data['item_json']), mapping), ensure_ascii=False)
                    old = seen_items.get(data['item_id'])
                    if old and json.loads(old['item_json']) != json.loads(data['item_json']):
                        raise h.HandoffError('Identical raw turns have conflicting indexed items. No rewrite was applied.')
                    seen_items[data['item_id']] = data
            if not candidates:
                raise h.HandoffError('A turn is missing from its history index. Reopen its source app and rescan.')
            turn_row = copy.deepcopy(max(candidates, key=lambda r: r.get('completed_at') or 0))
            turn_row.update(thread_id=storage, turn_id=new_turn, rollout_ordinal=start_n, rollout_byte_offset=start_offset,
                            rollout_end_ordinal=end_n, rollout_end_byte_offset=end_offset)
            for key in ('first_user_item_id', 'final_agent_item_id'):
                turn_row[key] = mapping.get(turn_row.get(key), turn_row.get(key))
                if turn_row[key] not in seen_items: turn_row[key] = None
            if variant_note:
                turn_row['first_user_item_id'] = variant_note['item_id']
                tables['thread_items'].append(variant_note)
            tables['thread_turns'].append(turn_row)
            tables['thread_items'].extend(seen_items.values())
            provenance.append({'original_turn': t['id'], 'merged_turn': new_turn, 'profile': t['profile'],
                               'timestamp': t['timestamp'], 'variant': t.get('variant', False)})
        # A clearly labelled user context note records provenance and any added material.
        when = h.now(); seconds = int(time.time()); ms = int(time.time() * 1000)
        tid, iid = str(uuid.uuid4()), str(uuid.uuid4())
        n, offset = write({'timestamp': when, 'type': 'event_msg', 'payload': {'type': 'task_started', 'turn_id': tid, 'started_at': seconds}})
        write({'timestamp': when, 'type': 'response_item', 'payload': {'type': 'message', 'id': iid, 'role': 'user',
                            'content': [{'type': 'input_text', 'text': note}]}})
        item_n, _ = write({'timestamp': when, 'type': 'event_msg', 'payload': {'type': 'item_completed', 'thread_id': owner, 'turn_id': tid,
            'item': {'type': 'UserMessage', 'id': iid, 'client_id': None, 'content': [{'type': 'text', 'text': note, 'text_elements': []}]},
            'started_at_ms': ms, 'completed_at_ms': ms}})
        write({'timestamp': when, 'type': 'event_msg', 'payload': {'type': 'task_complete', 'turn_id': tid, 'last_agent_message': None,
                                                                'started_at': seconds, 'completed_at': seconds, 'duration_ms': 0}})
        tables['thread_turns'].append({'thread_id': storage, 'turn_id': tid, 'rollout_ordinal': n, 'status': 'completed', 'error_json': None,
            'started_at': seconds, 'completed_at': seconds, 'duration_ms': 0, 'first_user_item_id': iid, 'final_agent_item_id': None,
            'rollout_byte_offset': offset, 'rollout_end_ordinal': ordinal, 'rollout_end_byte_offset': out.tell()})
        tables['thread_items'].append({'thread_id': storage, 'turn_id': tid, 'item_id': iid, 'rollout_ordinal': item_n,
            'created_at_ms': ms, 'item_type': 'userMessage', 'updated_at_ordinal': item_n,
            'item_json': json.dumps({'type': 'userMessage', 'id': iid, 'content': [{'type': 'text', 'text': note, 'text_elements': []}]}, ensure_ascii=False)})
    tables['thread_history_projection_state'] = [{'thread_id': storage, 'next_rollout_byte_offset': path.stat().st_size, 'next_rollout_ordinal': ordinal}]
    # Realtime entries do not have turn IDs; rebase only entries actually visible.
    # They need a dedicated merge implementation instead of silently losing audio.
    for v in views.values():
        storages = {f['thread_id'] for f in v['layouts'].get(owner, [])}
        if any(r['thread_id'] in storages for r in v['history']['thread_realtime_items']):
            raise h.HandoffError('This task contains realtime/audio entries. Rewriting that format is not supported; use a branch choice instead.')
        bounds = {}
        layout = v['layouts'].get(owner, [])
        for n, part in enumerate(layout):
            start = (part.get('history_base') or {}).get('end_ordinal_exclusive', 0)
            end = layout[n-1]['history_base']['end_ordinal_exclusive'] if n else start + chain.prefix_lines(Path(part['path']), part['size'])
            bounds[part['thread_id']] = (start, end)
        for row in v['history']['thread_items']:
            limits = bounds.get(row['thread_id'])
            if limits and limits[0] <= row['rollout_ordinal'] < limits[1]:
                key = (v['profile'], row['thread_id'], row['turn_id'], row['item_id'])
                if key not in covered_items and row['item_type'] not in ('contextCompaction', 'context_compaction'):
                    raise h.HandoffError('An indexed item could not be retained in its visible turn. No rewrite was applied: ' + row['item_type'])
    row = copy.deepcopy(newest)
    row.update(rollout_path=str(path), updated_at=seconds, updated_at_ms=ms, history_mode='paginated')
    item = {'thread_id': storage, 'owner_thread_id': owner, 'active': True, 'relative_path': rel, 'path': str(path),
            'size': path.stat().st_size, 'mtime_ns': path.stat().st_mtime_ns, 'sha256': h.digest(path), 'history_base': None,
            'terminal': ['task_complete', tid]}
    return row, item, tables, provenance, warnings


def prepare(review, text='', files=(), progress=lambda text: None):
    """Save a self-contained proposal and both originals. Never modify profiles."""
    latest.pending_recovery()
    root = h.checked_id(review['id'])
    ordering = review.get('ordering', 'turns')
    if ordering not in ('turns', 'messages'):
        raise h.HandoffError('Unknown merge ordering.')
    ids, views = read_views(root)
    if {p: choices.fingerprint(v) for p, v in views.items()} != review['tokens']:
        raise live.Deferred('A task changed since preview. Rescan before preparing this merge.')
    import_id = str(uuid.uuid4())
    directory = h.ROOT / 'rewrites' / import_id
    directory.mkdir(parents=True)
    backups = {p: pin(p, root, v, directory) for p, v in views.items()}
    attachments = copy_attachments(files, directory)
    plans = {}
    for p, info in backups.items():
        if not info.get('absent'):
            with h.scratch() as stage:
                plans[p] = copy.deepcopy(chain.load_package(info, stage))
    # Source records remain guarded by the review tokens until copying finishes.
    schema = next(iter(plans.values()))['schema']
    if any(plan['schema'] != schema for plan in plans.values()):
        raise h.HandoffError('The profiles have different database schemas. Update both apps before merging.')
    tables = {t: [] for t in h.STATE_TABLES + h.HISTORY_TABLES}
    generated, provenance, warnings = [], {}, []
    order_note = ('Messages are combined by their saved timestamps. Overlapping original turns may be split into chronological segments. '
                  'Tool dependencies retain their original order; tied/missing times use stable source order. These segments are imported history, not new exchanges. '
                  if ordering == 'messages' else
                  'This local history combines saved branches in their original per-branch order. Independent turns use their recorded start times. ')
    note = ('[Imported by Syncex — ' + h.now() + ']\n' + order_note +
            'Separate variants may describe work that happened independently. These changes do not replay tools or restore project files.\n'
            'Original branches and the merge record: ' + str(directory) + '\n')
    if text.strip(): note += '\nUser-supplied text added through Profile Sync (not an original Codex message):\n' + text.strip() + '\n'
    if attachments:
        note += '\nFiles added through Profile Sync (local copies; not cloud uploads):\n' + '\n'.join(
            f"- {a['name']}: {a['path']} (SHA-256 {a['sha256']})" for a in attachments)
    for owner in sorted(ids):
        progress('Writing combined history for ' + owner)
        row, item, hist, prov, warns = generate_owner(owner, views, directory, note if owner == root else
            '[Imported by Syncex] Supporting-task branches merged. Original records: ' + str(directory), import_id)
        if ordering == 'messages':
            import message_timeline
            warns += message_timeline.reorder(row, item, hist, prov, import_id)
        tables['threads'].append(row); generated.append(item); provenance[owner] = prov; warnings += warns
        for t in h.HISTORY_TABLES: tables[t].extend(hist[t])
    # Union supporting state records using their actual schema keys. Metadata
    # collisions use the newer task's profile; originals remain in both backups.
    for table in h.STATE_TABLES:
        if table == 'threads': continue
        keys = [r[0] for r in sorted(schema[table], key=lambda r: r[3]) if r[3]]
        if not keys: raise h.HandoffError('Unsupported state table without a primary key: ' + table)
        rows = {}
        ordered = sorted(plans.values(), key=lambda m: max(latest.version(r) for r in m['tables']['threads']))
        for m in ordered:
            for r in m['tables'][table]: rows[tuple(r[k] for k in keys)] = r
        tables[table] = list(rows.values())
    for row in tables['threads']:
        source_rows = [r for m in plans.values() for r in m['tables']['threads'] if r['id'] == row['id']]
        row['project_id'] = max(source_rows, key=latest.version).get('project_id')
    for table, rows in tables.items():
        columns = [column[0] for column in schema[table]]
        if any(set(row) != set(columns) for row in rows):
            raise h.HandoffError('This history schema is not supported by the rewrite adapter: ' + table)
        tables[table] = [{column: row[column] for column in columns} for row in rows]
    fresh_ids, fresh = read_views(root)
    if fresh_ids != ids or {p: choices.fingerprint(v) for p, v in fresh.items()} != review['tokens']:
        raise live.Deferred('A task changed while the proposal was prepared. Original backups were kept; rescan.')
    packages = {}
    for target in latest.PROFILES:
        source = next(p for p in latest.PROFILES if p != target)
        manifest = {'version': 2, 'source': source, 'source_home': str(h.PROFILES[source]), 'thread_id': root,
                    'title': review['title'], 'created': h.now(), 'schema': schema, 'tables': tables, 'files': generated,
                    'history_ids': [r['thread_id'] for r in generated], 'rewrite_id': import_id}
        archive = directory / ('prepared-for-' + target + '.zip')
        with zipfile.ZipFile(archive, 'w', zipfile.ZIP_DEFLATED, compresslevel=3) as z:
            for item in generated: z.write(item['path'], 'rollouts/' + item['relative_path'])
            z.writestr('manifest.json', json.dumps(manifest, ensure_ascii=False))
        packages[target] = {k: manifest[k] for k in ('source', 'thread_id', 'title', 'created')}
        packages[target].update(archive=str(archive), sha256=h.digest(archive), bytes=archive.stat().st_size)
    plan = {'version': 1, 'id': import_id, 'thread_id': root, 'title': review['title'], 'created': h.now(), 'status': 'prepared',
            'ordering': ordering,
            'tokens': review['tokens'], 'backups': backups, 'packages': packages, 'profiles': {p: str(h.PROFILES[p]) for p in latest.PROFILES},
            'attachments': attachments, 'provenance': provenance, 'warnings': warnings, 'applied': {}, 'directory': str(directory)}
    h.atomic_json(directory / 'plan.json', plan)
    return plan


class RewriteGuard(latest.Guard):
    allow_branch_replacement = True

    def __init__(self, target, ids, plan, package):
        super().__init__(target, target, ids)
        self.plan, self.package = plan, package

    def check_source(self, manifest):
        for info in self.plan['backups'].values():
            if not info.get('absent') and h.digest(info['archive']) != info['sha256']:
                raise h.HandoffError('An original branch backup failed verification.')
        if h.digest(self.package['archive']) != self.package['sha256'] or manifest.get('rewrite_id') != self.plan['id']:
            raise h.HandoffError('Prepared history failed verification.')
        for item in self.plan['attachments']:
            if h.digest(item['path']) != item['sha256']:
                raise h.HandoffError('An imported attachment is missing or changed.')
        self.incoming = manifest['tables']

    def check_target(self, conn, before):
        for profile in latest.PROFILES: sidebar.require_profile_closed(profile)
        super().check_target(conn, before)


def matches_package(view, info):
    with h.scratch() as stage:
        m = chain.load_package(info, stage)
        expected = {(f['thread_id'], f['sha256']) for f in m['files']}
        if expected != {(f['thread_id'], f['sha256']) for f in view['files'].values()}: return False
        if any(live.rows_hash(view['history'][t]) != live.rows_hash(m['tables'][t]) for t in h.HISTORY_TABLES): return False
        for row in m['tables']['threads']:
            actual = view['rows'].get(row['id'], {})
            if any(actual.get(k) != v for k, v in row.items() if k != 'rollout_path'): return False
        return live.rows_hash(view['edges']) == live.rows_hash(m['tables']['thread_spawn_edges'])


def apply(plan_path, progress=lambda text: None, cancel=None):
    """Apply/resume the exact prepared proposal; caller holds worker_lock."""
    path = Path(plan_path).resolve()
    if not path.is_relative_to((h.ROOT / 'rewrites').resolve()) or path.name != 'plan.json':
        raise h.HandoffError('Choose a plan from this installation\'s rewrites folder.')
    plan = json.loads(path.read_text(encoding='utf-8'))
    if plan['profiles'] != {p: str(h.PROFILES[p]) for p in latest.PROFILES}:
        raise h.HandoffError('This proposal belongs to a different profile configuration.')
    latest.pending_recovery()
    for profile in latest.PROFILES: sidebar.require_profile_closed(profile)
    ids, views = read_views(plan['thread_id'])
    for profile, view in views.items():
        if choices.fingerprint(view) != plan['tokens'][profile] and not matches_package(view, plan['packages'][profile]):
            raise live.Deferred(profile + ' changed since this proposal. Both copies were kept; create a fresh preview.')
    try:
        for profile in latest.PROFILES:
            if cancel and cancel.is_set():
                plan['status'] = 'paused'; h.atomic_json(path, plan); return plan
            ids, current = read_views(plan['thread_id'])
            if matches_package(current[profile], plan['packages'][profile]):
                plan['applied'][profile] = {'already_present': True}
                h.atomic_json(path, plan)
                continue
            if choices.fingerprint(current[profile]) != plan['tokens'][profile]:
                raise live.Deferred(profile + ' changed after preparation. Its history was kept.')
            plan['status'] = 'applying'; h.atomic_json(path, plan)
            info = plan['packages'][profile]
            result = live.import_snapshot(info, progress, profile, guard=RewriteGuard(current[profile], ids, plan, info))
            plan['applied'][profile] = result
            h.atomic_json(path, plan)
        plan.update(status='completed', finished=h.now())
        h.atomic_json(path, plan)
        return plan
    except Exception as exc:
        plan.update(status='needs_resume', error=str(exc)); h.atomic_json(path, plan)
        raise
