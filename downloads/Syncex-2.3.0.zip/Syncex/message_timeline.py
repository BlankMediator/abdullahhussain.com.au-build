"""Reorder a prepared union at message/item boundaries, with no live writes."""
import copy
from datetime import datetime, timezone
import heapq
import json
from pathlib import Path
import uuid
import handoff as h


def timestamp(value):
    try:
        return datetime.fromisoformat(value.replace('Z', '+00:00')).timestamp()
    except (ValueError, TypeError, AttributeError):
        return None


def reorder(row, file, tables, provenance, import_id):
    """Split overlapping turns into contiguous chronological segments.

    An indexed item's original-to-final update interval remains indivisible.
    Within-turn record order protects tool call/result dependencies. All raw
    records, apart from replaced turn wrappers, survive with rebased ordinals.
    """
    path = Path(file['path'])
    records = [json.loads(line) for line in path.read_bytes().splitlines()]
    turn_rows = {r['turn_id']: r for r in tables['thread_turns']}
    by_turn = {tid: [] for tid in turn_rows}
    wrappers = {}
    current = None
    for record in records[1:]:
        payload = record.get('payload', {})
        kind = payload.get('type') if record.get('type') == 'event_msg' else None
        if kind == 'task_started':
            current = payload['turn_id']
            wrappers.setdefault(current, {})['start'] = record
        elif kind in ('task_complete', 'turn_aborted'):
            wrappers.setdefault(payload.get('turn_id', current), {})['end'] = record
        else:
            if current not in by_turn:
                raise h.HandoffError('A timeline record has no indexed turn.')
            by_turn[current].append(record)
    items = tables['thread_items']
    units, sequences = [], []
    warnings = []
    for tid, content in by_turn.items():
        index = [r for r in items if r['turn_id'] == tid]
        ends = {max(r['rollout_ordinal'], r['updated_at_ordinal']) for r in index}
        spans = [(r['rollout_ordinal'], max(r['rollout_ordinal'], r['updated_at_ordinal'])) for r in index]
        sequence, pending = [], []

        def emit():
            if not pending:
                return
            ordinals = {r['ordinal'] for r in pending}
            rows = [r for r in index if r['rollout_ordinal'] in ordinals]
            if any(r['updated_at_ordinal'] not in ordinals for r in rows):
                raise h.HandoffError('An item update crosses a timeline boundary. Both copies were kept.')
            messages = [r for r in pending if r.get('type') == 'response_item'
                        and r.get('payload', {}).get('type') == 'message'
                        and r['payload'].get('role') in ('user', 'assistant')]
            # Native item timestamps identify visible user/assistant messages.
            # Raw records can also contain hidden environment/context messages.
            visible = [r for r in rows if r['item_type'] in ('userMessage', 'agentMessage')]
            times = [r['created_at_ms']/1000 for r in visible if r.get('created_at_ms') is not None]
            if not times:
                times = [timestamp(r.get('timestamp')) for r in messages]
            times = [t for t in times if t is not None]
            if len(set(times)) > 1:
                # Splitting this interval would disconnect an in-flight item
                # from its update. Do not claim a message-level chronological union.
                raise h.HandoffError('Overlapping indexed updates keep several messages together. Use Decide later or a branch choice for this task. '
                                     + f'({len(visible)} visible messages in one update interval.)')
            when = times[0] if times else next((r['created_at_ms']/1000 for r in rows if r.get('created_at_ms') is not None), None)
            if when is None:
                when = next((timestamp(r.get('timestamp')) for r in pending if timestamp(r.get('timestamp')) is not None), None)
            if when is None:
                when = turn_rows[tid].get('started_at') or 0
                warnings.append('A message/item has no saved time; its turn time and stable source order were used.')
            key = len(units)
            units.append({'key': key, 'turn': tid, 'records': list(pending), 'rows': rows, 'time': when})
            sequence.append(key)
            pending.clear()

        for record in content:
            pending.append(record)
            ordinal = record['ordinal']
            if ordinal in ends and not any(start <= ordinal < end for start, end in spans):
                emit()
        if pending:
            # Trailing token/accounting events stay with the previous item.
            if sequence:
                units[sequence[-1]]['records'].extend(pending)
            else:
                emit()
        sequences.append(sequence)
    edges = {u['key']: set() for u in units}
    degree = {u['key']: 0 for u in units}
    for sequence in sequences:
        for a, b in zip(sequence, sequence[1:]):
            edges[a].add(b)
            degree[b] += 1
            if units[a]['time'] > units[b]['time']:
                warnings.append('Saved times run backwards within a turn; original message/tool order takes precedence.')
    ready = [(u['time'], u['key']) for u in units if degree[u['key']] == 0]
    heapq.heapify(ready)
    ordered = []
    while ready:
        _, key = heapq.heappop(ready)
        ordered.append(units[key])
        for child in edges[key]:
            degree[child] -= 1
            if not degree[child]:
                heapq.heappush(ready, (units[child]['time'], child))
    if len(ordered) != len(units):
        raise h.HandoffError('Contradictory message ordering. Both copies were kept.')
    if len({u['time'] for u in units}) != len(units):
        warnings.append('Equal saved times use stable source/record order.')
    segments = []
    for unit in ordered:
        if segments and segments[-1]['turn'] == unit['turn']:
            segments[-1]['units'].append(unit)
        else:
            segments.append({'turn': unit['turn'], 'units': [unit]})
    counts = {tid: sum(s['turn'] == tid for s in segments) for tid in by_turn}
    from merge_history import rewrite_ids
    output, new_turns, new_items = [], [], []
    offsets, size = {}, 0

    def write(record):
        nonlocal size
        ordinal = len(output)
        record = dict(record, ordinal=ordinal)
        raw = (json.dumps(record, ensure_ascii=False, separators=(',', ':'))+'\n').encode()
        result = (ordinal, size)
        output.append(raw)
        size += len(raw)
        return result

    write(records[0])
    segment_provenance = []
    remaining = dict(counts)
    for n, segment in enumerate(segments):
        old = segment['turn']
        remaining[old] -= 1
        final_segment = remaining[old] == 0
        tid = old if counts[old] == 1 else str(uuid.uuid5(uuid.UUID(import_id), old+':timeline:'+str(n)))
        mapping = {old: tid}
        when = segment['units'][0]['time']
        end_time = max(u['time'] for u in segment['units'])
        iso = lambda t: datetime.fromtimestamp(t, timezone.utc).isoformat()
        start = copy.deepcopy(wrappers.get(old, {}).get('start', {}))
        start.update(type='event_msg', timestamp=iso(when))
        start['payload'] = dict(start.get('payload', {}), type='task_started', turn_id=tid, started_at=int(when))
        start_n, start_offset = write(start)
        for unit in segment['units']:
            for record in unit['records']:
                offsets[record['ordinal']] = write(rewrite_ids(record, mapping))
        end = copy.deepcopy(wrappers.get(old, {}).get('end', {}))
        end.update(type='event_msg', timestamp=iso(end_time))
        end_kind = end.get('payload', {}).get('type', 'task_complete') if final_segment else 'task_complete'
        end['payload'] = dict(rewrite_ids(end.get('payload', {}), mapping), type=end_kind,
                              turn_id=tid, started_at=int(when), completed_at=int(end_time),
                              duration_ms=max(0, int((end_time-when)*1000)))
        if end_kind == 'task_complete':
            answers = [json.loads(r['item_json']).get('text') for unit in segment['units']
                       for r in unit['rows'] if r['item_type'] == 'agentMessage']
            end['payload']['last_agent_message'] = answers[-1] if answers else None
        write(end)
        segment_items = []
        for unit in segment['units']:
            for original in unit['rows']:
                item = copy.deepcopy(original)
                item.update(turn_id=tid, rollout_ordinal=offsets[item['rollout_ordinal']][0],
                            updated_at_ordinal=offsets[item['updated_at_ordinal']][0])
                item['item_json'] = json.dumps(rewrite_ids(json.loads(item['item_json']), mapping), ensure_ascii=False)
                segment_items.append(item)
        turn = copy.deepcopy(turn_rows[old])
        if not final_segment:
            turn.update(status='completed', error_json=None)
        turn.update(turn_id=tid, rollout_ordinal=start_n, rollout_byte_offset=start_offset,
                    rollout_end_ordinal=len(output), rollout_end_byte_offset=size,
                    started_at=int(when), completed_at=int(end_time), duration_ms=max(0,int((end_time-when)*1000)))
        turn['first_user_item_id'] = next((r['item_id'] for r in segment_items if r['item_type']=='userMessage'), None)
        turn['final_agent_item_id'] = next((r['item_id'] for r in reversed(segment_items) if r['item_type']=='agentMessage'), None)
        new_turns.append(turn)
        new_items.extend(segment_items)
        segment_provenance.append({'source_merged_turn': old, 'timeline_turn': tid,
                                   'first_message_time': when, 'last_message_time': end_time})
    if len(new_items) != len(items) or len(offsets) != sum(len(v) for v in by_turn.values()):
        raise h.HandoffError('Timeline coverage check failed; no live history was changed.')
    temp = path.with_suffix('.timeline.tmp')
    temp.write_bytes(b''.join(output))
    temp.replace(path)
    tables['thread_turns'] = new_turns
    tables['thread_items'] = new_items
    tables['thread_history_projection_state'][0].update(next_rollout_byte_offset=size, next_rollout_ordinal=len(output))
    file.update(size=size, mtime_ns=path.stat().st_mtime_ns, sha256=h.digest(path),
                terminal=['task_complete', new_turns[-1]['turn_id']])
    provenance.append({'message_timeline_segments': segment_provenance})
    return sorted(set(warnings))
