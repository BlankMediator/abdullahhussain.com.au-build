"""Synthetic live preservation/coordination tests; never access real profiles."""
import json
from pathlib import Path
import tempfile
import threading
import unittest
from unittest.mock import patch
import uuid
import live_mode as lm

TASK = '11111111-1111-4111-8111-111111111111'


class JournalTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        self.base = Path(self.temp.name)
        self.home = self.base / 'profile'
        self.source = self.home / 'sessions' / ('rollout-' + TASK + '.jsonl')
        self.source.parent.mkdir(parents=True)
        self.source.write_bytes(b'{"first":1}\n')
        self.folder = self.base / 'journals'
        self.journal = lm.Journal(self.folder)
        self.item = {'path': str(self.source), 'thread_id': TASK, 'owner_thread_id': TASK}

    def capture(self):
        return self.journal.capture('Left', self.home, self.item)

    def test_partial_record_waits_and_resumes_after_restart(self):
        first = self.capture()
        with self.source.open('ab') as f:
            f.write(b'{"second":')
        partial = self.capture()
        self.assertEqual(partial['bytes'], first['bytes'])
        self.journal = lm.Journal(self.folder)
        with self.source.open('ab') as f:
            f.write(b'2}\n')
        final = self.capture()
        self.assertEqual(final['generation'], first['generation'])
        self.assertEqual(Path(final['path']).read_bytes(), self.source.read_bytes())

    def test_rewrite_keeps_original_generation(self):
        first = self.capture()
        before = Path(first['path']).read_bytes()
        self.source.write_bytes(b'{"other":1}\n')
        second = self.capture()
        self.assertNotEqual(first['generation'], second['generation'])
        self.assertEqual(Path(first['path']).read_bytes(), before)

    def test_interrupted_append_recovers_committed_prefix(self):
        first = self.capture()
        with self.source.open('ab') as f:
            f.write(b'{"next":2}\n')
        original = lm.save
        def fail_latest(path, value):
            if path.name == 'latest.json':
                raise OSError('Simulated power loss')
            original(path, value)
        with patch.object(lm, 'save', side_effect=fail_latest):
            with self.assertRaises(OSError):
                self.capture()
        self.journal = lm.Journal(self.folder)
        recovered = self.capture()
        self.assertEqual(first['generation'], recovered['generation'])
        self.assertEqual(Path(recovered['path']).read_bytes(), self.source.read_bytes())

    def test_corrupt_journal_retained_and_recaptured(self):
        first = self.capture()
        Path(first['path']).write_bytes(b'corruption\n')
        self.journal = lm.Journal(self.folder)
        second = self.capture()
        self.assertNotEqual(first['generation'], second['generation'])
        self.assertEqual(Path(first['path']).read_bytes(), b'corruption\n')
        self.assertEqual(Path(second['path']).read_bytes(), self.source.read_bytes())

    def test_large_records_cross_chunk_boundary(self):
        self.source.write_bytes(b'{"large":"' + b'a' * (lm.CHUNK + 17) + b'"}\npartial')
        value = self.capture()
        self.assertEqual(Path(value['path']).read_bytes(), self.source.read_bytes()[:-7])

    def test_same_id_different_profiles_kept_separately(self):
        first = self.capture()
        second = self.journal.capture('Right', self.home, self.item)
        self.assertNotEqual(first['path'], second['path'])

    def test_unchanged_capture_does_not_duplicate_files(self):
        first = self.capture()
        self.assertEqual(self.capture(), first)
        self.assertEqual(len(list(self.folder.rglob('*.jsonl'))), 1)

    def test_source_outside_profile_rejected(self):
        with self.assertRaises(lm.h.HandoffError):
            self.journal.capture('Left', self.base / 'different', self.item)


class RoleTests(unittest.TestCase):
    def test_recycled_pid_does_not_resurrect_old_owner(self):
        line = f'2026-11-23T00:00:00Z info thread_stream_role_changed conversationId={TASK} role=owner'
        self.assertEqual(lm.parse_roles(line, {TASK}, 9999999999), {})

    def test_new_role_replaces_old_and_unknown_invalidates(self):
        lines = '\n'.join(f'2026-11-23T00:00:0{i}Z info thread_stream_role_changed conversationId={TASK} role={role}'
                          for i, role in enumerate(('owner', 'follower', 'null')))
        self.assertEqual(lm.parse_roles(lines, {TASK}, 0)[TASK]['role'], 'unknown')


class ControlTests(unittest.TestCase):
    def test_stop_before_run_never_scans_or_imports(self):
        engine = object.__new__(lm.Engine)
        engine.cancel = threading.Event()
        engine.cancel.set()
        with patch.object(engine, 'tick') as tick:
            engine.run(lambda value: None)
        tick.assert_not_called()

    def test_closed_receiver_is_rechecked_inside_transaction(self):
        guard = object.__new__(lm.ClosedReceiverGuard)
        guard.target_profile = 'Right'
        with patch.object(lm.sidebar, 'require_profile_closed', side_effect=lm.h.HandoffError('reopened')):
            with self.assertRaisesRegex(lm.h.HandoffError, 'reopened'):
                guard.check_target(None, None)

    def test_empty_selection_rejected_before_writes(self):
        with self.assertRaises(ValueError):
            lm.Engine([])


if __name__ == '__main__':
    unittest.main(verbosity=2)
