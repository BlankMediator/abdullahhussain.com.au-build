"""Public, synthetic-only checks. Run with: py -3 public_smoke_tests.py"""
import copy
from pathlib import Path
import threading
import unittest
from unittest.mock import patch
import uuid
import handoff as h
import merge_history as merge
import profile_config as config
import conflict_policy as policies
import repair_sidebar as sidebar
import sync_profiles as combined


def turn(tid, profile, timestamp, content):
    return {'id': tid, 'profile': profile, 'timestamp': timestamp,
            'hashes': [content], 'key': tid + ':' + content, 'refs': [], 'aliases': []}


class SmokeTests(unittest.TestCase):
    def test_task_policy_overrides_default(self):
        settings={'default':'combine','tasks':{'task':'later'}}
        self.assertEqual(policies.effective(settings,'task'),'later')
        self.assertEqual(policies.effective(settings,'other'),'combine')

    def test_first_use_defers_conflicts(self):
        self.assertEqual(policies.defaults()['default'],'later')
        self.assertEqual(policies.defaults()['tasks'],{})

    def test_independent_work_is_ordered_and_shared_turn_not_duplicated(self):
        shared = str(uuid.uuid4())
        a = [turn(shared, 'Left', 1, 'shared'), turn('left-turn', 'Left', 3, 'left')]
        b = [turn(shared, 'Right', 1, 'shared'), turn('right-turn', 'Right', 2, 'right')]
        result, _ = merge.ordered_turns({'Left': a, 'Right': b})
        self.assertEqual([r['id'] for r in result], [shared, 'right-turn', 'left-turn'])

    def test_branch_sequence_takes_priority_over_clock_skew(self):
        a = [turn('first', 'Left', 10, 'a'), turn('second', 'Left', 5, 'b')]
        result, _ = merge.ordered_turns({'Left': a})
        self.assertEqual([r['id'] for r in result], ['first', 'second'])

    def test_divergent_answer_is_kept_and_flagged(self):
        result, warnings = merge.ordered_turns({
            'Left': [turn('same-turn', 'Left', 1, 'answer-a')],
            'Right': [turn('same-turn', 'Right', 1, 'answer-b')]})
        self.assertEqual(len(result), 2)
        self.assertTrue(warnings)
        self.assertTrue(all(r['variant'] for r in result))

    def test_contradictory_order_is_refused(self):
        a = [turn('one', 'Left', 1, 'a'), turn('two', 'Left', 2, 'b')]
        b = [turn('two', 'Right', 2, 'b'), turn('one', 'Right', 1, 'a')]
        with self.assertRaises(h.HandoffError): merge.ordered_turns({'Left': a, 'Right': b})

    def test_generic_configuration_needs_no_original_users(self):
        base = Path.cwd() / 'synthetic-config-test'
        value = {'version': 1, 'shared_folder': str(base / 'shared'), 'profiles': [
            {'name': 'Left window', 'home': str(base / 'left' / '.codex'), 'account': r'PC\First',
             'app': str(base / 'app' / 'ChatGPT.exe')},
            {'name': 'Right window', 'home': str(base / 'right' / '.codex'), 'account': r'PC\Second',
             'app': str(base / 'app' / 'ChatGPT.exe')}]}
        self.assertEqual(config.validate(copy.deepcopy(value)), value)
        with_secret = copy.deepcopy(value)
        with_secret['profiles'][0]['password'] = 'do-not-store-this'
        with self.assertRaises(ValueError): config.validate(with_secret)
        same_home = copy.deepcopy(value)
        same_home['profiles'][1]['home'] = same_home['profiles'][0]['home']
        with self.assertRaises(ValueError): config.validate(same_home)


class ProcessDetectionTests(unittest.TestCase):
    def setUp(self):
        for target, name, kwargs in (
            (h, 'ACCOUNTS', {'new': {'Left':r'PC\Left', 'Right':r'PC\Right'}}),
            (sidebar, 'canonical_account', {'side_effect':lambda value:value}),
            (sidebar, 'app_process_tree', {'return_value':{10:1,11:10,20:1}}),
            (sidebar, 'process_owner', {}),
        ):
            patcher=patch.object(target,name,**kwargs)
            value=patcher.start()
            self.addCleanup(patcher.stop)
            if name=='app_process_tree':self.tree=value
            if name=='process_owner':self.owner=value
        self.owner.side_effect=lambda pid:{10:r'PC\Left',11:r'PC\Left',20:r'PC\Right'}[pid]

    def test_protected_child_uses_verified_parent_owner(self):
        def owner(pid):
            if pid==11: raise h.HandoffError('token denied')
            return {10:r'PC\Left',20:r'PC\Right'}[pid]
        self.owner.side_effect=owner
        self.assertEqual(sidebar.profile_apps('Left'),[10,11])
        self.assertEqual(sidebar.profile_apps('Right'),[20])
        self.assertEqual(sidebar.profile_apps('Left').unknown,())

    def test_unknown_root_blocks_both_profiles(self):
        self.tree.return_value={10:1}
        self.owner.side_effect=h.HandoffError('token denied')
        for profile in ('Left','Right'):
            apps=sidebar.profile_apps(profile)
            self.assertEqual(apps,[10])
            self.assertEqual(apps.unknown,(10,))

    def test_windows_owner_error_is_also_conservative(self):
        self.tree.return_value={10:1}
        self.owner.side_effect=OSError('Windows token lookup failed')
        self.assertEqual(sidebar.profile_apps('Left').unknown,(10,))

    def test_confirmed_exited_process_is_ignored(self):
        self.tree.return_value={10:1}
        self.owner.side_effect=None
        self.owner.return_value=None
        self.assertEqual(sidebar.profile_apps('Left'),[])

    def test_live_child_with_exited_parent_still_blocks(self):
        self.tree.return_value={10:1,11:10}
        def owner(pid):
            if pid==11:raise h.HandoffError('token denied')
            return None
        self.owner.side_effect=owner
        self.assertEqual(sidebar.profile_apps('Left'),[11])
        self.assertEqual(sidebar.profile_apps('Left').unknown,(11,))

    def test_ambiguous_parent_cycle_still_blocks(self):
        self.tree.return_value={10:11,11:10}
        self.owner.side_effect=h.HandoffError('token denied')
        self.assertEqual(sidebar.profile_apps('Left').unknown,(10,11))

    def test_write_gate_refuses_unknown_process(self):
        self.tree.return_value={10:1}
        self.owner.side_effect=h.HandoffError('token denied')
        with self.assertRaisesRegex(h.HandoffError,'Quit BOTH'):
            sidebar.require_profile_closed('Right')

    def test_wait_resumes_only_after_exit_and_quiet_recheck(self):
        cancel=threading.Event()
        messages=[]
        with patch.object(sidebar,'profile_apps',side_effect=[sidebar.AppProcesses([10],[10]),[],[]]) as scan, \
             patch.object(cancel,'wait',return_value=False) as wait:
            self.assertTrue(sidebar.wait_for_profiles_exit(('Left',),cancel,messages.append))
        self.assertIn('Quit BOTH',messages[0])
        self.assertEqual(scan.call_count,3)
        self.assertEqual([c.args[0] for c in wait.call_args_list],[1,2])

    def test_unknown_owner_wait_can_be_cancelled(self):
        cancel=threading.Event()
        with patch.object(sidebar,'profile_apps',return_value=sidebar.AppProcesses([10],[10])), \
             patch.object(cancel,'wait',return_value=True):
            self.assertFalse(sidebar.wait_for_profiles_exit(('Left',),cancel))

    def test_reopened_process_during_quiet_interval_still_blocks(self):
        cancel=threading.Event()
        apps=sidebar.AppProcesses([10],[10])
        with patch.object(sidebar,'profile_apps',side_effect=[[],apps,apps,[],[]]) as scan, \
             patch.object(cancel,'wait',return_value=False):
            self.assertTrue(sidebar.wait_for_profiles_exit(('Left',),cancel))
        self.assertEqual(scan.call_count,5)


class SummaryTests(unittest.TestCase):
    def report(self):
        source, target = combined.latest.PROFILES
        row = {'id':'task','title':'Renamed task','source':source,'target':target}
        report = {'history_passes':[{'imported':[], 'deferred':[dict(row,reason='Snapshot could not be captured')]}],
                  'metadata':{}, 'metadata_requested':True, 'status':'completed_with_deferred_tasks',
                  'reopen_errors':[], 'remaining':{'planned':[row]}}
        return report, row

    def test_final_preview_retains_last_copy_error_and_direction(self):
        report, row = self.report()
        summary = combined.latest_summary(report)
        self.assertIn('Last copy attempt: Snapshot could not be captured', summary)
        self.assertIn(row['source'] + ' → ' + row['target'], summary)

    def test_successful_retry_clears_previous_failure(self):
        report, row = self.report()
        report['history_passes'].append({'imported':[row], 'deferred':[]})
        self.assertNotIn('Last copy attempt:', combined.latest_summary(report))

    def test_opposite_direction_does_not_reuse_old_failure(self):
        report, row = self.report()
        report['remaining']['planned'] = [dict(row,source=row['target'],target=row['source'])]
        self.assertNotIn('Last copy attempt:', combined.latest_summary(report))


class LaunchBridgeTests(unittest.TestCase):
    def test_profile_configuration_reaches_standard_user_launcher(self):
        import windows_launch
        home=Path.cwd()/'left-profile'
        app=Path.cwd()/'ChatGPT.exe'
        with patch.object(h,'PROFILES',{'Left':home}), patch.object(h,'ACCOUNTS',{'Left':r'PC\First'}), \
             patch.object(h,'APPS',{'Left':app},create=True), patch.object(windows_launch,'account_action',return_value={'pid':42}) as action:
            self.assertEqual(config.launch('Left'),{'pid':42})
            action.assert_called_once_with({'name':'Left','account':r'PC\First','home':str(home),'app':str(app)},h.ROOT)


if __name__ == '__main__':
    unittest.main(verbosity=2)
