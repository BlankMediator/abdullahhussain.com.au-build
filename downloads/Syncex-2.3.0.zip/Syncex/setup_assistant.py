"""Discover, prepare and verify two profiles; retain the manual setup editor."""
import copy
import os
from pathlib import Path
import queue
import threading
import tkinter as tk
from tkinter import ttk, filedialog, messagebox
import webbrowser
import profile_config as cfg
import setup_support as support
import windows_launch as launch

INSTALL_URL='https://learn.chatgpt.com/docs/windows/windows-app'


def defaults(existing=None):
    if existing:return copy.deepcopy(existing)
    current=launch.current_account()
    candidates=[a for a in support.local_accounts() if a.casefold()!=current.casefold()
                and a.rsplit('\\',1)[-1].casefold() not in {'administrator','guest','defaultaccount','wdagutilityaccount'}
                and support.profile_home(a)]
    second=candidates[0] if candidates else os.environ['COMPUTERNAME']+'\\CodexSecond'
    apps=support.discover_apps()
    profiles=[]
    for name,account in zip(('Primary','Secondary'),(current,second)):
        try:home=support.profile_home(account)
        except OSError:home=None
        profiles.append({'name':name,'account':account,'home':str((home or Path.home().parent/account.rsplit('\\',1)[-1])/'.codex'),
                         'app':apps[0] if apps else ''})
    return {'version':1,'shared_folder':str(cfg.PROGRAM/'shared-data'),'profiles':profiles}


def passwords(parent, data):
    win=tk.Toplevel(parent);win.title('Windows passwords');win.geometry('760x330');win.transient(parent);win.grab_set()
    frame=ttk.Frame(win,padding=18);frame.pack(fill='both',expand=True)
    ttk.Label(frame,text='Windows sign-in for either configured account',font=('Segoe UI',15,'bold')).pack(anchor='w')
    ttk.Label(frame,text='Save is optional in the Windows password prompt. Saved passwords belong to the Windows user running this utility. '
        'They enable future launches from that user’s session. ChatGPT sign-in stays inside each app.',wraplength=710).pack(anchor='w',pady=12)
    status=tk.StringVar();ttk.Label(frame,textvariable=status,wraplength=710).pack(anchor='w',pady=6)
    rows=[]
    def refresh():
        for account,label in rows:
            try:text='Saved for this Windows user' if launch.has_credential(account) else 'Not saved'
            except Exception as e:text=str(e)
            label.set(text)
    def change(account,forget=False):
        try:
            if forget:launch.forget_credential(account);status.set('Removed this utility’s saved password for '+account)
            else:status.set(launch.set_credential(account))
            refresh()
        except Exception as e:status.set(str(e))
    for p in data['profiles']:
        row=ttk.Frame(frame);row.pack(fill='x',pady=8)
        ttk.Label(row,text=p['account'],width=30).pack(side='left')
        value=tk.StringVar();rows.append((p['account'],value))
        ttk.Label(row,textvariable=value,width=28).pack(side='left')
        ttk.Button(row,text='Set / update…',command=lambda a=p['account']:change(a)).pack(side='left',padx=4)
        ttk.Button(row,text='Forget',command=lambda a=p['account']:change(a,True)).pack(side='left')
    ttk.Button(frame,text='Close',command=win.destroy).pack(side='bottom',anchor='e')
    refresh();parent.wait_window(win)


class Assistant:
    def __init__(self,parent,existing=None):
        self.parent=parent;self.saved=None;self.busy=False;self.events=queue.Queue();self.buttons=[];self.fields=[]
        self.window=tk.Toplevel(parent);self.window.title('Automatic setup — Syncex')
        self.window.geometry('1040x830');self.window.minsize(960,760);self.window.transient(parent);self.window.grab_set()
        frame=ttk.Frame(self.window,padding=16);frame.pack(fill='both',expand=True)
        ttk.Label(frame,text='Set up or repair two Windows profiles',font=('Segoe UI',18,'bold')).pack(anchor='w')
        ttk.Label(frame,text='Detect existing settings, review what to prepare, then open each app and verify both users. '
            'Administrator approval is only for account and permissions setup.',wraplength=990).pack(anchor='w',pady=6)
        base=defaults(existing);accounts=support.local_accounts();apps=support.discover_apps(base)
        row=ttk.Frame(frame);row.pack(fill='x',pady=6)
        self.add_button(row,'Detect installed app / paths',self.detect)
        self.add_button(row,'Get official app installer',lambda:webbrowser.open(INSTALL_URL))
        self.add_button(row,'Manual setup…',self.manual)
        self.forms=[];self.automatic=[]
        for i,p in enumerate(base['profiles']):
            box=ttk.LabelFrame(frame,text='Profile '+str(i+1),padding=8);box.pack(fill='x',pady=4)
            values={k:tk.StringVar(value=p[k]) for k in ('name','account','home','app')};self.forms.append(values)
            for n,(key,label) in enumerate((('name','Label'),('account','Windows account'),('home','Codex folder'),('app','App executable'))):
                ttk.Label(box,text=label,width=18).grid(row=n,column=0,sticky='w')
                if key in ('account','app'):
                    field=ttk.Combobox(box,textvariable=values[key],values=accounts if key=='account' else apps)
                else:field=ttk.Entry(box,textvariable=values[key])
                field.grid(row=n,column=1,sticky='ew',pady=1)
                self.fields.append(field)
                if key in ('home','app'):
                    button=ttk.Button(box,text='Browse…',command=lambda v=values[key],k=key:self.browse(v,k))
                    button.grid(row=n,column=2,padx=4);self.buttons.append(button)
            try:expected=support.profile_home(p['account'])
            except OSError:expected=None
            automatic=tk.BooleanVar(value=not existing or bool(expected and Path(p['home'])==expected/'.codex'))
            self.automatic.append(automatic)
            check=ttk.Checkbutton(box,text='Use this account’s Windows profile + .codex when preparing setup',variable=automatic)
            check.grid(row=4,column=1,sticky='w');self.fields.append(check)
            button=ttk.Button(box,text='Open / sign in',command=lambda n=i:self.open_app(n));button.grid(row=4,column=2);self.buttons.append(button)
            box.columnconfigure(1,weight=1)
        row=ttk.Frame(frame);row.pack(fill='x',pady=6)
        ttk.Label(row,text='Shared sync folder:',width=18).pack(side='left')
        self.shared=tk.StringVar(value=base['shared_folder']);field=ttk.Entry(row,textvariable=self.shared)
        field.pack(side='left',fill='x',expand=True);self.fields.append(field)
        self.add_button(row,'Browse…',lambda:self.browse(self.shared,'home'))
        self.create_missing=tk.BooleanVar(value=False)
        check=ttk.Checkbutton(frame,text='Allow creation of missing local Windows accounts as standard users',variable=self.create_missing)
        check.pack(anchor='w');self.fields.append(check)
        row=ttk.Frame(frame);row.pack(fill='x',pady=8)
        self.add_button(row,'Review / prepare setup…',self.prepare)
        self.add_button(row,'Windows passwords…',self.credentials)
        self.add_button(row,'Verify both users',self.verify)
        self.add_button(row,'Save and finish',self.finish)
        self.status=tk.StringVar(value='Existing settings are loaded. Nothing has been changed.')
        ttk.Label(frame,textvariable=self.status,wraplength=990).pack(anchor='w',pady=4)
        self.output=tk.Text(frame,height=7,wrap='word',state='disabled');self.output.pack(fill='both',expand=True)
        self.window.protocol('WM_DELETE_WINDOW',self.close)
        self.poll_id=self.window.after(100,self.poll)

    def add_button(self,parent,text,command):
        button=ttk.Button(parent,text=text,command=command);button.pack(side='left',padx=(0,6));self.buttons.append(button)
        return button

    def browse(self,var,kind):
        value=(filedialog.askopenfilename(parent=self.window,filetypes=[('Windows app','*.exe')]) if kind=='app'
               else filedialog.askdirectory(parent=self.window,mustexist=False))
        if value:var.set(value)

    def data(self,validate=True):
        value={'version':1,'shared_folder':self.shared.get().strip(),
               'profiles':[{k:v.get().strip() for k,v in p.items()} for p in self.forms]}
        return cfg.validate(value) if validate else value

    def show(self,text):
        self.output.configure(state='normal');self.output.delete('1.0','end');self.output.insert('1.0',text);self.output.configure(state='disabled')

    def run(self,fn,done):
        if self.busy:return
        self.busy=True
        for button in self.buttons+self.fields:button.configure(state='disabled')
        def worker():
            try:self.events.put((done,fn(),None))
            except Exception as e:self.events.put((done,None,str(e)))
        threading.Thread(target=worker,daemon=True).start()

    def poll(self):
        try:
            done,result,error=self.events.get_nowait();self.busy=False
            for button in self.buttons+self.fields:button.configure(state='normal')
            if error:self.status.set(error)
            else:
                try:done(result)
                except Exception as e:self.status.set(str(e))
        except queue.Empty:pass
        if self.window.winfo_exists():self.poll_id=self.window.after(100,self.poll)

    def detect(self):
        try:
            apps=support.discover_apps()
            for i,p in enumerate(self.forms):
                if self.automatic[i].get():
                    try:home=support.profile_home(p['account'].get())
                    except OSError:home=None
                    if home:p['home'].set(str(home/'.codex'))
                if not Path(p['app'].get()).is_file() and apps:p['app'].set(apps[0])
            self.status.set('Detected existing app paths and Windows profile folders. Review the accounts before preparing setup.')
        except Exception as e:self.status.set(str(e))

    def manual(self):
        try:
            value=cfg.wizard(self.window,self.data(validate=False))
            if value:
                self.load(value);self.saved=value;self.status.set('Manual settings saved. Verify both users when ready.')
        except Exception as e:self.status.set(str(e))

    def load(self,data):
        self.shared.set(data['shared_folder'])
        for form,p in zip(self.forms,data['profiles']):
            for k,v in p.items():form[k].set(v)

    def prepare(self):
        try:
            plan={'config':self.data(),'create_missing':self.create_missing.get(),
                  'automatic_homes':[v.get() for v in self.automatic],'program':str(cfg.PROGRAM)}
            text=support.review_text(plan)
            if not messagebox.askokcancel('Review automatic setup',text,parent=self.window):return
            self.show(text);self.status.set('Preparing selected accounts and folders. Complete any Windows approval or new-user password prompt.')
            def done(result):
                if result['ok']:
                    self.load(result['config']);cfg.save(result['config']);cfg.activate(result['config']);self.saved=result['config']
                    self.status.set('Setup prepared. Open each app, complete sign-in, then Verify both users.')
                else:self.status.set('Setup needs attention: '+result['error']+' Completed steps were retained; retry after fixing the reported item.')
                self.show('\n'.join(str(e) for e in result['events'])+'\nReport: '+result['report'])
            self.run(lambda:support.prepare(plan),done)
        except Exception as e:self.status.set(str(e))

    def credentials(self):
        try:passwords(self.window,self.data())
        except Exception as e:self.status.set(str(e))

    def open_app(self,i):
        try:
            data=self.data();cfg.save(data);cfg.activate(data);self.saved=data
            self.status.set('Opening '+data['profiles'][i]['account']+' without elevation. Complete ChatGPT sign-in in the app.')
            self.run(lambda:launch.account_action(data['profiles'][i],data['shared_folder']),
                     lambda r:self.status.set('Opened as '+r['account']+'. Complete sign-in and send a first task if this is a new profile.'))
        except Exception as e:self.status.set(str(e))

    def verify(self):
        try:
            data=self.data();folders=[data['shared_folder']]+[p['home'] for p in data['profiles']]
            self.status.set('Checking access under each Windows account. A saved password is used when available.')
            def check():return [launch.account_action(p,data['shared_folder'],'probe',folders) for p in data['profiles']]
            def done(results):
                lines=[];ready=True
                for r in results:
                    ok=r['app_found'] and r['databases_ready'] and r['database_access'] and all(f['writable'] for f in r['folders'])
                    ready &= ok
                    lines.extend([r['account']+': '+('files and access ready' if ok else 'needs setup'),
                        '  App executable: '+('found' if r['app_found'] else 'missing'),
                        '  History databases: '+('ready' if r['databases_ready'] else 'open/sign in and create a first task'),
                        '  Sign-in data: '+('present; confirm the session in the app' if r['sign_in_data_present'] else 'not found; sign in inside the app')])
                    lines.extend('  '+f['path']+': '+('writable' if f['writable'] else f.get('error','not writable')) for f in r['folders'])
                    lines.extend('  Database access: '+error for error in r.get('database_errors',[]))
                self.show('\n'.join(lines));self.status.set('File/access verification complete. '+('Both profiles are ready; confirm sign-in in each app.' if ready else 'Use Review / prepare setup or Open / sign in for the reported items.'))
            self.run(check,done)
        except Exception as e:self.status.set(str(e))

    def finish(self):
        try:
            data=self.data();cfg.save(data);cfg.activate(data);self.saved=data;self.close()
        except Exception as e:self.status.set(str(e))

    def close(self):
        if self.busy:self.status.set('Wait for the current setup step to finish, or cancel its Windows prompt.');return
        self.window.after_cancel(self.poll_id);self.window.destroy()


def wizard(parent,existing=None):
    assistant=Assistant(parent,existing)
    parent.wait_window(assistant.window)
    return assistant.saved or existing
