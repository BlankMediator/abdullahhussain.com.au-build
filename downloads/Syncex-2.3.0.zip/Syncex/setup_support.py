"""Account discovery and a bounded, reviewed administrator setup helper."""
import ctypes as c
from ctypes import wintypes as w
import hashlib
import json
import os
from pathlib import Path
import re
import subprocess
import sys
import time
import uuid
import winreg
import windows_launch as launch


def account_sid(account):
    a=c.WinDLL('advapi32',use_last_error=True)
    a.LookupAccountNameW.argtypes=[w.LPCWSTR,w.LPCWSTR,c.c_void_p,c.POINTER(w.DWORD),w.LPWSTR,c.POINTER(w.DWORD),c.POINTER(w.DWORD)]
    a.ConvertSidToStringSidW.argtypes=[c.c_void_p,c.POINTER(w.LPWSTR)]
    k=c.WinDLL('kernel32',use_last_error=True);k.LocalFree.argtypes=[c.c_void_p]
    size,domainsize,kind=w.DWORD(),w.DWORD(),w.DWORD()
    a.LookupAccountNameW(None,account,None,c.byref(size),None,c.byref(domainsize),c.byref(kind))
    if not size.value:
        raise launch.winerror()
    sid=c.create_string_buffer(size.value);domain=c.create_unicode_buffer(max(1,domainsize.value))
    if not a.LookupAccountNameW(None,account,sid,c.byref(size),domain,c.byref(domainsize),c.byref(kind)):
        raise launch.winerror()
    text=w.LPWSTR()
    if not a.ConvertSidToStringSidW(sid,c.byref(text)):
        raise launch.winerror()
    try:
        return text.value
    finally:
        k.LocalFree(c.cast(text,c.c_void_p))


def profile_home(account):
    sid=account_sid(account)
    try:
        with winreg.OpenKey(winreg.HKEY_LOCAL_MACHINE,
                'SOFTWARE\\Microsoft\\Windows NT\\CurrentVersion\\ProfileList\\'+sid) as key:
            return Path(os.path.expandvars(winreg.QueryValueEx(key,'ProfileImagePath')[0]))
    except FileNotFoundError:
        return None


def local_accounts():
    class User(c.Structure):
        _fields_=[('name',w.LPWSTR)]
    net=c.WinDLL('netapi32',use_last_error=True)
    net.NetUserEnum.argtypes=[w.LPCWSTR,w.DWORD,w.DWORD,c.POINTER(c.c_void_p),w.DWORD,
                              c.POINTER(w.DWORD),c.POINTER(w.DWORD),c.POINTER(w.DWORD)]
    net.NetApiBufferFree.argtypes=[c.c_void_p]
    resume=w.DWORD();names=[]
    while True:
        buf=c.c_void_p();read,total=w.DWORD(),w.DWORD()
        status=net.NetUserEnum(None,0,2,c.byref(buf),0xFFFFFFFF,c.byref(read),c.byref(total),c.byref(resume))
        if status not in (0,234):
            raise c.WinError(status)
        try:
            users=c.cast(buf,c.POINTER(User))
            names.extend(os.environ['COMPUTERNAME']+'\\'+users[i].name for i in range(read.value))
        finally:
            if buf:net.NetApiBufferFree(buf)
        if status==0:return sorted(names,key=str.casefold)


def discover_apps(existing=None):
    candidates=[]
    if existing:
        candidates.extend(Path(p['app']) for p in existing['profiles'])
    # Inspect running executable paths without reading command lines or credentials.
    import handoff as h
    import repair_sidebar as sidebar
    original=getattr(h,'APPS',None)
    try:
        h.APPS={'chat':Path('ChatGPT.exe'),'codex':Path('Codex.exe')}
        tree=sidebar.app_process_tree()
    finally:
        if original is None:del h.APPS
        else:h.APPS=original
    k=c.WinDLL('kernel32',use_last_error=True)
    k.OpenProcess.argtypes=[w.DWORD,w.BOOL,w.DWORD];k.OpenProcess.restype=w.HANDLE
    k.QueryFullProcessImageNameW.argtypes=[w.HANDLE,w.DWORD,w.LPWSTR,c.POINTER(w.DWORD)]
    k.CloseHandle.argtypes=[w.HANDLE]
    for pid,parent in tree.items():
        if parent in tree:continue
        process=k.OpenProcess(0x1000,False,pid)
        if not process:continue
        try:
            name=c.create_unicode_buffer(32768);size=w.DWORD(len(name))
            if k.QueryFullProcessImageNameW(process,0,name,c.byref(size)):candidates.append(Path(name.value))
        finally:k.CloseHandle(process)
    for root in [Path(os.environ.get('LOCALAPPDATA',Path.home()/'AppData/Local'))/'Programs',
                 Path(os.environ.get('ProgramFiles','C:/Program Files'))]:
        for product in ('ChatGPT','Codex'):
            candidates.append(root/product/(product+'.exe'))
    return list(dict.fromkeys(str(p.resolve()) for p in candidates if p.is_file()))


def linked(path):
    try:
        return bool(getattr(Path(path).lstat(),'st_file_attributes',0) & 0x400)
    except FileNotFoundError:
        return False


def safe_folder(path):
    p=Path(path)
    if not p.is_absolute() or str(p).startswith('\\\\'):
        raise ValueError('Automatic setup requires an absolute local folder: '+str(p))
    for ancestor in (p,*p.parents):
        if linked(ancestor):
            raise ValueError('Automatic setup cannot traverse a linked path: '+str(ancestor))
    p=p.resolve()
    denied={Path(p.anchor),Path(os.environ.get('SystemRoot','C:/Windows')).resolve(),
            Path(os.environ.get('ProgramFiles','C:/Program Files')).resolve(),
            Path(os.environ.get('ProgramData','C:/ProgramData')).resolve(),Path.home().parent.resolve()}
    if p in denied or p==Path.home().resolve() or any(p.is_relative_to(x) for x in denied if x.name.lower()=='windows'):
        raise ValueError('Automatic setup cannot change this system/profile root: '+str(p))
    return p


def validate_plan(plan):
    import profile_config as cfg
    if set(plan)!={'config','create_missing','automatic_homes','program'}:
        raise ValueError('Unsupported setup plan.')
    cfg.validate(plan['config'])
    if not isinstance(plan['create_missing'],bool) or len(plan['automatic_homes'])!=2 or any(type(x) is not bool for x in plan['automatic_homes']):
        raise ValueError('Invalid automatic setup choices.')
    if Path(plan['program']).resolve()!=Path(__file__).resolve().parent:
        raise ValueError('Setup program directory does not match this installation.')
    for path in [plan['config']['shared_folder']]+[p['home'] for p in plan['config']['profiles']]:
        safe_folder(path)
    for profile in plan['config']['profiles']:
        if not Path(profile['app']).is_file():
            raise ValueError('Select an installed app executable before preparing setup: '+profile['app'])
        domain,user=profile['account'].split('\\',1)
        if domain.casefold()!=os.environ['COMPUTERNAME'].casefold():
            raise ValueError('Automatic account creation/repair supports local accounts on this PC. Use Manual setup for domain accounts.')
        if not re.fullmatch(r'[A-Za-z0-9][A-Za-z0-9 _.-]{0,19}',user) or user.endswith(('.', ' ')):
            raise ValueError('Use a local Windows account name of 1–20 letters, numbers, spaces, dots, hyphens or underscores.')
        try:
            home=profile_home(profile['account'])
        except OSError as exc:
            if exc.winerror!=1332 or not plan['create_missing']:raise
            home=None
        if home and Path(profile['home']).resolve()==home.resolve():
            raise ValueError('Select the .codex subfolder, not the Windows profile root.')
    return plan


def review_text(plan):
    validate_plan(plan)
    data=plan['config'];accounts=', '.join(p['account'] for p in data['profiles'])
    lines=['Accounts: '+accounts,
        'Missing local users: '+('create as STANDARD users; Windows will ask for each new password' if plan['create_missing'] else 'stop and report'),
        'Initialize missing Windows profiles; preserve existing users, passwords and group membership.',
        'Create missing folders and grant Modify access to these two users only: '+data['shared_folder']]
    for p,automatic in zip(data['profiles'],plan['automatic_homes']):
        lines.append('  '+p['account']+': '+('Windows-assigned profile folder + \\.codex' if automatic else p['home']))
    lines.extend(['Grant Read/Execute access to this utility, its Python runtime and selected app files/resources.',
        'Allow these two users to display and interact with app windows on this Windows desktop for the current session.',
        'Profile folder access includes sign-in files already in those folders. No sign-in tokens are copied.',
        'Save permission backups and a completion report. Existing access is preserved.',
        'Windows may request administrator approval for this setup only. Apps are opened separately without elevation.'])
    return '\n'.join(lines)


class ShellInfo(c.Structure):
    _fields_=[('cbSize',w.DWORD),('fMask',w.ULONG),('hwnd',w.HWND),('lpVerb',w.LPCWSTR),
              ('lpFile',w.LPCWSTR),('lpParameters',w.LPCWSTR),('lpDirectory',w.LPCWSTR),
              ('nShow',c.c_int),('hInstApp',w.HANDLE),('lpIDList',c.c_void_p),('lpClass',w.LPCWSTR),
              ('hkeyClass',w.HKEY),('dwHotKey',w.DWORD),('hIcon',w.HANDLE),('hProcess',w.HANDLE)]


def prepare(plan):
    validate_plan(plan)
    root=Path(os.environ['LOCALAPPDATA'])/'CodexProfileSync'/'setup-reports'/uuid.uuid4().hex
    root.mkdir(parents=True)
    request=root/'request.json';report=root/'result.json'
    raw=json.dumps(plan,ensure_ascii=False,indent=2).encode('utf-8');request.write_bytes(raw)
    digest=hashlib.sha256(raw).hexdigest()
    args=[str(Path(__file__).resolve()),'--apply',str(request),digest,str(report)]
    shell=c.WinDLL('shell32',use_last_error=True)
    shell.ShellExecuteExW.argtypes=[c.POINTER(ShellInfo)]
    info=ShellInfo(cbSize=c.sizeof(ShellInfo),fMask=0x40,lpVerb='runas',lpFile=sys.executable,
                   lpParameters=subprocess.list2cmdline(args),lpDirectory=str(Path(__file__).parent),nShow=0)
    if not shell.ShellExecuteExW(c.byref(info)):
        raise launch.winerror()
    k,_=launch.native()
    try:
        while k.WaitForSingleObject(info.hProcess,250)==258:
            pass  # Worker thread; the setup UI continues processing events.
    finally:k.CloseHandle(info.hProcess)
    if not report.exists():
        raise RuntimeError('The setup helper exited without a report. Setup files: '+str(root))
    result=json.loads(report.read_text(encoding='utf-8'))
    result['report']=str(report)
    return result


def create_local_user(account,events):
    class User(c.Structure):
        _fields_=[('name',w.LPWSTR),('password',w.LPWSTR),('password_age',w.DWORD),('priv',w.DWORD),
                  ('home_dir',w.LPWSTR),('comment',w.LPWSTR),('flags',w.DWORD),('script_path',w.LPWSTR)]
    class Member(c.Structure):
        _fields_=[('name',w.LPWSTR)]
    net=c.WinDLL('netapi32',use_last_error=True)
    net.NetUserAdd.argtypes=[w.LPCWSTR,w.DWORD,c.c_void_p,c.POINTER(w.DWORD)]
    net.NetLocalGroupAddMembers.argtypes=[w.LPCWSTR,w.LPCWSTR,w.DWORD,c.c_void_p,w.DWORD]
    username=account.split('\\',1)[1]
    with launch.prompt_credential(account,creating=True) as secret:
        if secret.buffer[0]=='\0':raise ValueError('A non-empty Windows password is required for another-user launches.')
        data=User(name=username,password=c.cast(secret.buffer,w.LPWSTR),priv=1,comment='Syncex standard user',flags=0x201)
        error=w.DWORD();status=net.NetUserAdd(None,1,c.byref(data),c.byref(error))
        if status:raise c.WinError(status)
        events.append({'action':'create_standard_user','account':account})
    # Resolve the localized name of the built-in Users group by its fixed SID.
    a=c.WinDLL('advapi32',use_last_error=True);k=c.WinDLL('kernel32',use_last_error=True)
    a.ConvertStringSidToSidW.argtypes=[w.LPCWSTR,c.POINTER(c.c_void_p)]
    a.LookupAccountSidW.argtypes=[w.LPCWSTR,c.c_void_p,w.LPWSTR,c.POINTER(w.DWORD),w.LPWSTR,c.POINTER(w.DWORD),c.POINTER(w.DWORD)]
    k.LocalFree.argtypes=[c.c_void_p]
    sid=c.c_void_p()
    if not a.ConvertStringSidToSidW('S-1-5-32-545',c.byref(sid)):raise launch.winerror()
    try:
        name,domain=c.create_unicode_buffer(256),c.create_unicode_buffer(256)
        nc,dc,kind=w.DWORD(256),w.DWORD(256),w.DWORD()
        if not a.LookupAccountSidW(None,sid,name,c.byref(nc),domain,c.byref(dc),c.byref(kind)):raise launch.winerror()
        member=Member(name=account);status=net.NetLocalGroupAddMembers(None,name.value,3,c.byref(member),1)
        if status not in (0,1378):raise c.WinError(status)
    finally:k.LocalFree(sid)


def initialize_profile(account):
    home=profile_home(account)
    if home:return home
    api=c.WinDLL('userenv',use_last_error=True)
    api.CreateProfile.argtypes=[w.LPCWSTR,w.LPCWSTR,w.LPWSTR,w.DWORD]
    api.CreateProfile.restype=c.c_long
    path=c.create_unicode_buffer(32768)
    status=api.CreateProfile(account_sid(account),account.split('\\',1)[1],path,len(path))
    if status!=0:
        home=profile_home(account)
        if home:return home
        raise RuntimeError('Windows profile initialization failed for '+account+' (HRESULT '+hex(status & 0xFFFFFFFF)+').')
    return Path(path.value)


def reject_links(root):
    safe_folder(root)
    if not Path(root).exists():return
    for folder,dirs,files in os.walk(root,followlinks=False):
        for name in dirs+files:
            p=Path(folder)/name
            if linked(p):
                raise ValueError('Automatic permissions repair stops at linked paths: '+str(p)+'. Use Manual setup for this location.')


def grant_access(path,sids,rights,backup_dir,index,events):
    path=Path(path)
    if not path.exists():raise FileNotFoundError(str(path))
    reject_links(path) if path.is_dir() else safe_folder(path.parent)
    icacls=str(Path(os.environ['SystemRoot'])/'System32/icacls.exe')
    backup=backup_dir/(str(index)+'.acl')
    common={'capture_output':True,'creationflags':subprocess.CREATE_NO_WINDOW}
    # /L acts on links; reject_links also refuses a tree containing them.
    saved=subprocess.run([icacls,str(path),'/save',str(backup),'/T','/L','/Q'],**common)
    (backup_dir/(str(index)+'-backup.log')).write_bytes(saved.stdout+saved.stderr)
    if saved.returncode:raise RuntimeError('Could not back up permissions for '+str(path))
    entries=['*'+sid+':'+('(OI)(CI)' if path.is_dir() else '')+rights for sid in sids]
    applied=subprocess.run([icacls,str(path),'/grant',*entries,'/T','/L','/Q'],**common)
    (backup_dir/(str(index)+'-grant.log')).write_bytes(applied.stdout+applied.stderr)
    events.append({'action':'permissions','path':str(path),'rights':rights,'backup':str(backup),'exit_code':applied.returncode})
    if applied.returncode:raise RuntimeError('Permissions update was incomplete for '+str(path)+'. See the setup report and ACL backup.')


def apply_plan(plan,root,events):
    validate_plan(plan)
    if not launch.elevated():raise RuntimeError('Administrator approval is required for account and permission setup.')
    data=plan['config']
    for i,profile in enumerate(data['profiles']):
        try:account_sid(profile['account'])
        except OSError as exc:
            if exc.winerror!=1332 or not plan['create_missing']:raise
            create_local_user(profile['account'],events)
        home=initialize_profile(profile['account'])
        events.append({'action':'windows_profile','account':profile['account'],'home':str(home)})
        if plan['automatic_homes'][i]:profile['home']=str(home/'.codex')
    validate_plan(plan)
    sids=[account_sid(p['account']) for p in data['profiles']]
    backup=root/'permissions';backup.mkdir(exist_ok=True)
    targets=[(Path(data['shared_folder']),'M')]+[(Path(p['home']),'M') for p in data['profiles']]
    for folder,_ in targets:
        reject_links(folder)
        if not folder.exists():
            folder.mkdir(parents=True);events.append({'action':'create_folder','path':str(folder)})
    read_paths={Path(plan['program']).resolve(),Path(sys.executable).resolve().parent}
    for p in data['profiles']:
        app=Path(p['app'])
        if not app.is_file():raise FileNotFoundError('Select an installed app executable first: '+str(app))
        read_paths.add(app)
        read_paths.update(f for f in app.parent.iterdir() if f.is_file() and f.suffix.lower() in {'.dll','.pak','.bin','.dat'})
        read_paths.update(f for f in (app.parent/'resources',app.parent/'locales') if f.is_dir())
    # Avoid reducing or redundantly traversing a location that already gets Modify.
    managed=[x.resolve() for x,_ in targets]
    targets.extend((p,'RX') for p in sorted(read_paths,key=str) if not any(p==m or p.is_relative_to(m) for m in managed))
    for i,(path,rights) in enumerate(targets):grant_access(path,sids,rights,backup,i,events)
    for profile in data['profiles']:
        launch.allow_desktop_access(profile['account'])
        events.append({'action':'desktop_access','account':profile['account']})
    return data


def admin_main():
    request,digest,report=Path(sys.argv[2]),sys.argv[3],Path(sys.argv[4])
    events=[]
    try:
        raw=request.read_bytes()
        if hashlib.sha256(raw).hexdigest()!=digest:raise ValueError('The reviewed setup request changed; nothing was applied.')
        plan=json.loads(raw)
        result=apply_plan(plan,report.parent,events)
        value={'ok':True,'config':result,'events':events}
    except Exception as exc:
        value={'ok':False,'error':str(exc),'events':events}
    report.write_text(json.dumps(value,ensure_ascii=False,indent=2),encoding='utf-8')


if __name__=='__main__' and len(sys.argv)==5 and sys.argv[1]=='--apply':
    admin_main()
