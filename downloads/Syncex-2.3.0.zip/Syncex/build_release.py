"""Build an allowlisted distribution; never include installed profile data."""
import ast
import hashlib
import json
from pathlib import Path
import re
import shutil
import subprocess
import sys
import uuid
import zipfile
import handoff as h

VERSION = '2.3.0'
ROOT = Path(__file__).resolve().parent
ALLOW = (
    'desktop_app.py', 'profile_config.py', 'selection.py', 'sync_profiles.py',
    'live_mode.py', 'live_panel.py', 'live_mode_tests.py', 'LIVE-MODE.md',
    'live_bridge.py', 'live_connection.py', 'live_bridge_tests.py', 'launch_readiness_tests.py',
    'sync_latest.py', 'sync_live.py', 'history_chain.py', 'merge_history.py',
    'conflict_choices.py', 'conflict_policy.py', 'message_timeline.py', 'repair_sidebar.py', 'handoff.py',
    'public_smoke_tests.py', 'setup_launch_tests.py', 'windows_launch.py', 'setup_support.py',
    'setup_assistant.py', 'build_release.py', 'profiles.example.json',
    'Start Syncex.cmd', 'Start Codex Profile Sync.cmd', '.gitignore', '.gitattributes', 'verify_release.py', 'VERIFY.md', 'README.md', 'SYNC-NOW.md', 'SETUP.md',
    'USER-GUIDE.md', 'DIRECTORIES.md', 'ARCHITECTURE.md', 'RELEASE.md',
    'VALIDATION.md', 'CHANGELOG.md', 'LEGACY-HANDOFF.md', 'NEXT-STEPS.md',
)


def public_source(name, text, labels):
    """Remove unused local entry points without rewriting the retained helpers."""
    tree = ast.parse(text)
    remove = {'handoff.py': {'pending_apps', 'require_apps_closed', 'guard_activation',
        'import_package', 'transfer', 'recover_pending', 'hook', 'snapshot_worker', 'launch_target', 'list_chats', 'main'},
        'sync_live.py': {'gui'}, 'repair_sidebar.py': {'gui'}, 'sync_profiles.py': {'gui', 'synchronize'}}
    edits = []
    for node in tree.body:
        if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)) and node.name in remove.get(name, set()):
            start = min([node.lineno] + [d.lineno for d in node.decorator_list])
            edits.append((start-1, node.end_lineno, ''))
        if name in ('handoff.py', 'sync_live.py', 'repair_sidebar.py') and isinstance(node, ast.If) and '__name__' in ast.unparse(node.test):
            edits.append((node.lineno-1, node.end_lineno, ''))
        if name == 'handoff.py' and isinstance(node, ast.Assign):
            names = [t.id for t in node.targets if isinstance(t, ast.Name)]
            for key in ('PROFILES', 'ACCOUNTS', 'APP'):
                if key in names:
                    edits.append((node.lineno-1, node.end_lineno, key + (' = Path()\n' if key == 'APP' else ' = {}\n')))
    lines = text.splitlines(keepends=True)
    for start, end, replacement in sorted(edits, reverse=True): lines[start:end] = [replacement]
    text = ''.join(lines)
    for old, new in labels.items():
        text = re.sub(r'\b' + re.escape(old) + r'\b', lambda _: new, text)
    return text


def main():
    parent = ROOT / 'release'
    stage = parent / ('build-' + uuid.uuid4().hex)
    stage.mkdir(parents=True)
    labels = {p: name for p, name in zip(h.PROFILES, ('Primary', 'Secondary'))}
    private_paths = [str(p) for p in h.PROFILES.values()] + list(h.ACCOUNTS.values())
    try:
        hashes = {}
        for name in ALLOW:
            source = ROOT / name
            text = source.read_text(encoding='utf-8')
            if source.suffix == '.py': text = public_source(name, text, labels)
            if any(value and value in text for value in private_paths):
                raise RuntimeError('Local identity/path found in release file: ' + name)
            if any(re.search(r'\b' + re.escape(value) + r'\b', text) for value in labels if value not in ('Primary', 'Secondary')):
                raise RuntimeError('Local profile label found in release file: ' + name)
            dest = stage / name
            dest.write_text(text, encoding='utf-8', newline='\n')
            if dest.suffix == '.py': compile(text, name, 'exec')
            hashes[name] = hashlib.sha256(dest.read_bytes()).hexdigest()
        subprocess.run([sys.executable, str(stage/'public_smoke_tests.py')], cwd=stage, check=True)
        subprocess.run([sys.executable, str(stage/'setup_launch_tests.py')], cwd=stage, check=True)
        subprocess.run([sys.executable, str(stage/'live_mode_tests.py')], cwd=stage, check=True)
        subprocess.run([sys.executable, str(stage/'live_bridge_tests.py')], cwd=stage, check=True)
        subprocess.run([sys.executable, str(stage/'launch_readiness_tests.py')], cwd=stage, check=True)
        # Also import the generic entry point after removing old local defaults.
        subprocess.run([sys.executable, '-c', 'import desktop_app, handoff; assert handoff.PROFILES == {}'], cwd=stage, check=True)
        (stage/'SHA256SUMS.json').write_text(json.dumps(hashes, indent=2)+'\n', encoding='utf-8', newline='\n')
        (stage/'SHA256SUMS.txt').write_text(''.join(f'{digest}  {name}\n' for name, digest in sorted(hashes.items())), encoding='ascii', newline='\n')
        archive = parent / ('Syncex-' + VERSION + '.zip')
        with zipfile.ZipFile(archive, 'w', zipfile.ZIP_DEFLATED, compresslevel=9) as z:
            for name in sorted((*ALLOW, 'SHA256SUMS.json', 'SHA256SUMS.txt')):
                entry = zipfile.ZipInfo('Syncex/'+name, (2026, 11, 23, 0, 0, 0))
                entry.compress_type = zipfile.ZIP_DEFLATED
                entry.create_system = 3
                entry.external_attr = 0o100644 << 16
                z.writestr(entry, (stage/name).read_bytes(), compresslevel=9)
        digest = hashlib.sha256(archive.read_bytes()).hexdigest()
        checksum = digest+'  '+archive.name+'\n'
        archive.with_suffix('.zip.sha256').write_text(checksum, encoding='ascii', newline='\n')
        (parent/'SHA256SUMS.txt').write_text(checksum, encoding='ascii', newline='\n')
        subprocess.run([sys.executable, str(stage/'verify_release.py'), str(archive)], cwd=stage, check=True)
        print(archive)
        print('SHA-256:', digest)
        print('Files:', len(ALLOW)+2)
    finally:
        if stage.resolve().parent != parent.resolve(): raise RuntimeError('Unexpected cleanup location')
        shutil.rmtree(stage)


if __name__ == '__main__': main()
