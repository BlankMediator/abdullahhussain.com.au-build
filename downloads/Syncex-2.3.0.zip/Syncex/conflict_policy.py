"""Persist and apply the user's global/per-task conflict resolution presets."""
import copy
import json
from pathlib import Path
import sqlite3
import handoff as h
import sync_latest as latest
import sync_live as live
import conflict_choices as choices
import merge_history as merge
import repair_sidebar as sidebar

LABELS = {'later': 'Decide later', 'latest': 'Use latest version',
          'combine': 'Combine messages chronologically'}


def defaults():
    return {'version': 1, 'profiles': {p: str(home) for p, home in h.PROFILES.items()},
            'default': 'later', 'tasks': {}}


def validate(value):
    if not isinstance(value, dict) or set(value) != {'version', 'profiles', 'default', 'tasks'} or value['version'] != 1:
        raise ValueError('Invalid conflict settings. Open Conflict settings and save them again.')
    if value['default'] not in LABELS or not isinstance(value['tasks'], dict):
        raise ValueError('Invalid default conflict policy.')
    for tid, policy in value['tasks'].items():
        h.checked_id(tid)
        if policy not in LABELS:
            raise ValueError('Invalid task conflict policy.')
    if value['profiles'] != defaults()['profiles']:
        raise ValueError('Conflict settings belong to different profiles.')
    return copy.deepcopy(value)


def load():
    path = h.ROOT / 'conflict-policies.local.json'
    if not path.exists():
        return defaults()
    value = json.loads(path.read_text(encoding='utf-8'))
    if value.get('profiles') != defaults()['profiles']:
        return defaults()
    return validate(value)


def save(value):
    value = validate(value)
    h.atomic_json(h.ROOT / 'conflict-policies.local.json', value)
    return value


def effective(settings, tid):
    return settings['tasks'].get(tid, settings['default'])


def activity(view):
    """Use saved conversation activity, not file mtimes or a renamed title."""
    times = []
    for owner in view['rows']:
        for ref in merge.records(view, owner):
            record = ref['record']
            payload = record.get('payload', {})
            if record.get('type') == 'response_item' or (
                record.get('type') == 'event_msg' and payload.get('type') == 'item_completed'):
                value = merge.stamp(record.get('timestamp'))
                if value is not None:
                    times.append(value)
    return max(times) if times else None


def latest_choice(root, title):
    _, views = choices.read_pair(root)
    scores = {p: activity(v) for p, v in views.items()}
    if any(v is None for v in scores.values()):
        raise live.Deferred('A version has no saved message time. Decide later or choose a branch manually.')
    high = max(scores.values())
    candidates = [p for p, value in scores.items() if value == high]
    if len(candidates) != 1:
        raise live.Deferred('Both versions have the same latest message time. Decide later or choose a branch manually.')
    return {'id': root, 'title': title, 'source': candidates[0],
            'tokens': {p: choices.fingerprint(v) for p, v in views.items()}, 'activity_times': scores}


def new_report(settings):
    return {'settings': validate(settings), 'applied': [], 'later': [], 'deferred': [],
            'prepared': [], 'status': 'running', 'rewrote_histories': False}


def resolve(conflicts, result, progress, cancel, save_report=lambda: None):
    """Caller holds worker_lock. A preset is authorization, not another prompt."""
    settings = validate(result['settings'])
    for conflict in conflicts:
        if cancel.is_set():
            result['status'] = 'cancelled'; save_report(); return result
        root, title = conflict['id'], conflict['title']
        policy = effective(settings, root)
        entry = {'id': root, 'title': title, 'policy': policy}
        if policy == 'later':
            result['later'].append(entry); save_report(); continue
        try:
            if policy == 'latest':
                progress('Using the latest saved version: ' + title)
                request = latest_choice(root, title)
                chosen = choices.apply_choices([request], progress, cancel)
                if chosen['imported']:
                    result['applied'].append(dict(entry, source=request['source'],
                        target=chosen['imported'][0]['target'], backups=chosen['backup'],
                        activity_times=request['activity_times']))
                else:
                    reason = chosen['deferred'][0]['reason'] if chosen['deferred'] else 'Stopped before applying.'
                    result['deferred'].append(dict(entry, reason=reason))
            else:
                progress('Preparing chronological messages: ' + title)
                review = merge.preview(root, progress)
                review['ordering'] = 'messages'
                plan = merge.prepare(review, progress=progress)
                result['prepared'].append(dict(entry, path=str(Path(plan['directory'])/'plan.json'),
                                                warnings=plan['warnings'], status='prepared'))
        except (h.HandoffError, OSError, sqlite3.Error, ValueError) as exc:
            result['deferred'].append(dict(entry, reason=str(exc)))
            latest.pending_recovery()
        save_report()
    if result['prepared'] and not cancel.is_set():
        result['status'] = 'waiting_for_apps'; save_report()
        progress('Chronological merges are prepared and originals backed up. Quit BOTH Codex apps with Ctrl+Q; keep this launcher open. Stop keeps proposals for later.')
        if not sidebar.wait_for_profiles_exit(latest.PROFILES, cancel, progress):
            result['status'] = 'cancelled'; save_report(); return result
        for entry in result['prepared']:
            if cancel.is_set(): break
            try:
                plan = merge.apply(entry['path'], progress, cancel)
                entry['status'] = plan['status']
                if plan['status'] == 'completed':
                    result['rewrote_histories'] = True
                    result['applied'].append(dict(entry))
            except (h.HandoffError, OSError, sqlite3.Error, ValueError) as exc:
                entry['status'] = 'needs_review'
                result['deferred'].append(dict(entry, reason=str(exc)))
                save_report()
                latest.pending_recovery()
            save_report()
    result['status'] = 'cancelled' if cancel.is_set() else 'completed'
    save_report()
    return result
