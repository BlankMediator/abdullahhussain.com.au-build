"""Portable two-profile configuration. Passwords and login tokens never belong here."""
import json
import os
from pathlib import Path
import re
import subprocess
import sys
import uuid

PROGRAM = Path(__file__).resolve().parent
CONFIG = Path(os.environ.get('CODEX_SYNC_CONFIG', str(PROGRAM / 'profiles.local.json'))).resolve()
CURRENT = None


def validate(data):
    if set(data) != {'version', 'shared_folder', 'profiles'} or data['version'] != 1:
        raise ValueError('Unsupported configuration. Use Setup to save version 1.')
    shared = Path(data['shared_folder']).expanduser()
    if not shared.is_absolute() or str(shared).startswith('\\\\'):
        raise ValueError('Choose an absolute local shared folder on this PC, not a network share.')
    profiles = data['profiles']
    if not isinstance(profiles, list) or len(profiles) != 2:
        raise ValueError('Configure exactly two Windows profiles.')
    names, homes, accounts = set(), [], set()
    for p in profiles:
        if set(p) != {'name', 'home', 'account', 'app'}:
            raise ValueError('Each profile needs name, home, account and app only. Do not put credentials in this file.')
        if not re.fullmatch(r'[A-Za-z0-9][A-Za-z0-9 _-]{0,39}', p['name']):
            raise ValueError('Profile labels must be 1–40 letters, numbers, spaces, underscores or hyphens.')
        p['name'] = p['name'].strip()
        if p['name'].upper() in {'CON', 'PRN', 'AUX', 'NUL', *(f'COM{n}' for n in range(10)), *(f'LPT{n}' for n in range(10))}:
            raise ValueError('Choose a profile label that is not a reserved Windows filename.')
        if p['name'].casefold() in names: raise ValueError('Profile labels must be different.')
        names.add(p['name'].casefold())
        home = Path(p['home']).expanduser()
        app = Path(p['app']).expanduser()
        if not home.is_absolute() or not app.is_absolute() or app.suffix.lower() != '.exe':
            raise ValueError('Select absolute .codex folder and app .exe paths.')
        if not re.fullmatch(r'[^\r\n"/]+\\[^\r\n"/\\]+', p['account']):
            raise ValueError('Use the Windows account name as COMPUTER\\user or DOMAIN\\user.')
        if p['account'].casefold() in accounts: raise ValueError('Use two different Windows accounts.')
        accounts.add(p['account'].casefold())
        homes.append(home.resolve())
        p.update(home=str(home.resolve()), app=str(app.resolve()))
    if any(a == b or a.is_relative_to(b) or b.is_relative_to(a) for i, a in enumerate(homes) for b in homes[i+1:]):
        raise ValueError('The two .codex folders must be separate, with neither inside the other.')
    shared = shared.resolve()
    if any(shared.is_relative_to(home) or home.is_relative_to(shared) for home in homes):
        raise ValueError('The shared data folder must be separate from both .codex folders.')
    data['shared_folder'] = str(shared)
    return data


def load():
    return validate(json.loads(CONFIG.read_text(encoding='utf-8'))) if CONFIG.exists() else None


def save(data):
    import handoff as h
    data = validate(data)
    # Setup creates only the explicitly selected shared folder, never a profile.
    Path(data['shared_folder']).mkdir(parents=True, exist_ok=True)
    h.atomic_json(CONFIG, data)
    return data


def activate(data):
    global CURRENT
    import handoff as h
    import sync_latest as latest
    import sync_live as live
    import sync_profiles as combined
    import repair_sidebar as sidebar
    data = validate(data)
    CURRENT = data
    h.PROFILES = {p['name']: Path(p['home']) for p in data['profiles']}
    h.ACCOUNTS = {p['name']: p['account'] for p in data['profiles']}
    h.APPS = {p['name']: Path(p['app']) for p in data['profiles']}
    h.APP = next(iter(h.APPS.values()))
    h.ROOT = Path(data['shared_folder']); h.DATA = h.ROOT / 'data'
    latest.PROFILES = tuple(h.PROFILES)
    live.RUNS = h.ROOT / 'live-sync'; sidebar.RUNS = h.ROOT / 'sidebar-repair'; combined.RUNS = h.ROOT / 'profile-sync'
    h.launch_target = launch


def launch(profile, open_url=None):
    import handoff as h
    import windows_launch
    return windows_launch.account_action({'name':profile,'account':h.ACCOUNTS[profile],
        'home':str(h.PROFILES[profile]),'app':str(h.APPS[profile])},h.ROOT,**({'open_url':open_url} if open_url else {}))


def check(data, write_probe=True):
    """Check only selected locations; no ACL changes or account enumeration."""
    import handoff as h
    data = validate(data)
    result = []
    for p in data['profiles']:
        import repair_sidebar as sidebar
        sidebar.canonical_account(p['account'])
        home = Path(p['home'])
        for name in ('state_5.sqlite', 'thread_history_1.sqlite', 'sqlite/codex-dev.db'):
            with h.read_db(home / name) as db:
                if db.execute('PRAGMA quick_check').fetchone()[0] != 'ok':
                    raise ValueError('Database check failed: ' + p['name'] + '/' + name)
        if not Path(p['app']).is_file(): raise ValueError('App not found: ' + p['app'])
        result.append(p['name'] + ': app and history databases found')
    if write_probe:
        for folder in [Path(data['shared_folder'])] + [Path(p['home']) for p in data['profiles']]:
            probe = folder / ('.profile-sync-access-' + uuid.uuid4().hex)
            try:
                with probe.open('xb') as f: f.write(b'access check')
            finally:
                probe.unlink(missing_ok=True)
        result.append('The current Windows user can write to both profile folders and the shared folder.')
    result.append('Run this check from the other Windows account too. Folder permissions are managed by Windows; this tool does not change them.')
    return '\n'.join(result)


def wizard(parent, existing=None):
    import tkinter as tk
    from tkinter import ttk, filedialog, messagebox
    window = tk.Toplevel(parent); window.title('Set up two Codex profiles'); window.geometry('960x760')
    window.transient(parent); window.grab_set()
    frame = ttk.Frame(window, padding=18); frame.pack(fill='both', expand=True)
    ttk.Label(frame, text='Set up two Windows users and a shared sync folder', font=('Segoe UI', 17, 'bold')).pack(anchor='w')
    instructions = ('1. Create or select two Windows accounts. Sign into each Windows account once to initialize its user folder.\n'
        '2. Install the desktop app for each user, or select an existing app executable accessible to that user.\n'
        '3. Choose a local shared folder for sync backups and imported files. Both users need access.\n'
        '4. Enter each account’s actual COMPUTER\\user name and its separate .codex folder.\n'
        '5. Save, launch each app below, and sign into ChatGPT inside that app. Send a first task in each to create its databases.\n'
        'Windows password entry is available for either account, with optional saving in Windows Credential Manager. ChatGPT sign-in stays inside the app.')
    ttk.Label(frame, text=instructions, wraplength=910).pack(anchor='w', pady=12)
    shortcuts = ttk.Frame(frame); shortcuts.pack(fill='x')
    ttk.Button(shortcuts, text='Open Windows account settings', command=lambda: os.startfile('ms-settings:otherusers')).pack(side='left')
    ttk.Button(shortcuts, text='Open official app setup', command=lambda: __import__('webbrowser').open('https://learn.chatgpt.com/docs/windows/windows-app')).pack(side='left', padx=8)
    base = existing or {'shared_folder': str(PROGRAM / 'shared-data'), 'profiles': [
        {'name': 'Primary', 'home': str(Path.home()/'.codex'), 'account': os.environ.get('COMPUTERNAME','COMPUTER')+'\\'+os.environ.get('USERNAME','user'), 'app': ''},
        {'name': 'Secondary', 'home': '', 'account': os.environ.get('COMPUTERNAME','COMPUTER')+'\\', 'app': ''}]}
    shared = tk.StringVar(value=base['shared_folder'])
    row = ttk.Frame(frame); row.pack(fill='x', pady=12)
    ttk.Label(row, text='Shared sync folder:').pack(side='left')
    ttk.Entry(row, textvariable=shared).pack(side='left', fill='x', expand=True, padx=8)
    def choose_folder(var):
        value = filedialog.askdirectory(parent=window, mustexist=False)
        if value: var.set(value)
    ttk.Button(row, text='Select / create…', command=lambda: choose_folder(shared)).pack(side='left')
    forms = []
    for i, p in enumerate(base['profiles']):
        box = ttk.LabelFrame(frame, text=f'Windows profile {i+1}', padding=8); box.pack(fill='x', pady=6)
        vars = {k: tk.StringVar(value=p[k]) for k in ('name','account','home','app')}; forms.append(vars)
        for n, (key, label) in enumerate((('name','Label'),('account','Windows account'),('home','.codex folder'),('app','App executable'))):
            ttk.Label(box, text=label, width=19).grid(row=n, column=0, sticky='w')
            ttk.Entry(box, textvariable=vars[key]).grid(row=n,column=1,sticky='ew',pady=2)
            if key == 'home': ttk.Button(box,text='Browse…',command=lambda v=vars[key]: choose_folder(v)).grid(row=n,column=2)
            if key == 'app':
                def pick(v=vars[key]):
                    path=filedialog.askopenfilename(parent=window,filetypes=[('Windows applications','*.exe')])
                    if path:v.set(path)
                ttk.Button(box,text='Browse…',command=pick).grid(row=n,column=2)
        box.columnconfigure(1,weight=1)
    status = tk.StringVar(value='Folder access is configured through Windows Properties → Security. Give access only to the two intended users.')
    ttk.Label(frame,textvariable=status,wraplength=910).pack(anchor='w',pady=10)
    saved = []
    def data():return {'version':1,'shared_folder':shared.get().strip(),'profiles':[{k:v.get().strip() for k,v in f.items()} for f in forms]}
    def commit(close=False):
        try:
            value=save(data());activate(value);saved[:] = [value];status.set('Saved. Launch each app, sign in, then check access.');
            if close: window.destroy()
        except Exception as e:messagebox.showerror('Setup',str(e),parent=window)
    def check_now():
        try:status.set(check(data()))
        except Exception as e:status.set(str(e)+'\nInitialize both apps and grant this Windows user access to the selected folders, then retry.')
    def open_app(i):
        saved.clear()
        commit()
        if saved:
            try:launch(saved[0]['profiles'][i]['name'])
            except Exception as e:messagebox.showerror('Launch app',str(e),parent=window)
    buttons=ttk.Frame(frame);buttons.pack(fill='x',side='bottom',pady=8)
    ttk.Button(buttons,text='Save',command=commit).pack(side='left')
    ttk.Button(buttons,text='Launch profile 1 / sign in',command=lambda:open_app(0)).pack(side='left',padx=6)
    ttk.Button(buttons,text='Launch profile 2 / sign in',command=lambda:open_app(1)).pack(side='left',padx=6)
    ttk.Button(buttons,text='Check access',command=check_now).pack(side='left',padx=6)
    ttk.Button(buttons,text='Save and finish',command=lambda:commit(True)).pack(side='right')
    parent.wait_window(window)
    return saved[0] if saved else existing
