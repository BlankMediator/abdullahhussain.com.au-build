"""Version-gated desktop IPC relay. No profile database writes or model replay.

The native apps produce/consume the stream. This relay gives two configured
Windows accounts access to one local pipe, scopes cross-account traffic, and
preserves the desktop's discovery/request/broadcast protocol.
"""
import ctypes as c
from ctypes import wintypes as w
import hashlib
import json
import os
from pathlib import Path
import queue
import struct
import threading
import time
import uuid

PIPE = r'\\.\pipe\codex-ipc'
MAX_FRAME = 256 * 1024 * 1024
SUPPORTED_BUNDLE = 'a42da38cbb14b28399f1d54fcf453bffc5e9802663e7e098f187c8378f4c7a40'
VERSIONS = {'thread-stream-state-changed':11, 'thread-stream-following-changed':1,
    'thread-stream-following-status-requested':1, 'thread-owner-discovery':1,
    'thread-follower-start-turn':2, 'thread-follower-load-complete-history':1,
    'thread-follower-compact-thread':1, 'thread-follower-steer-turn':1,
    'thread-follower-interrupt-turn':4, 'thread-follower-update-thread-settings':2,
    'thread-follower-edit-last-user-turn':2, 'thread-follower-command-approval-decision':1,
    'thread-follower-file-approval-decision':1, 'thread-follower-permissions-request-approval-response':1,
    'thread-follower-submit-user-input':1, 'thread-follower-submit-mcp-server-elicitation-response':1,
    'thread-follower-set-queued-follow-ups-state':1, 'thread-queued-followups-changed':2}


class BridgeError(RuntimeError):
    pass


def check_bundle(app):
    """Fail closed on unknown private protocol builds; never patch app binaries."""
    path = Path(app).parent / 'resources/app.asar'
    with path.open('rb') as stream:
        header = stream.read(16)
        if len(header) != 16:
            raise BridgeError('App archive is incomplete.')
        sizes = struct.unpack('<4I', header)
        if sizes[3] > 32 * 1024 * 1024:
            raise BridgeError('App archive header is unsupported.')
        tree = json.loads(stream.read(sizes[3]))
        files = tree['files']['.vite']['files']['build']['files']
        node = files.get('src-CCXHtyvY.js')
        if not node:
            raise BridgeError('This app build has not been validated for the live connection.')
        stream.seek(8 + sizes[1] + int(node['offset']))
        digest = hashlib.sha256(stream.read(node['size'])).hexdigest()
    if digest != SUPPORTED_BUNDLE:
        raise BridgeError('The desktop IPC build changed. Live connection is disabled until its protocol is validated; history preservation remains available.')
    return digest


def frame(message):
    data = json.dumps(message, separators=(',', ':'), ensure_ascii=False).encode('utf-8')
    if not data or len(data) > MAX_FRAME:
        raise BridgeError('IPC message exceeds the desktop frame limit.')
    return struct.pack('<I', len(data)) + data


class Router:
    """Pure protocol state machine. Socket writes are queued, never under I/O."""
    def __init__(self, selected_ids):
        self.ids = frozenset(selected_ids)
        self.peers = {}
        self.pending = {}
        self.discoveries = {}
        self.lock = threading.RLock()
        self.stats = {'broadcasts':0, 'requests':0, 'blocked':0, 'stream_updates':0}
        self.followers = {}
        self.last_stream = {}

    def add(self, profile, send, pid=None):
        with self.lock:
            if len(self.peers) >= 128:
                raise BridgeError('Too many live clients.')
            peer = {'id':str(uuid.uuid4()), 'profile':profile, 'send':send, 'pid':pid, 'initialized':False, 'type':None}
            self.peers[peer['id']] = peer
            return peer

    def emit(self, peer, value):
        try:
            peer['send'](value)
            return True
        except Exception:
            self.stats['blocked'] += 1
            return False

    def error(self, peer, request_id, message):
        self.emit(peer, {'type':'response', 'requestId':request_id, 'resultType':'error', 'error':message})

    def allowed(self, source, target, message):
        if source['profile'] == target['profile']:
            return True
        method, params = message.get('method'), message.get('params') or {}
        if not isinstance(params, dict) or method not in VERSIONS:
            return False
        if params.get('conversationId') not in self.ids or params.get('hostId', 'local') != 'local' or message.get('hostId') not in (None, 'local'):
            return False
        version = message.get('version', 0)
        return version == VERSIONS[method] or (method == 'thread-follower-interrupt-turn' and version == 3)

    def receive(self, peer, message):
        if not isinstance(message, dict):
            raise BridgeError('Invalid IPC envelope.')
        with self.lock:
            if peer['id'] not in self.peers:
                return
            kind, method = message.get('type'), message.get('method')
            if kind == 'request' and method == 'initialize':
                if not peer['initialized']:
                    peer['initialized'] = True
                    peer['type'] = str((message.get('params') or {}).get('clientType', 'unknown'))[:100]
                    self.client_status(peer, 'connected')
                self.emit(peer, {'type':'response','requestId':message.get('requestId'),'resultType':'success',
                                 'method':'initialize','handledByClientId':peer['id'],'result':{'clientId':peer['id']}})
                return
            if not peer['initialized']:
                raise BridgeError('Client did not initialize.')
            if kind == 'broadcast':
                # Router lifecycle identities may not be forged by clients.
                if method in ('client-status-changed', 'ipc-connection-reset'):
                    self.stats['blocked'] += 1
                    return
                outgoing = dict(message, sourceClientId=peer['id'])
                targets = message.get('targetClientIds')
                delivered = False
                for target in list(self.peers.values()):
                    if target is peer or not target['initialized'] or (targets is not None and target['id'] not in targets):
                        continue
                    if self.allowed(peer, target, outgoing):
                        sent = self.emit(target, outgoing)
                        delivered = delivered or (sent and target['profile'] != peer['profile'])
                self.stats['broadcasts'] += 1
                params = message.get('params') or {}
                tid = params.get('conversationId')
                if tid in self.ids and method == 'thread-stream-state-changed' and delivered:
                    self.stats['stream_updates'] += 1
                    self.last_stream[tid] = {'profile':peer['profile'], 'time':time.time()}
                if tid in self.ids and method == 'thread-stream-following-changed':
                    self.followers.setdefault(tid, {})[peer['id']] = {'profile':peer['profile'], 'following':params.get('following') is True}
                return
            if kind == 'request':
                if len(self.pending) >= 1024:
                    self.error(peer, message.get('requestId'), 'router-busy')
                    return
                targets = [other for other in self.peers.values() if other is not peer and other['initialized']
                           and (not message.get('targetClientId') or message['targetClientId'] == other['id'])
                           and self.allowed(peer, other, message)]
                if not targets:
                    self.error(peer, message.get('requestId'), 'no-client-found')
                    return
                routed = str(uuid.uuid4())
                timeout = message.get('timeoutMs') or 10000
                if not isinstance(timeout, (int, float)):
                    timeout = 10000
                state = {'source':peer['id'], 'original':message.get('requestId'),
                         'message':dict(message, sourceClientId=peer['id']), 'target':None,
                         'deadline':time.monotonic() + max(1, min(timeout / 1000, 120)), 'candidates':set()}
                self.pending[routed] = state
                # Populate before sends: in-memory test clients can respond immediately.
                outgoing = []
                for target in targets:
                    discovery = str(uuid.uuid4())
                    state['candidates'].add(discovery)
                    self.discoveries[discovery] = (routed, target['id'])
                    outgoing.append((target, {'type':'client-discovery-request','requestId':discovery,'request':state['message']}))
                for target, packet in outgoing:
                    self.emit(target, packet)
                return
            if kind == 'client-discovery-response':
                discovery = self.discoveries.get(message.get('requestId'))
                if not discovery or discovery[1] != peer['id']:
                    return
                self.discoveries.pop(message['requestId'])
                routed, target_id = discovery
                state = self.pending.get(routed)
                if not state:
                    return
                state['candidates'].discard(message['requestId'])
                if state['target']:
                    return
                if (message.get('response') or {}).get('canHandle') is True:
                    state['target'] = target_id
                    self.stats['requests'] += 1
                    self.emit(peer, dict(state['message'], requestId=routed))
                elif not state['candidates']:
                    self.finish(routed, error='no-client-found')
                return
            if kind == 'response':
                routed = message.get('requestId')
                state = self.pending.get(routed)
                if state and state['target'] == peer['id']:
                    self.finish(routed, response=dict(message, handledByClientId=peer['id']))

    def finish(self, routed, response=None, error=None):
        state = self.pending.pop(routed, None)
        if not state:
            return
        for discovery in state['candidates']:
            self.discoveries.pop(discovery, None)
        source = self.peers.get(state['source'])
        if source:
            if error:
                self.error(source, state['original'], error)
            else:
                self.emit(source, dict(response, requestId=state['original']))

    def client_status(self, peer, status):
        packet = {'type':'broadcast','method':'client-status-changed','version':0,'sourceClientId':peer['id'],
                  'params':{'clientId':peer['id'],'clientType':peer['type'],'status':status}}
        for other in list(self.peers.values()):
            if other is not peer and other['initialized']:
                self.emit(other, packet)

    def remove(self, peer):
        with self.lock:
            if not self.peers.pop(peer['id'], None):
                return
            if peer['initialized']:
                self.client_status(peer, 'disconnected')
            for routed, state in list(self.pending.items()):
                if peer['id'] in (state['target'], state['source']):
                    self.finish(routed, error='client-disconnected')
            for discovery, (routed, target) in list(self.discoveries.items()):
                if target == peer['id']:
                    self.discoveries.pop(discovery, None)
                    state = self.pending.get(routed)
                    if state:
                        state['candidates'].discard(discovery)
                        if not state['target'] and not state['candidates']:
                            self.finish(routed, error='no-client-found')
            for followers in self.followers.values():
                followers.pop(peer['id'], None)

    def expire(self):
        with self.lock:
            for routed, state in list(self.pending.items()):
                if time.monotonic() >= state['deadline']:
                    self.finish(routed, error='request-timeout')

    def status(self):
        with self.lock:
            clients = [{'profile':p['profile'],'pid':p['pid'],'type':p['type']} for p in self.peers.values() if p['initialized']]
            return dict(self.stats, clients=clients, followers={tid:list(rows.values()) for tid,rows in self.followers.items()}, last_stream=dict(self.last_stream))


class SecurityAttributes(c.Structure):
    _fields_ = [('length',w.DWORD),('descriptor',c.c_void_p),('inherit',w.BOOL)]


class Overlapped(c.Structure):
    _fields_ = [('internal',c.c_size_t),('internal_high',c.c_size_t),
                ('offset',w.DWORD),('offset_high',w.DWORD),('event',w.HANDLE)]


def kernel():
    k = c.WinDLL('kernel32', use_last_error=True)
    k.CreateNamedPipeW.argtypes = [w.LPCWSTR,w.DWORD,w.DWORD,w.DWORD,w.DWORD,w.DWORD,w.DWORD,c.POINTER(SecurityAttributes)]
    k.CreateNamedPipeW.restype = w.HANDLE
    k.ConnectNamedPipe.argtypes = [w.HANDLE,c.c_void_p]
    k.DisconnectNamedPipe.argtypes = [w.HANDLE]
    k.CloseHandle.argtypes = [w.HANDLE]
    k.ReadFile.argtypes = [w.HANDLE,c.c_void_p,w.DWORD,c.POINTER(w.DWORD),c.c_void_p]
    k.WriteFile.argtypes = [w.HANDLE,c.c_void_p,w.DWORD,c.POINTER(w.DWORD),c.c_void_p]
    k.CancelIoEx.argtypes = [w.HANDLE,c.c_void_p]
    k.GetNamedPipeClientProcessId.argtypes = [w.HANDLE,c.POINTER(w.ULONG)]
    k.GetNamedPipeClientSessionId.argtypes = [w.HANDLE,c.POINTER(w.ULONG)]
    k.ProcessIdToSessionId.argtypes = [w.DWORD,c.POINTER(w.DWORD)]
    k.LocalFree.argtypes = [c.c_void_p]
    k.CreateEventW.argtypes = [c.c_void_p,w.BOOL,w.BOOL,w.LPCWSTR]
    k.CreateEventW.restype = w.HANDLE
    k.WaitForSingleObject.argtypes = [w.HANDLE,w.DWORD]
    k.GetOverlappedResult.argtypes = [w.HANDLE,c.POINTER(Overlapped),c.POINTER(w.DWORD),w.BOOL]
    return k


class PipeServer:
    def __init__(self, selected_ids, accounts, apps, pipe=PIPE, verify_apps=True):
        import windows_launch
        from setup_support import account_sid
        windows_launch.require_standard()
        if verify_apps:
            for app in set(map(str, apps.values())):
                check_bundle(app)
        self.accounts = {windows_launch.canonical(a).casefold():p for p,a in accounts.items()}
        self.apps = {str(Path(app).resolve()).casefold() for app in apps.values()}
        self.pipe = pipe
        self.router = Router(selected_ids)
        self.stop = threading.Event()
        self.handles = set()
        self.guard = threading.Lock()
        self.errors = []
        self.k = kernel()
        self.session = w.DWORD()
        if not self.k.ProcessIdToSessionId(os.getpid(),c.byref(self.session)):
            raise c.WinError(c.get_last_error())
        # Only the two selected Windows users and SYSTEM; remote access refused.
        # The server's creator gets full control; clients need read/write access.
        sids = sorted({account_sid(a) for a in accounts.values()})
        current_sid = account_sid(windows_launch.current_account())
        if current_sid not in sids:
            raise BridgeError('Open the live launcher under one of the two configured Windows accounts.')
        sddl = 'D:P(A;;GA;;;SY)' + ''.join('(A;;'+('GA' if sid == current_sid else 'GRGW')+';;;'+sid+')' for sid in sids)
        adv = c.WinDLL('advapi32',use_last_error=True)
        adv.ConvertStringSecurityDescriptorToSecurityDescriptorW.argtypes=[w.LPCWSTR,w.DWORD,c.POINTER(c.c_void_p),c.c_void_p]
        descriptor = c.c_void_p()
        if not adv.ConvertStringSecurityDescriptorToSecurityDescriptorW(sddl,1,c.byref(descriptor),None):
            raise c.WinError(c.get_last_error())
        self.descriptor = descriptor
        self.security = SecurityAttributes(c.sizeof(SecurityAttributes),descriptor,False)
        self.accept_thread = None

    def create(self, first=False):
        handle = self.k.CreateNamedPipeW(self.pipe,3 | 0x40000000 | (0x80000 if first else 0),8,128,65536,65536,1000,c.byref(self.security))
        if handle == c.c_void_p(-1).value:
            code = c.get_last_error()
            if code in (5,231):
                raise BridgeError('The desktop live pipe is already owned by another app or launcher. Quit both apps (and other Codex IPC clients), then reconnect. No process was stopped.')
            raise c.WinError(code)
        with self.guard:
            self.handles.add(handle)
        return handle

    def start(self):
        try:
            first = self.create(first=True)
        except BaseException:
            self.k.LocalFree(self.descriptor)
            self.descriptor = None
            raise
        self.accept_thread = threading.Thread(target=self.accept, args=(first,), daemon=True)
        self.accept_thread.start()
        return self

    def release(self, handle):
        with self.guard:
            if handle not in self.handles:
                return
            self.handles.remove(handle)
        self.k.DisconnectNamedPipe(handle)
        self.k.CloseHandle(handle)

    def accept(self, handle):
        try:
            while not self.stop.is_set():
                self.io('connect',handle)
                if self.stop.is_set():
                    break
                active = handle
                # Keep a listening instance alive before handing off this one.
                handle = self.create()
                threading.Thread(target=self.serve,args=(active,),daemon=True).start()
        except Exception as exc:
            self.errors.append(str(exc))
        finally:
            self.release(handle)

    def io(self, operation, handle, buffer=None, size=0):
        event=self.k.CreateEventW(None,True,False,None)
        if not event:raise c.WinError(c.get_last_error())
        overlapped=Overlapped(event=event);count=w.DWORD();pending=False
        try:
            if operation=='connect':
                ok=self.k.ConnectNamedPipe(handle,c.byref(overlapped))
            elif operation=='read':
                ok=self.k.ReadFile(handle,buffer,size,c.byref(count),c.byref(overlapped))
            else:
                ok=self.k.WriteFile(handle,buffer,size,c.byref(count),c.byref(overlapped))
            code=c.get_last_error()
            if not ok and operation=='connect' and code==535:return 0
            if not ok and code!=997:raise EOFError() if code in (109,232,233,995) else c.WinError(code)
            pending=not ok
            while pending:
                wait=self.k.WaitForSingleObject(event,200)
                if wait==0:break
                if self.stop.is_set():
                    self.k.CancelIoEx(handle,c.byref(overlapped))
                    break
                if wait!=258:raise c.WinError(c.get_last_error())
            if not self.k.GetOverlappedResult(handle,c.byref(overlapped),c.byref(count),True):
                raise EOFError()
            return count.value
        finally:
            # OVERLAPPED/buffer storage must outlive a cancelled operation.
            if pending:
                self.k.CancelIoEx(handle,c.byref(overlapped))
                self.k.GetOverlappedResult(handle,c.byref(overlapped),c.byref(count),True)
            self.k.CloseHandle(event)

    def identify(self, handle):
        import repair_sidebar
        import windows_launch
        pid, session = w.ULONG(), w.ULONG()
        if not self.k.GetNamedPipeClientProcessId(handle,c.byref(pid)) or not self.k.GetNamedPipeClientSessionId(handle,c.byref(session)):
            raise c.WinError(c.get_last_error())
        if session.value != self.session.value:
            raise BridgeError('The live client is in another Windows session.')
        account = repair_sidebar.process_owner(pid.value)
        profile = self.accounts.get((account or '').casefold())
        if profile is None:
            raise BridgeError('The live client account could not be verified.')
        # Tests use unique disposable pipes; production accepts configured apps only.
        if self.pipe == PIPE:
            k,_=windows_launch.native()
            k.OpenProcess.argtypes=[w.DWORD,w.BOOL,w.DWORD];k.OpenProcess.restype=w.HANDLE
            k.QueryFullProcessImageNameW.argtypes=[w.HANDLE,w.DWORD,w.LPWSTR,c.POINTER(w.DWORD)]
            process=k.OpenProcess(0x1000,False,pid.value)
            if not process:
                raise c.WinError(c.get_last_error())
            try:
                path,size=c.create_unicode_buffer(32768),w.DWORD(32768)
                if not k.QueryFullProcessImageNameW(process,0,path,c.byref(size)):
                    raise c.WinError(c.get_last_error())
                if str(Path(path.value).resolve()).casefold() not in self.apps:
                    raise BridgeError('The client executable is not one of the configured apps.')
                windows_launch.require_standard(process)
            finally:
                k.CloseHandle(process)
        return profile,pid.value

    def read_exact(self, handle, size):
        parts=[]
        while size and not self.stop.is_set():
            buf=c.create_string_buffer(min(size,65536))
            got=self.io('read',handle,buf,len(buf))
            if not got:
                raise EOFError()
            parts.append(buf.raw[:got]);size-=got
        if size:
            raise EOFError()
        return b''.join(parts)

    def serve(self, handle):
        peer=None
        outbound=queue.Queue(maxsize=64)
        queued_bytes=[0]
        queue_lock=threading.Lock()
        ended=threading.Event()
        def enqueue(message):
            packet=frame(message)
            try:
                with queue_lock:
                    if queued_bytes[0]+len(packet)>MAX_FRAME:raise queue.Full()
                    outbound.put_nowait(packet)
                    queued_bytes[0]+=len(packet)
            except queue.Full:
                ended.set();self.k.CancelIoEx(handle,None)
                raise BridgeError('A live client stopped reading; its connection was closed.')
        def writer():
            try:
                while not self.stop.is_set() and not ended.is_set():
                    try:data=outbound.get(timeout=.2)
                    except queue.Empty:continue
                    with queue_lock:queued_bytes[0]-=len(data)
                    offset=0
                    while offset<len(data):
                        block=data[offset:offset+65536]
                        count=self.io('write',handle,block,len(block))
                        if not count:
                            raise EOFError()
                        offset+=count
            except Exception:
                ended.set();self.k.CancelIoEx(handle,None)
        worker=None
        try:
            profile,pid=self.identify(handle)
            peer=self.router.add(profile,enqueue,pid)
            worker=threading.Thread(target=writer,daemon=True);worker.start()
            while not self.stop.is_set() and not ended.is_set():
                length=struct.unpack('<I',self.read_exact(handle,4))[0]
                if not 0<length<=MAX_FRAME:
                    raise BridgeError('Invalid desktop IPC frame length.')
                message=json.loads(self.read_exact(handle,length))
                self.router.receive(peer,message)
        except EOFError:
            pass
        except Exception as exc:
            self.errors.append(str(exc))
            self.errors[:]=self.errors[-8:]
        finally:
            ended.set()
            if peer:
                self.router.remove(peer)
            self.k.CancelIoEx(handle,None)
            self.release(handle)

    def status(self):
        self.router.expire()
        return dict(self.router.status(), errors=list(self.errors), listening=bool(self.accept_thread and self.accept_thread.is_alive()))

    def close(self):
        self.stop.set()
        with self.guard:
            handles=list(self.handles)
        for handle in handles:
            self.k.CancelIoEx(handle,None)
            self.k.DisconnectNamedPipe(handle)
        if self.accept_thread:
            self.accept_thread.join(2)
        for handle in handles:
            self.release(handle)
        if self.descriptor:
            self.k.LocalFree(self.descriptor)
            self.descriptor=None

    def discover_owner(self, task, profile, timeout=15):
        responses=queue.Queue()
        peer=self.router.add(profile,responses.put)
        self.router.receive(peer,{'type':'request','method':'initialize','requestId':'init','params':{'clientType':'profile-sync-probe'}})
        self.router.receive(peer,{'type':'request','method':'thread-owner-discovery','requestId':'owner','version':1,
            'timeoutMs':int(timeout*1000),'params':{'hostId':'local','conversationId':task}})
        deadline=time.monotonic()+timeout
        try:
            while time.monotonic()<deadline and not self.stop.is_set():
                try:packet=responses.get(timeout=.2)
                except queue.Empty:
                    self.router.expire();continue
                if packet.get('type')=='response' and packet.get('requestId')=='owner':
                    return packet.get('handledByClientId') if packet.get('resultType')=='success' else None
            return None
        finally:
            self.router.remove(peer)
