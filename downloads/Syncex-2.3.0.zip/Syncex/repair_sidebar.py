"""Merge desktop projects, task names and search metadata after Secondary exits.

Does not copy authentication, replace history databases, or stop either app.
The source app can remain running. Run this launcher from the normal desktop.
"""
import copy
import ctypes
from ctypes import wintypes
from datetime import datetime, timezone
import json
import os
from pathlib import Path
import shutil
import sqlite3
import threading
import uuid
import handoff as h
import sync_live as live

RUNS = h.ROOT / 'sidebar-repair'
GLOBAL = '.codex-global-state.json'


def canonical_account(account):
    """Resolve Windows aliases before comparing process owners; fail if unknown."""
    a = ctypes.WinDLL('advapi32', use_last_error=True)
    a.LookupAccountNameW.argtypes = [wintypes.LPCWSTR, wintypes.LPCWSTR, ctypes.c_void_p,
        ctypes.POINTER(wintypes.DWORD), wintypes.LPWSTR, ctypes.POINTER(wintypes.DWORD), ctypes.POINTER(wintypes.DWORD)]
    a.LookupAccountSidW.argtypes = [wintypes.LPCWSTR, ctypes.c_void_p, wintypes.LPWSTR,
        ctypes.POINTER(wintypes.DWORD), wintypes.LPWSTR, ctypes.POINTER(wintypes.DWORD), ctypes.POINTER(wintypes.DWORD)]
    size, domain_size, kind = wintypes.DWORD(), wintypes.DWORD(), wintypes.DWORD()
    a.LookupAccountNameW(None, account, None, ctypes.byref(size), None, ctypes.byref(domain_size), ctypes.byref(kind))
    if not size.value:
        raise h.HandoffError('Windows account could not be resolved: ' + account + '. Check Setup and whoami.')
    sid = ctypes.create_string_buffer(size.value)
    domain = ctypes.create_unicode_buffer(max(domain_size.value, 1))
    if not a.LookupAccountNameW(None, account, sid, ctypes.byref(size), domain, ctypes.byref(domain_size), ctypes.byref(kind)):
        raise h.HandoffError('Windows account lookup failed: ' + account)
    name_size, out_domain_size = wintypes.DWORD(512), wintypes.DWORD(512)
    name, out_domain = ctypes.create_unicode_buffer(512), ctypes.create_unicode_buffer(512)
    if not a.LookupAccountSidW(None, sid, name, ctypes.byref(name_size), out_domain, ctypes.byref(out_domain_size), ctypes.byref(kind)):
        raise h.HandoffError('Windows account name could not be verified: ' + account)
    return out_domain.value + '\\' + name.value


def process_owner(pid):
    k = ctypes.WinDLL('kernel32', use_last_error=True)
    a = ctypes.WinDLL('advapi32', use_last_error=True)
    k.OpenProcess.argtypes = [wintypes.DWORD, wintypes.BOOL, wintypes.DWORD]
    k.OpenProcess.restype = wintypes.HANDLE
    k.CloseHandle.argtypes = [wintypes.HANDLE]
    a.OpenProcessToken.argtypes = [wintypes.HANDLE, wintypes.DWORD, ctypes.POINTER(wintypes.HANDLE)]
    a.GetTokenInformation.argtypes = [wintypes.HANDLE, ctypes.c_int, ctypes.c_void_p, wintypes.DWORD, ctypes.POINTER(wintypes.DWORD)]
    a.LookupAccountSidW.argtypes = [wintypes.LPCWSTR, ctypes.c_void_p, wintypes.LPWSTR, ctypes.POINTER(wintypes.DWORD), wintypes.LPWSTR, ctypes.POINTER(wintypes.DWORD), ctypes.POINTER(wintypes.DWORD)]
    proc = k.OpenProcess(0x1000, False, pid)
    if not proc:
        if ctypes.get_last_error() == 87:  # Process exited during enumeration.
            return None
        raise h.HandoffError(f'Cannot open ChatGPT process {pid} to identify its owner (Windows error {ctypes.get_last_error()}).')
    token = wintypes.HANDLE()
    try:
        if not a.OpenProcessToken(proc, 8, ctypes.byref(token)):
            raise h.HandoffError(f'Cannot read the owner of ChatGPT process {pid} (Windows error {ctypes.get_last_error()}).')
        size = wintypes.DWORD()
        a.GetTokenInformation(token, 1, None, 0, ctypes.byref(size))
        buf = ctypes.create_string_buffer(size.value)
        if not a.GetTokenInformation(token, 1, buf, size, ctypes.byref(size)):
            raise ctypes.WinError(ctypes.get_last_error())
        sid = ctypes.c_void_p.from_buffer(buf).value
        nc, dc, kind = wintypes.DWORD(256), wintypes.DWORD(256), wintypes.DWORD()
        name, domain = ctypes.create_unicode_buffer(256), ctypes.create_unicode_buffer(256)
        if not a.LookupAccountSidW(None, sid, name, ctypes.byref(nc), domain, ctypes.byref(dc), ctypes.byref(kind)):
            raise ctypes.WinError(ctypes.get_last_error())
        return domain.value + '\\' + name.value
    finally:
        if token:
            k.CloseHandle(token)
        k.CloseHandle(proc)


def app_process_tree():
    # Chromium sandbox children can deny token queries. Resolve those through
    # their still-running ChatGPT parent, never by assuming an unknown owner.
    class Entry(ctypes.Structure):
        _fields_ = [('size', wintypes.DWORD), ('usage', wintypes.DWORD), ('pid', wintypes.DWORD),
                    ('heap', ctypes.c_size_t), ('module', wintypes.DWORD), ('threads', wintypes.DWORD),
                    ('parent', wintypes.DWORD), ('priority', wintypes.LONG), ('flags', wintypes.DWORD),
                    ('name', wintypes.WCHAR * 260)]
    k = ctypes.WinDLL('kernel32', use_last_error=True)
    k.CreateToolhelp32Snapshot.argtypes = [wintypes.DWORD, wintypes.DWORD]
    k.CreateToolhelp32Snapshot.restype = wintypes.HANDLE
    k.CloseHandle.argtypes = [wintypes.HANDLE]
    for fn in (k.Process32FirstW, k.Process32NextW):
        fn.argtypes = [wintypes.HANDLE, ctypes.POINTER(Entry)]
        fn.restype = wintypes.BOOL
    handle = k.CreateToolhelp32Snapshot(2, 0)
    if handle == ctypes.c_void_p(-1).value:
        raise ctypes.WinError(ctypes.get_last_error())
    result = {}
    try:
        row = Entry()
        row.size = ctypes.sizeof(row)
        ok = k.Process32FirstW(handle, ctypes.byref(row))
        if not ok:
            raise ctypes.WinError(ctypes.get_last_error())
        while ok:
            if row.name.lower() in {Path(p).name.lower() for p in getattr(h, 'APPS', {'default': h.APP}).values()}:
                result[row.pid] = row.parent
            ok = k.Process32NextW(handle, ctypes.byref(row))
        if ctypes.get_last_error() != 18:
            raise ctypes.WinError(ctypes.get_last_error())
    finally:
        k.CloseHandle(handle)
    return result


class AppProcesses(list):
    """Processes that might belong to a profile, with unresolved IDs retained."""
    def __init__(self, pids, unknown=()):
        super().__init__(pids)
        self.unknown = tuple(sorted(unknown))


def profile_apps(profile):
    tree, owners, unknown = app_process_tree(), {}, set()
    def owner(pid, seen=frozenset()):
        if pid in owners:
            return owners[pid]
        if pid in seen:
            unknown.add(pid)
            return None
        try:
            value = process_owner(pid)
        except (h.HandoffError, OSError):
            parent = tree[pid]
            value = owner(parent, seen | {pid}) if parent in tree else None
            if value is None:
                unknown.add(pid)
        owners[pid] = value
        return value
    wanted = canonical_account(h.ACCOUNTS[profile]).casefold()
    for pid in tree:
        owner(pid)
    # An unreadable process is a blocker for either profile, never evidence
    # that an app has exited. A later enumeration can confirm its exit.
    return AppProcesses([pid for pid in tree if pid in unknown or (owners[pid] or '').casefold() == wanted], unknown)


def unknown_process_message(pids):
    return ('Windows cannot identify the owner of ChatGPT process(es) ' + ', '.join(map(str, pids)) +
            '. Quit BOTH Codex/ChatGPT apps with Ctrl+Q; keep this sync launcher open. '
            'Sync will resume when the apps have exited. Stop keeps completed copies.')


def wait_for_profiles_exit(profiles, cancel, progress=lambda text: None):
    """Wait conservatively when cross-account token queries are denied."""
    previous = None
    while not cancel.is_set():
        pending, unknown = [], set()
        for profile in profiles:
            apps = profile_apps(profile)
            if apps:
                pending.append(profile)
            unknown.update(getattr(apps, 'unknown', ()))
        if not pending:
            if cancel.wait(2):
                return False
            # Recheck after the quiet interval so a reopening app still blocks.
            if not any(profile_apps(profile) for profile in profiles):
                return True
            continue
        message = (unknown_process_message(sorted(unknown)) if unknown else
                   'Waiting for ' + ', '.join(pending) + ' to exit. Use Ctrl+Q and keep this sync launcher open.')
        if message != previous:
            progress(message)
            previous = message
        if cancel.wait(1):
            return False
    return False


def alt_apps():
    return profile_apps('Secondary')


def require_profile_closed(profile):
    apps = profile_apps(profile)
    if getattr(apps, 'unknown', ()):
        raise h.HandoffError(unknown_process_message(apps.unknown))
    if apps:
        raise h.HandoffError(f'{profile} is still running. Quit it with Ctrl+Q; the source app can stay open.')


def require_alt_closed():
    if alt_apps():
        raise h.HandoffError('Secondary is still running. Quit Secondary with Ctrl+Q; Primary can stay open.')


def load_json(path):
    return json.loads(path.read_text(encoding='utf-8')) if path.exists() else {}


def merged_global(source, target, source_rows, target_rows, source_profile='Primary', target_profile='Secondary'):
    result = copy.deepcopy(target)
    projects = result.setdefault('local-projects', {})
    for pid, value in source.get('local-projects', {}).items():
        old = projects.get(pid)
        if not old or value.get('updatedAt', 0) >= old.get('updatedAt', 0):
            projects[pid] = copy.deepcopy(value)
    for key in ('project-order', 'electron-saved-workspace-roots'):
        result[key] = list(dict.fromkeys(source.get(key, []) + target.get(key, [])))
    labels = result.setdefault('electron-workspace-root-labels', {})
    labels.update(source.get('electron-workspace-root-labels', {}))
    assignments = result.setdefault('thread-project-assignments', {})
    for tid, value in source.get('thread-project-assignments', {}).items():
        if tid in target_rows and tid in source_rows and target_rows[tid]['updated_at'] <= source_rows[tid]['updated_at']:
            assignments[tid] = copy.deepcopy(value)
    key = 'app-server-project-id-by-legacy-project-id-by-host'
    source_map = source.get(key, {}).get('local:' + str(h.PROFILES[source_profile]), {})
    result.setdefault(key, {}).setdefault('local:' + str(h.PROFILES[target_profile]), {}).update(source_map)
    for key in ('project-appearances', 'sidebar-project-thread-orders'):
        dest = result.setdefault(key, {})
        for k, v in source.get(key, {}).items():
            if k not in projects and k not in source_map.values():
                continue
            if key == 'sidebar-project-thread-orders' and isinstance(v, list):
                dest[k] = list(dict.fromkeys(v + (dest.get(k, []) if isinstance(dest.get(k, []), list) else [])))
            else:
                dest[k] = copy.deepcopy(v)
    # Preserve target's migration status, current task, account, UI preferences,
    # permissions, writable roots, connection IDs, and selected project.
    return result


def index_rows(path):
    result = {}
    if path.exists():
        for line in path.read_text(encoding='utf-8').splitlines():
            if line.strip():
                row = json.loads(line)
                result[row['id']] = row
    return result


def repair(gate=None, source_profile='Primary', target_profile='Secondary', excluded_ids=(), allowed_ids=None, project_ids=None, scoped=False):
    source, target = live.direction(source_profile, target_profile)
    gate = gate or (require_alt_closed if target_profile == 'Secondary' else lambda: require_profile_closed(target_profile))
    gate()
    for folder in (live.RUNS, h.ROOT / 'one-time-sync', h.DATA / 'transfers'):
        if any(load_json(p).get('status') in ('applying', 'recovery_required') for p in folder.glob('*/journal.json')):
            raise h.HandoffError('Recover the interrupted history import in its original launcher first.')
    sg, tg = load_json(source / GLOBAL), load_json(target / GLOBAL)
    expected_global = h.digest(target / GLOBAL)
    with h.read_db(source / 'state_5.sqlite') as c:
        source_rows = {r['id']: dict(r) for r in c.execute("SELECT * FROM threads WHERE source='vscode'")
                       if r['id'] not in excluded_ids and (allowed_ids is None or r['id'] in allowed_ids)}
        projects = h.table_rows(c, 'projects')
        roots = h.table_rows(c, 'project_roots')
    if scoped:
        from selection import scope_global, project_for
        selected_projects = set(project_ids or ())
        selected_projects.update(project_for(row, sg, source, roots) for row in source_rows.values())
        selected_projects.discard(None)
        projects = [row for row in projects if row['id'] in selected_projects]
        roots = [row for row in roots if row['project_id'] in selected_projects]
        sg = scope_global(sg, source, selected_projects, set(source_rows), roots)
    with h.read_db(source / 'sqlite/codex-dev.db') as c:
        source_catalog = {r['thread_id']: dict(r) for r in c.execute("SELECT * FROM local_thread_catalog WHERE host_id='local'")}
    source_index = index_rows(source / 'session_index.jsonl')
    target_index = index_rows(target / 'session_index.jsonl')
    index_path = target / 'session_index.jsonl'
    expected_index = h.digest(index_path) if index_path.exists() else None
    run = RUNS / (datetime.now().strftime('%Y%m%d-%H%M%S') + '-' + uuid.uuid4().hex[:8])
    run.mkdir(parents=True)
    for rel in ('state_5.sqlite', 'sqlite/codex-dev.db'):
        h.backup_db(target / rel, run / 'before' / rel)
    for name in (GLOBAL, GLOBAL + '.bak', 'session_index.jsonl'):
        if (target / name).exists():
            shutil.copyfile(target / name, run / 'before' / name)
    report = {'started': h.now(), 'source': source_profile, 'target': target_profile, 'status': 'applying', 'backup': str(run), 'names': [], 'projects': 0}
    h.atomic_json(run / 'report.json', report)
    with live.target_db(target_profile) as c:
        c.execute('BEGIN IMMEDIATE')
        try:
            gate()
            target_rows = {r['id']: dict(r) for r in c.execute('SELECT * FROM threads')}
            old_projects = {r['id']: dict(r) for r in c.execute('SELECT * FROM projects')}
            for row in projects:
                old = old_projects.get(row['id'])
                if old and old['updated_at_ms'] > row['updated_at_ms']:
                    continue
                h.insert_rows(c, 'main', 'projects', [row], replace=True)
                c.execute('DELETE FROM project_roots WHERE project_id=?', (row['id'],))
                h.insert_rows(c, 'main', 'project_roots', [r for r in roots if r['project_id'] == row['id']], replace=True)
            project_ids = {r[0] for r in c.execute('SELECT id FROM projects')}
            mapping = sg.get('app-server-project-id-by-legacy-project-id-by-host', {}).get('local:' + str(source), {})
            seq = c.execute("SELECT observation_sequence+1 FROM catalog_db.local_thread_catalog_sync_state WHERE host_id='local'").fetchone()[0]
            for tid, src in source_rows.items():
                dst = target_rows.get(tid)
                if not dst or dst['updated_at'] > src['updated_at']:
                    continue
                name = src.get('name') or source_catalog.get(tid, {}).get('display_title') or src['title'].splitlines()[0]
                assignment = sg.get('thread-project-assignments', {}).get(tid, {}).get('projectId')
                pid = mapping.get(assignment, assignment) if assignment else src.get('project_id') or dst.get('project_id')
                if pid not in project_ids:
                    pid = dst.get('project_id')
                c.execute('UPDATE threads SET name=?,project_id=? WHERE id=?', (name, pid, tid))
                dst = dict(dst, name=name, project_id=pid)
                if not dst['archived']:
                    cat = live.make_catalog(c, {'threads': [dst]})[0]
                    cat['observation_sequence'] = seq
                    cat['pending_observed_title'] = 1
                    h.insert_rows(c, 'catalog_db', 'local_thread_catalog', [cat], replace=True)
                old_index = target_index.get(tid, {})
                incoming = source_index.get(tid, {})
                if incoming.get('updated_at', '') >= old_index.get('updated_at', ''):
                    target_index[tid] = dict(incoming or old_index, id=tid, thread_name=name,
                        updated_at=incoming.get('updated_at') or datetime.fromtimestamp(dst['updated_at'], timezone.utc).isoformat())
                report['names'].append({'id': tid, 'name': name})
            c.execute("UPDATE catalog_db.local_thread_catalog_sync_state SET observation_sequence=?,last_full_reconciled_at=0 WHERE host_id='local'", (seq,))
            c.execute('UPDATE catalog_db.local_thread_catalog_metadata SET catalog_revision=catalog_revision+1 WHERE id=1')
            for db in ('main', 'catalog_db'):
                if c.execute('PRAGMA ' + db + '.foreign_key_check').fetchall():
                    raise h.HandoffError('Project metadata failed a database reference check.')
            merged = merged_global(sg, tg, source_rows, target_rows, source_profile, target_profile)
            report['projects'] = len(merged['local-projects'])
            gate()
            if h.digest(target / GLOBAL) != expected_global or (h.digest(index_path) if index_path.exists() else None) != expected_index:
                raise h.HandoffError(f'{target_profile} settings changed during repair. Quit {target_profile} fully and retry.')
            # Prepare complete files before committing metadata. A retry is safe:
            # all changes merge by ID, never replace the target task collection.
            index_temp = run / 'session_index.jsonl'
            index_temp.write_text(''.join(json.dumps(row, ensure_ascii=False) + '\n' for row in target_index.values()), encoding='utf-8')
            c.commit()
        except BaseException:
            c.rollback()
            raise
    gate()
    if h.digest(target / GLOBAL) != expected_global or (h.digest(index_path) if index_path.exists() else None) != expected_index:
        raise h.HandoffError(f'{target_profile} settings changed. Database metadata is repaired; quit {target_profile} fully and run repair again to finish the sidebar.')
    h.atomic_json(target / GLOBAL, merged)
    h.atomic_json(target / (GLOBAL + '.bak'), merged)
    tmp = index_path.with_name(index_path.name + '.repair-' + uuid.uuid4().hex)
    try:
        shutil.copyfile(index_temp, tmp)
        os.replace(tmp, index_path)
    finally:
        tmp.unlink(missing_ok=True)
    assert load_json(target / GLOBAL)['local-projects'] == merged['local-projects']
    assert index_rows(index_path) == target_index
    report.update(status='completed', finished=h.now(), history_modified=False)
    h.atomic_json(run / 'report.json', report)
    h.atomic_json(RUNS / 'latest-result.json', report)
    return report




