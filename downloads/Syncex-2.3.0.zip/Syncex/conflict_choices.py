"""Review and explicitly choose a task branch, with permanent backups of both."""
from datetime import datetime
import hashlib
import json
from pathlib import Path
import shutil
import sqlite3
import uuid
import handoff as h
import history_chain as chain
import sync_latest as latest
import sync_live as live


def read_pair(root):
    h.checked_id(root)
    indexes = {p: latest.index(p) for p in latest.PROFILES}
    ids = set().union(*(latest.descendants(root, edges) for _, edges in indexes.values()))
    if any(root not in rows or rows[root]['source'] != 'vscode' for rows, _ in indexes.values()):
        raise live.Deferred('The task must exist in both profiles. Run Sync now to copy a missing task.')
    return ids, {p: latest.view(p, ids, *indexes[p]) for p in latest.PROFILES}


def fingerprint(view):
    data = {key: view[key] for key in ('profile', 'rows', 'edges', 'history', 'metadata')}
    data['files'] = {key: {k: f[k] for k in ('relative_path', 'sha256', 'size', 'history_base')}
                     for key, f in view['files'].items()}
    return hashlib.sha256(json.dumps(data, sort_keys=True, ensure_ascii=False).encode()).hexdigest()


def message_preview(view, root):
    """Recent user/assistant text only; never execute or interpret message content."""
    messages = []
    layout = view['layouts'][root]
    # The active segment is sufficient for a recent-message preview; walk its
    # parents only when it contains no visible messages, respecting retry bounds.
    for index, item in enumerate(layout):
        limit = item['size'] if index == 0 else layout[index - 1]['history_base']['end_byte_offset']
        with Path(item['path']).open('rb') as stream:
            while stream.tell() < limit:
                line = stream.readline(limit - stream.tell())
                if not line:
                    break
                record = json.loads(line)
                payload = record.get('payload', {})
                if record.get('type') != 'response_item' or payload.get('type') != 'message' or payload.get('role') not in ('user', 'assistant'):
                    continue
                content = payload.get('content', [])
                text = '\n'.join(part.get('text', '') for part in content if isinstance(part, dict)) if isinstance(content, list) else str(content)
                if not text.strip() or text.lstrip().startswith(('<environment_context>', '<recommended_plugins>', '<send_user_message_question_reply>')):
                    continue
                messages.append({'role': payload['role'], 'text': text.strip()[:1800]})
                messages = messages[-4:]
        if messages:
            break
    return messages


def review(progress=lambda text: None, cancel=None):
    scan = latest.sync(progress, cancel, preview=True)
    candidates = {r['id']: r for r in scan['conflicts']}
    previous = h.ROOT / 'profile-sync' / 'latest-result.json'
    if previous.exists():
        saved = json.loads(previous.read_text(encoding='utf-8'))
        for row in saved.get('remaining', {}).get('conflicts', []):
            candidates.setdefault(row['id'], row)
    entries = []
    for root, previous in candidates.items():
        if cancel is not None and cancel.is_set():
            break
        progress('Reading versions: ' + ' '.join(previous['title'].split())[:70])
        entry = dict(id=root, title=previous['title'], status='conflict', reason=previous.get('reason', ''))
        try:
            _, views = read_pair(root)
            decision, _, reason = latest.choose(*(views[p] for p in latest.PROFILES))
            if decision != 'conflict':
                continue
            entry['reason'] = reason
            entry['versions'] = {p: {'token': fingerprint(v), 'updated_at': v['rows'][root]['updated_at'],
                                     'version': latest.version(v['rows'][root]), 'messages': message_preview(v, root)}
                                 for p, v in views.items()}
        except (h.HandoffError, OSError, sqlite3.Error, ValueError) as exc:
            entry.update(status='blocked', reason=str(exc), versions={})
        entries.append(entry)
    return entries


def pin_snapshot(profile, root, expected, directory):
    info = chain.snapshot_thread(profile, root)
    pinned = directory / (profile + '.zip')
    shutil.copyfile(info['archive'], pinned)
    info = dict(info, archive=str(pinned))
    with h.scratch() as stage:
        manifest = chain.load_package(info, stage)
        latest.Guard(expected, expected, set(expected['rows'])).check_source(manifest)
    h.atomic_json(directory / (profile + '.json'), info)
    return info


class ChoiceGuard(latest.Guard):
    allow_branch_replacement = True

    def __init__(self, source, target, ids, backups):
        super().__init__(source, target, ids)
        self.backups = backups

    def check_source(self, manifest):
        # The override is available only after BOTH captured branches are safely
        # pinned outside the rotating snapshot cache and their checksums pass.
        if set(self.backups) != set(latest.PROFILES):
            raise h.HandoffError('Both branch backups are required before applying a choice.')
        for info in self.backups.values():
            if h.digest(info['archive']) != info['sha256']:
                raise h.HandoffError('A branch backup failed verification. No choice was applied.')
        super().check_source(manifest)


def apply_choices(choices, progress=lambda text: None, cancel=None):
    """Caller holds the shared worker lock. A choice applies only to reviewed data."""
    if not choices:
        raise h.HandoffError('Choose a version for at least one task.')
    if len({r['id'] for r in choices}) != len(choices):
        raise h.HandoffError('A task was selected more than once.')
    for choice in choices:
        h.checked_id(choice['id'])
        if choice['source'] not in latest.PROFILES or set(choice['tokens']) != set(latest.PROFILES):
            raise h.HandoffError('Invalid branch choice. Refresh and choose again.')
    latest.pending_recovery()
    run = h.ROOT / 'conflict-resolutions' / (datetime.now().strftime('%Y%m%d-%H%M%S') + '-' + uuid.uuid4().hex[:8])
    report = {'mode': 'reviewed_conflicts', 'started': h.now(), 'status': 'running', 'imported': [], 'deferred': [], 'backup': str(run)}
    def save():
        h.atomic_json(run / 'report.json', report)
        h.atomic_json(run.parent / 'latest-result.json', report)
    save()
    try:
        for choice in choices:
            if cancel is not None and cancel.is_set():
                report.update(status='cancelled', finished=h.now())
                save()
                return report
            root, source = choice['id'], choice['source']
            target = next(p for p in latest.PROFILES if p != source)
            entry = {key: choice[key] for key in ('id', 'source', 'title')}
            entry['target'] = target
            directory = run / root
            try:
                ids, views = read_pair(root)
                if any(fingerprint(v) != choice['tokens'][p] for p, v in views.items()):
                    raise live.Deferred('A version changed since review. Refresh the list and choose again.')
                if not ids <= views[source]['rows'].keys():
                    raise live.Deferred('The selected version lacks a supporting task present on the other side; this group needs manual review.')
                if latest.choose(*(views[p] for p in latest.PROFILES))[0] != 'conflict':
                    raise live.Deferred('This task is no longer a conflict. Run normal Sync now.')
                progress('Backing up both versions: ' + ' '.join(choice['title'].split())[:65])
                directory.mkdir(parents=True)
                backups = {p: pin_snapshot(p, root, views[p], directory) for p in latest.PROFILES}
                # Snapshotting can take time. Recheck both sides after saving the
                # backups; the importer checks again under receiving-file/DB locks.
                fresh_ids, fresh = read_pair(root)
                if fresh_ids != ids or any(fingerprint(fresh[p]) != choice['tokens'][p] for p in latest.PROFILES):
                    raise live.Deferred('A version changed while backing up. Both backups were kept; refresh and choose again.')
                if cancel is not None and cancel.is_set():
                    report.update(status='cancelled', finished=h.now())
                    save()
                    return report
                h.atomic_json(directory / 'choice.json', dict(entry, reviewed_tokens=choice['tokens'], backups=backups))
                result = live.import_snapshot(backups[source], progress, target,
                    guard=ChoiceGuard(views[source], views[target], ids, backups))
                report['imported'].append(dict(result, **entry, branch_backups=str(directory)))
            except (h.HandoffError, OSError, sqlite3.Error, ValueError) as exc:
                report['deferred'].append(dict(entry, reason=str(exc)))
                save()
                latest.pending_recovery()
            save()
        report.update(status='completed_with_deferred_tasks' if report['deferred'] else 'completed', finished=h.now())
        save()
        return report
    except Exception as exc:
        report.update(status='failed', error=str(exc), finished=h.now())
        save()
        raise


def result_text(report):
    lines = [f"Applied choices: {len(report['imported'])}"]
    for row in report['imported']:
        lines.append(f"{row['title']}: kept {row['source']}, copied into {row['target']}")
    for row in report['deferred']:
        lines.append(f"Not applied — {row['title']}: {row['reason']}")
    if report['status'] == 'cancelled':
        lines.append('Stopped. Completed choices remain saved.')
    lines.append('Both branch backups: ' + report['backup'])
    lines.append('History only. Restart a receiving app if it shows the old branch. Run Sync now with projects/search enabled to refresh project metadata.')
    return '\n'.join(lines)
