"""Per-task, two-way synchronization; never choose a divergent branch by its clock."""
import json
from pathlib import Path
import sqlite3
import handoff as h
import history_chain as chain
import sync_live as live

PROFILES = ('Primary', 'Secondary')
META = tuple(key for key in live.FIELDS if key != 'updated_at')


def index(profile):
    with h.read_db(h.PROFILES[profile] / 'state_5.sqlite') as conn:
        return ({r['id']: dict(r) for r in conn.execute('SELECT * FROM threads')},
                h.table_rows(conn, 'thread_spawn_edges'))


def descendants(root, edges):
    ids = {root}
    while True:
        more = {r['child_thread_id'] for r in edges if r['parent_thread_id'] in ids}
        if more <= ids:
            return ids
        ids |= more


def view(profile, ids, rows, edges):
    home = h.PROFILES[profile]
    selected = {tid: rows[tid] for tid in ids if tid in rows}
    files, layouts = {}, {}
    for tid, row in selected.items():
        layout = chain.layout(home, row)
        if not layout[0]['terminal'] or layout[0]['terminal'][0] not in h.TERMINAL:
            raise live.Deferred(f'{profile}: this task or a supporting agent is still running. Finish or stop its reply and retry.')
        for item in layout:
            if item['thread_id'] in files:
                raise live.Deferred('Tasks share a history storage ID; review before synchronizing.')
            item['sha256'] = h.digest(item['path'])
            stat = Path(item['path']).stat()
            if (stat.st_size, stat.st_mtime_ns) != (item['size'], item['mtime_ns']):
                raise live.Deferred('History changed during comparison. Retry after the reply finishes.')
            files[item['thread_id']] = item
        layouts[tid] = layout
    history = {table: [] for table in h.HISTORY_TABLES}
    if files:
        marks = ','.join('?' for _ in files)
        with h.read_db(home / 'thread_history_1.sqlite') as conn:
            for table in history:
                history[table] = h.table_rows(conn, table, f'thread_id IN ({marks})', list(files))
        chain.validate(list(files.values()), history['thread_history_projection_state'])
    with h.read_db(home / 'sqlite/codex-dev.db') as conn:
        names = {r['thread_id']: r['display_title'] for r in conn.execute("SELECT thread_id,display_title FROM local_thread_catalog WHERE host_id='local'")}
    metadata = {tid: dict(row, name=row.get('name') or names.get(tid) or (row['title'] or 'Untitled task').splitlines()[0])
                for tid, row in selected.items()}
    return {'profile': profile, 'rows': selected, 'files': files, 'layouts': layouts, 'history': history,
            'metadata': metadata,
            'edges': [e for e in edges if e['parent_thread_id'] in ids]}


def contains(new, old):
    """All old bytes must survive, including the part visible through retry links."""
    if not old['rows'].keys() <= new['rows'].keys():
        return False
    for tid, older in old['layouts'].items():
        newer = new['layouts'][tid]
        available = {item['thread_id']: item for item in newer}
        visible = {item['thread_id']: item['size'] if n == 0 else
                   newer[n - 1]['history_base']['end_byte_offset'] for n, item in enumerate(newer)}
        for n, item in enumerate(older):
            incoming = available.get(item['thread_id'])
            limit = item['size'] if n == 0 else older[n - 1]['history_base']['end_byte_offset']
            if not incoming or visible[item['thread_id']] < limit:
                return False
            if incoming['sha256'] != item['sha256'] and h.prefix_relation(Path(item['path']), Path(incoming['path'])) != 'extends':
                return False
    return True


def row_set(rows):
    return {json.dumps(row, sort_keys=True, ensure_ascii=False) for row in rows}


def version(row):
    return (max(row.get('updated_at_ms') or 0, (row.get('updated_at') or 0) * 1000), row.get('updated_at') or 0)


def choose(left, right):
    a, b = contains(left, right), contains(right, left)
    if not a and not b:
        return 'conflict', None, 'Different messages or supporting-agent work exist on both sides. Both copies were preserved.'
    if a != b:
        return 'copy', left if a else right, None
    # Identical transcripts may still have a partially populated history index.
    a = all(row_set(right['history'][t]) <= row_set(left['history'][t]) for t in h.HISTORY_TABLES)
    b = all(row_set(left['history'][t]) <= row_set(right['history'][t]) for t in h.HISTORY_TABLES)
    if not a and not b:
        return 'conflict', None, 'History indexes differ on both sides; both copies were preserved for review.'
    if a != b:
        return 'copy', left if a else right, None
    winners = set()
    for tid, row in left['metadata'].items():
        other = right['metadata'][tid]
        if any(row.get(key) != other.get(key) for key in META) or version(row) != version(other):
            if version(row) == version(other):
                return 'conflict', None, 'Messages match, but task metadata differs with equal update times. Both copies were preserved.'
            winners.add(left['profile'] if version(row) > version(other) else right['profile'])
    if len(winners) > 1:
        return 'conflict', None, 'The task and its supporting agents have newer metadata on opposite sides.'
    if winners:
        return 'copy', left if left['profile'] in winners else right, None
    return 'unchanged', None, None


class Guard:
    """Bind the import to the versions actually compared, under its file/DB locks."""
    allow_branch_replacement = False
    def __init__(self, source, target, ids):
        self.source, self.target, self.ids = source, target, ids
        self.target_files = {str(Path(f['path']).resolve()): f['sha256'] for f in target['files'].values()}

    def check_source(self, manifest):
        rows = {r['id']: r for r in manifest['tables']['threads']}
        if rows.keys() != self.source['rows'].keys():
            raise live.Deferred('Supporting tasks changed during capture; retry sync.')
        for tid, old in self.source['rows'].items():
            # Snapshot capture resolves legacy project assignments into project_id.
            if any(rows[tid].get(k) != v for k, v in old.items() if k != 'project_id'):
                raise live.Deferred('The source task changed after comparison; retry sync.')
        actual = {(f['thread_id'], f['relative_path'], f['sha256']) for f in manifest['files']}
        expected = {(f['thread_id'], f['relative_path'], f['sha256']) for f in self.source['files'].values()}
        if actual != expected or any(live.rows_hash(manifest['tables'][t]) != live.rows_hash(self.source['history'][t]) for t in h.HISTORY_TABLES):
            raise live.Deferred('Source history changed after comparison; retry sync.')
        if live.rows_hash(manifest['tables']['thread_spawn_edges']) != live.rows_hash(self.source['edges']):
            raise live.Deferred('Supporting tasks changed after comparison; retry sync.')
        self.incoming = manifest['tables']

    def check_file(self, path, before_hash, backup, incoming):
        expected = self.target_files.get(str(path.resolve()))
        if expected is not None and before_hash != expected:
            raise live.Deferred('Receiving history changed after comparison; retry sync.')
        if expected is None and before_hash is not None and incoming is not None:
            if h.prefix_relation(backup, incoming) not in ('same', 'extends'):
                raise live.Deferred('A different saved history already occupies the receiving path; it was preserved.')

    def check_target(self, conn, before):
        if {r['id']: r for r in before['threads']} != self.target['rows']:
            raise live.Deferred('The receiving task changed after comparison; retry sync.')
        marks = ','.join('?' for _ in self.ids)
        edges = [dict(r) for r in conn.execute(f'SELECT * FROM thread_spawn_edges WHERE parent_thread_id IN ({marks})', sorted(self.ids))]
        if live.rows_hash(edges) != live.rows_hash(self.target['edges']):
            raise live.Deferred('Receiving supporting tasks changed after comparison; retry sync.')
        for table in h.HISTORY_TABLES:
            expected = self.target['history'][table]
            relevant = [r for r in before[table] if r['thread_id'] in self.target['files']]
            if self.allow_branch_replacement:
                # A reviewed choice can switch to a different retry chain. Hold
                # and verify the old chain too, even if those rows aren't replaced.
                storage = sorted(self.target['files'])
                marks = ','.join('?' for _ in storage)
                relevant = [dict(r) for r in conn.execute(
                    f'SELECT * FROM history_db.{table} WHERE thread_id IN ({marks})', storage)]
            extra = [r for r in before[table] if r['thread_id'] not in self.target['files']]
            if live.rows_hash(relevant) != live.rows_hash(expected) or not row_set(extra) <= row_set(self.incoming[table]):
                raise live.Deferred('Receiving history records changed or contain different saved work; retry sync.')


def pending_recovery():
    for folder in (live.RUNS, h.ROOT / 'one-time-sync', h.DATA / 'transfers'):
        if any(json.loads(p.read_text(encoding='utf-8')).get('status') in ('applying', 'recovery_required') for p in folder.glob('*/journal.json')):
            raise h.HandoffError('Recover the interrupted history import before starting another sync.')


def last_sources():
    """Retain task metadata authority across history-only runs or cancellation."""
    journals = [json.loads(p.read_text(encoding='utf-8')) for p in live.RUNS.glob('*/journal.json')]
    result = {}
    for journal in sorted(journals, key=lambda row: row.get('created', '')):
        if journal.get('status') == 'completed' and journal.get('source') in PROFILES:
            result.update({tid: journal['source'] for tid in journal.get('ids', [journal['thread_id']])})
    return result


def sync(progress=lambda text: None, cancel=None, target_only=None, preview=False, selected_ids=None):
    """Scan the union of roots; refresh each group, then use a guarded import."""
    pending_recovery()
    initial = {p: index(p) for p in PROFILES}
    roots = sorted({r['id'] for rows, _ in initial.values() for r in rows.values() if r['source'] == 'vscode'})
    if selected_ids is not None:
        roots = [tid for tid in roots if tid in selected_ids]
    report = {'mode': 'latest_both_ways', 'started': h.now(), 'imported': [], 'conflicts': [],
              'deferred': [], 'unchanged': 0, 'planned': [], 'safe_ids': [], 'winners': {}}
    for root in roots:
        if cancel is not None and cancel.is_set():
            report['cancelled'] = True
            break
        rows = {p: index(p) for p in PROFILES}
        ids = set().union(*(descendants(root, edges) for _, edges in rows.values()))
        main = next((rs[root] for rs, _ in rows.values() if root in rs), None)
        if main is None:
            continue
        entry = {'id': root, 'ids': sorted(ids), 'title': main.get('name') or main['title']}
        progress('Comparing ' + ' '.join(entry['title'].split())[:75] + '…')
        try:
            views = {p: view(p, ids, *rows[p]) for p in PROFILES}
            if any(not descendants(root, rows[p][1]) <= rows[p][0].keys() for p in PROFILES if root in rows[p][0]):
                raise live.Deferred('A supporting task record is missing; retry after it is saved.')
            decision, source, reason = choose(*(views[p] for p in PROFILES))
            if decision == 'conflict':
                report['conflicts'].append(dict(entry, reason=reason))
                continue
            if decision == 'unchanged':
                report['unchanged'] += 1
                report['safe_ids'].extend(ids)
                continue
            src = source['profile']
            dst = next(p for p in PROFILES if p != src)
            entry.update(source=src, target=dst, title=source['metadata'][root]['name'])
            report['planned'].append(entry)
            if target_only is not None and dst != target_only:
                continue
            if not ids <= source['rows'].keys():
                raise live.Deferred('Supporting tasks differ; neither complete group can replace the other.')
            if preview:
                continue
            info = chain.snapshot_thread(src, root)
            result = live.import_snapshot(info, progress, dst, guard=Guard(source, views[dst], ids))
            report['imported'].append(dict(result, title=entry['title'], source=src, target=dst, ids=sorted(ids)))
            report['safe_ids'].extend(ids)
            report['winners'].update({tid: src for tid in ids})
        except (h.HandoffError, OSError, sqlite3.Error, ValueError) as exc:
            report['deferred'].append(dict(entry, reason=str(exc)))
            pending_recovery()  # Never continue past an uncertain commit.
    report['finished'] = h.now()
    return report
