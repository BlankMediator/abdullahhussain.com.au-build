"""Verify public release bytes without importing or running application code."""
import hashlib
import json
from pathlib import Path, PurePosixPath
import re
import sys
import zipfile


def valid_name(name):
    p = PurePosixPath(name)
    return bool(name) and not p.is_absolute() and p.as_posix() == name and not any(x in ('.', '..') or ':' in x or '\\' in x for x in p.parts)


def check_files(read, hashes):
    if not isinstance(hashes, dict) or not hashes:
        raise ValueError('Missing file manifest')
    for name, digest in hashes.items():
        if not valid_name(name) or not re.fullmatch(r'[0-9a-f]{64}', digest):
            raise ValueError('Invalid manifest entry: ' + name)
        if hashlib.sha256(read(name)).hexdigest() != digest:
            raise ValueError('SHA-256 mismatch: ' + name)
    expected = ''.join(f'{digest}  {name}\n' for name, digest in sorted(hashes.items()))
    if read('SHA256SUMS.txt').decode('ascii') != expected:
        raise ValueError('Text and JSON manifests differ')
    return len(hashes)


def verify(target):
    if target.is_dir():
        def read(name):
            p = target / name
            if not p.resolve().is_relative_to(target.resolve()):
                raise ValueError('Manifest path escapes program folder')
            return p.read_bytes()
        hashes = json.loads(read('SHA256SUMS.json'))
        count = check_files(read, hashes)
    else:
        line = target.with_suffix(target.suffix + '.sha256').read_text(encoding='ascii').strip()
        digest, name = line.split('  ', 1)
        if name != target.name or hashlib.sha256(target.read_bytes()).hexdigest() != digest:
            raise ValueError('Archive checksum mismatch')
        with zipfile.ZipFile(target) as z:
            names = z.namelist()
            if len(names) != len(set(names)) or any(not valid_name(n) for n in names):
                raise ValueError('Unsafe or duplicate archive paths')
            prefix = 'Syncex/'
            hashes = json.loads(z.read(prefix + 'SHA256SUMS.json'))
            expected = {prefix + n for n in hashes} | {prefix + 'SHA256SUMS.json', prefix + 'SHA256SUMS.txt'}
            if set(names) != expected:
                raise ValueError('Unexpected or missing archive files')
            count = check_files(lambda name: z.read(prefix + name), hashes)
    print(f'PASS: SHA-256 verified for {count} files: {target}')


if __name__ == '__main__':
    try:
        verify(Path(sys.argv[1]) if len(sys.argv) > 1 else Path(__file__).resolve().parent)
    except (OSError, ValueError, KeyError, zipfile.BadZipFile) as exc:
        sys.exit('Verification failed: ' + str(exc))
