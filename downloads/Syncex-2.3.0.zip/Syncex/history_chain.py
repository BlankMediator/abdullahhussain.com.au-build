"""Capture paginated retry histories without confusing task IDs with storage IDs.

A retry can keep the visible task ID while creating a new rollout/storage ID.
session_meta.history_base links that rollout to a bounded prefix of its parent.
Keep those links, files and history rows intact; never flatten/replay the log.
"""
from datetime import datetime, timezone
import json
import os
from pathlib import Path
import re
import shutil
import uuid
import zipfile
import handoff as h

SUFFIX = re.compile(r'([0-9a-f]{8}(?:-[0-9a-f]{4}){3}-[0-9a-f]{12})\.jsonl$', re.I)


def checked_path(home, value):
    path = Path(str(value).removeprefix('\\\\?\\')).resolve()
    if not path.is_relative_to(home.resolve()):
        raise h.HandoffError('A transcript points outside its profile.')
    rel = path.relative_to(home.resolve())
    if rel.parts[0] not in ('sessions', 'archived_sessions') or path.suffix != '.jsonl':
        raise h.HandoffError('Unexpected transcript location.')
    return path


def header(path):
    with path.open('rb') as stream:
        try:
            record = json.loads(stream.readline())
        except (ValueError, UnicodeError):
            raise h.HandoffError('Invalid transcript header; no history was copied.')
    return record.get('payload', {}) if record.get('type') == 'session_meta' else {}


def layout(home, row):
    """Return active file first, followed by each ancestor, rejecting ambiguity."""
    owner = row['id']
    path = checked_path(home, row['rollout_path'])
    files, seen = [], set()
    while True:
        meta = header(path)
        match = SUFFIX.search(path.name)
        storage = match[1] if match else owner
        if storage in seen:
            raise h.HandoffError('History links contain a cycle.')
        seen.add(storage)
        if meta.get('id', owner) != owner:
            raise h.HandoffError('This history references another task; automatic import was deferred.')
        stat = path.stat()
        base = meta.get('history_base')
        files.append({'thread_id': storage, 'owner_thread_id': owner, 'active': not files,
                      'relative_path': path.relative_to(home.resolve()).as_posix(), 'path': str(path),
                      'size': stat.st_size, 'mtime_ns': stat.st_mtime_ns,
                      'terminal': h.tail_status(path), 'history_base': base})
        if not base:
            return files
        parent_id = h.checked_id(base['thread_id'])
        candidates = {p.resolve() for folder in ('sessions', 'archived_sessions')
                      for p in (home / folder).rglob('*' + parent_id + '.jsonl')
                      if SUFFIX.search(p.name) and SUFFIX.search(p.name)[1] == parent_id}
        if len(candidates) != 1:
            raise h.HandoffError('A linked history file is missing or ambiguous: ' + parent_id)
        path = checked_path(home, candidates.pop())


def prefix_lines(path, length):
    """Count complete JSONL records in an exact parent prefix, bounded in memory."""
    count, last = 0, b''
    with path.open('rb') as stream:
        remaining = length
        while remaining:
            chunk = stream.read(min(1024 * 1024, remaining))
            if not chunk:
                raise h.HandoffError('A history link extends past its parent file.')
            count += chunk.count(b'\n')
            last = chunk[-1:]
            remaining -= len(chunk)
    if length and last != b'\n':
        raise h.HandoffError('A history link ends inside a transcript record.')
    return count


def validate(files, projections):
    by_id = {item['thread_id']: item for item in files}
    if len(by_id) != len(files):
        raise h.HandoffError('Two tasks share history storage; automatic import was deferred.')
    states = {row['thread_id']: row for row in projections}
    for item in files:
        storage = item['thread_id']
        projection = states.get(storage)
        if projection is None or projection['next_rollout_byte_offset'] != item['size']:
            raise h.HandoffError('Linked history is still being saved or its index disagrees. Retry after the reply finishes.')
        base = item.get('history_base')
        start = base['end_ordinal_exclusive'] if base else 0
        if projection['next_rollout_ordinal'] != start + prefix_lines(Path(item['path']), item['size']):
            raise h.HandoffError('Linked history record counts disagree with its index.')
        if base:
            parent = by_id.get(base['thread_id'])
            if parent is None:
                raise h.HandoffError('A linked parent was not captured.')
            offset = base['end_byte_offset']
            if not isinstance(offset, int) or offset < 0 or offset > parent['size']:
                raise h.HandoffError('Invalid linked history byte offset.')
            parent_start = (parent.get('history_base') or {}).get('end_ordinal_exclusive', 0)
            if start != parent_start + prefix_lines(Path(parent['path']), offset):
                raise h.HandoffError('Linked history boundaries disagree.')


def snapshot_thread(profile, thread_id):
    home = h.PROFILES[profile]
    h.checked_id(thread_id)
    with h.owned_lock(thread_id, profile), h.read_db(home / 'state_5.sqlite') as state:
        all_rows = {r['id']: dict(r) for r in state.execute('SELECT * FROM threads')}
        root = all_rows.get(thread_id)
        if not root or root['source'] != 'vscode':
            raise h.HandoffError('Select an existing main desktop task.')
        edges = h.table_rows(state, 'thread_spawn_edges')
        ids = {thread_id}
        while True:
            more = {r['child_thread_id'] for r in edges if r['parent_thread_id'] in ids}
            if more <= ids:
                break
            ids |= more
        if not ids <= all_rows.keys():
            raise h.HandoffError('A supporting task is missing.')
        threads = [all_rows[tid] for tid in sorted(ids)]
        files = [item for row in threads for item in layout(home, row)]
        if all(not item.get('history_base') and item['thread_id'] == item['owner_thread_id'] for item in files):
            # Legacy capture keys history rows by visible task ID. Merged
            # histories also have a separate storage ID, even without a parent.
            return h._snapshot(profile, thread_id, home, None, False)
        for item in files:
            if item['active'] and (not item['terminal'] or item['terminal'][0] not in h.TERMINAL):
                raise h.HandoffError('The task or one of its agents has not finished yet.')
        tables = {}
        for table in h.STATE_TABLES:
            if table == 'threads':
                tables[table] = threads
            elif table == 'thread_spawn_edges':
                tables[table] = [r for r in edges if r['parent_thread_id'] in ids and r['child_thread_id'] in ids]
            elif table in ('thread_dynamic_tools', 'thread_artifacts'):
                tables[table] = [r for r in h.table_rows(state, table) if r['thread_id'] in ids]
            else:
                tables[table] = h.table_rows(state, table)
        glob_path = home / '.codex-global-state.json'
        glob = json.loads(glob_path.read_text(encoding='utf-8')) if glob_path.exists() else {}
        legacy = glob.get('app-server-project-id-by-legacy-project-id-by-host', {}).get('local:' + str(home), {})
        roots = sorted(tables['project_roots'], key=lambda r: len(r['path']), reverse=True)
        for row in threads:
            if row['project_id'] is None:
                explicit = glob.get('thread-project-assignments', {}).get(row['id'], {}).get('projectId')
                cwd = h.norm(row['cwd'])
                row['project_id'] = legacy.get(explicit, explicit) if explicit else next(
                    (r['project_id'] for r in roots if cwd == h.norm(r['path']) or cwd.startswith(h.norm(r['path']) + '\\')), None)
        projects = {r['project_id'] for r in threads if r['project_id']}
        sections = {r['thread_section_id'] for r in threads if r['thread_section_id']}
        for table in ('projects', 'project_roots', 'project_idempotency_keys', 'thread_sections'):
            key = 'id' if table in ('projects', 'thread_sections') else 'project_id'
            allowed = sections if table == 'thread_sections' else projects
            tables[table] = [r for r in tables[table] if r[key] in allowed]
        schema = {table: h.signature(state, table) for table in h.STATE_TABLES}
        history_ids = sorted({item['thread_id'] for item in files})
        marks = ','.join('?' for _ in history_ids)
        with h.read_db(home / 'thread_history_1.sqlite') as history:
            for table in h.HISTORY_TABLES:
                tables[table] = h.table_rows(history, table, f'thread_id IN ({marks})', history_ids)
                schema[table] = h.signature(history, table)
        validate(files, tables['thread_history_projection_state'])
        manifest = {'version': 2, 'source': profile, 'thread_id': thread_id,
                    'title': root.get('name') or root['title'], 'created': h.now(), 'source_home': str(home),
                    'schema': schema, 'tables': tables, 'files': files, 'history_ids': history_ids}
        dest = h.DATA / 'chain-snapshots' / profile / thread_id
        dest.mkdir(parents=True, exist_ok=True)
        stamp = datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%S') + '-' + uuid.uuid4().hex[:8]
        archive, temp = dest / (stamp + '.zip'), dest / (stamp + '.tmp')
        try:
            with zipfile.ZipFile(temp, 'w', zipfile.ZIP_DEFLATED, compresslevel=3) as z:
                for item in files:
                    src = Path(item['path'])
                    item['sha256'] = h.digest(src)
                    z.write(src, 'rollouts/' + item['relative_path'])
                    stat = src.stat()
                    if (stat.st_size, stat.st_mtime_ns) != (item['size'], item['mtime_ns']):
                        raise h.HandoffError('Linked history changed while capturing; retry after the reply finishes.')
                z.writestr('manifest.json', json.dumps(manifest, ensure_ascii=False))
            # Detect path switches/retries during the capture as well as file writes.
            with h.read_db(home / 'state_5.sqlite') as latest:
                for row in threads:
                    now = latest.execute('SELECT rollout_path,updated_at_ms FROM threads WHERE id=?', (row['id'],)).fetchone()
                    if not now or tuple(now) != (row['rollout_path'], row['updated_at_ms']):
                        raise h.HandoffError('The task changed during capture; retry after the reply finishes.')
            os.replace(temp, archive)
            info = {key: manifest[key] for key in ('source', 'thread_id', 'title', 'created')}
            info.update(archive=str(archive), sha256=h.digest(archive), bytes=archive.stat().st_size)
            h.atomic_json(dest / 'latest.json', info)
            for old in sorted(dest.glob('*.zip'), key=lambda p: p.stat().st_mtime, reverse=True)[2:]:
                if old.resolve().parent != dest.resolve():
                    raise h.HandoffError('Unsafe snapshot cleanup path.')
                old.unlink()
            return info
        finally:
            temp.unlink(missing_ok=True)


def load_package(info, staging):
    archive = Path(info['archive'])
    if h.digest(archive) != info['sha256']:
        raise h.HandoffError('Snapshot checksum failed.')
    with zipfile.ZipFile(archive) as z:
        manifest = json.loads(z.read('manifest.json'))
        if manifest['version'] == 1:
            return h.load_package(info, staging)
        if manifest['version'] != 2 or any(manifest[key] != info[key] for key in ('source', 'thread_id')):
            raise h.HandoffError('Snapshot identity/version mismatch.')
        if set(manifest['tables']) != set(h.STATE_TABLES + h.HISTORY_TABLES):
            raise h.HandoffError('Unexpected snapshot tables.')
        for item in manifest['files']:
            h.checked_id(item['thread_id'])
            h.checked_id(item['owner_thread_id'])
            rel = Path(item['relative_path'])
            if rel.is_absolute() or '..' in rel.parts:
                raise h.HandoffError('Unsafe transcript path in snapshot.')
            out = checked_path(staging, staging / rel)
            out.parent.mkdir(parents=True, exist_ok=True)
            with z.open('rollouts/' + rel.as_posix()) as src, out.open('wb') as dst:
                shutil.copyfileobj(src, dst)
            if out.stat().st_size != item['size'] or h.digest(out) != item['sha256']:
                raise h.HandoffError('Transcript checksum failed.')
            item['path'] = str(out)
        validate(manifest['files'], manifest['tables']['thread_history_projection_state'])
        if set(manifest['history_ids']) != {r['thread_id'] for r in manifest['files']}:
            raise h.HandoffError('Snapshot history identities disagree.')
        return manifest
