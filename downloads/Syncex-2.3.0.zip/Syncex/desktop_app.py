"""Portable launcher: prescan, explicit scope, merge/import preview and setup."""
from datetime import datetime
import json
import os
from pathlib import Path
import queue
import threading
import tkinter as tk
from tkinter import ttk, filedialog, messagebox
import handoff as h
import sync_profiles as combined
import sync_latest as latest
import sync_live as live
import repair_sidebar as sidebar
import conflict_choices as choices
import merge_history as merge
import selection
import profile_config as config
import conflict_policy as policies

VERSION = '2.3.0'


class Workbench:
    def __init__(self, app):
        self.app = app
        app.title('Syncex — ' + VERSION)
        app.geometry('1160x800');app.minsize(960,700)
        self.events=queue.Queue();self.cancel=threading.Event();self.busy=False
        self.catalog={'tasks':[],'projects':[]};self.tasks=set();self.projects=set();self.saved_selection=None
        self.buttons=[]
        f=ttk.Frame(app,padding=18);f.pack(fill='both',expand=True)
        ttk.Label(f,text='Choose what to sync between your Codex profiles',font=('Segoe UI',18,'bold')).pack(anchor='w')
        self.profiles=tk.StringVar(value='');ttk.Label(f,textvariable=self.profiles).pack(anchor='w',pady=6)
        top=ttk.Frame(f);top.pack(fill='x',pady=6)
        self.button(top,'Scan / refresh',self.scan)
        self.button(top,'Automatic setup',self.auto_setup)
        self.button(top,'Manual setup',self.setup)
        self.button(top,'Windows passwords',self.passwords)
        self.button(top,'Documentation',lambda:os.startfile(config.PROGRAM/'README.md'))
        self.search=tk.StringVar();ttk.Label(top,text='Search:').pack(side='left',padx=(18,4))
        ttk.Entry(top,textvariable=self.search).pack(side='left',fill='x',expand=True)
        self.search.trace_add('write',lambda *_:self.render())
        launch_row=ttk.Frame(f);launch_row.pack(fill='x',pady=(2,4))
        self.launch_buttons=[self.button(launch_row,'Configure account in Setup',self.setup) for _ in range(2)]
        ttk.Label(f,text='Open uses the Windows account and paths saved in Setup.').pack(anchor='w')
        panes=ttk.Panedwindow(f,orient='horizontal');panes.pack(fill='both',expand=True,pady=8)
        left=ttk.LabelFrame(panes,text='Projects — click the box to include current tasks',padding=6)
        right=ttk.LabelFrame(panes,text='Tasks — click the box or highlight several rows',padding=6)
        panes.add(left,weight=1);panes.add(right,weight=3)
        self.ptree=ttk.Treeview(left,columns=('include','name'),show='headings',selectmode='browse')
        for key,title,width in [('include','Include',65),('name','Project',220)]:self.ptree.heading(key,text=title);self.ptree.column(key,width=width)
        self.ptree.pack(fill='both',expand=True);self.ptree.bind('<Button-1>',self.toggle_project)
        self.tree=ttk.Treeview(right,columns=('include','title','profiles','updated','policy'),show='headings',selectmode='extended')
        for key,title,width in [('include','Include',60),('title','Task',260),('profiles','Found in',110),('updated','Updated',115),('policy','Conflict policy',140)]:
            self.tree.heading(key,text=title);self.tree.column(key,width=width,minwidth=55)
        scroll=ttk.Scrollbar(right,orient='vertical',command=self.tree.yview);self.tree.configure(yscrollcommand=scroll.set)
        scroll.pack(side='right',fill='y');self.tree.pack(fill='both',expand=True);self.tree.bind('<Button-1>',self.toggle_task)
        select=ttk.Frame(f);select.pack(fill='x')
        self.button(select,'Include highlighted',lambda:self.set_highlighted(True));self.button(select,'Exclude highlighted',lambda:self.set_highlighted(False))
        self.button(select,'Include all scanned',self.select_all);self.button(select,'Clear selection',self.clear)
        self.count=tk.StringVar();ttk.Label(select,textvariable=self.count).pack(side='right')
        self.conflict_settings=policies.defaults()
        policy_row=ttk.Frame(f);policy_row.pack(fill='x',pady=(10,2))
        ttk.Label(policy_row,text='When histories conflict:').pack(side='left',padx=(0,8))
        self.policy=tk.StringVar(value=policies.LABELS['later'])
        self.policy_combo=ttk.Combobox(policy_row,textvariable=self.policy,values=list(policies.LABELS.values()),state='readonly',width=36)
        self.policy_combo.pack(side='left',padx=(0,8));self.policy_combo.bind('<<ComboboxSelected>>',self.set_global_policy)
        self.button(policy_row,'Set policy for highlighted tasks…',self.task_policy)
        self.metadata=tk.BooleanVar(value=True);self.reopen=tk.BooleanVar(value=True)
        ttk.Checkbutton(f,text='Update selected projects and search (quit each receiving app when prompted)',variable=self.metadata).pack(anchor='w',pady=(10,2))
        ttk.Checkbutton(f,text='Reopen receiving apps after the update (Windows may ask for a password)',variable=self.reopen).pack(anchor='w')
        row=ttk.Frame(f);row.pack(fill='x',pady=10)
        self.button(row,'Sync selected both ways',self.sync)
        self.button(row,'Start Live mode…',self.live_mode)
        self.button(row,'Merge / add text or files…',self.edit_task)
        self.button(row,'Choose one branch…',self.choose_branch)
        self.stop=ttk.Button(row,text='Stop',command=self.cancel.set,state='disabled');self.stop.pack(side='left',padx=4)
        self.status=tk.StringVar(value='Scan to find projects and tasks, then choose which to include.')
        ttk.Label(f,textvariable=self.status,wraplength=1100).pack(anchor='w',pady=4)
        self.output=tk.Text(f,height=7,wrap='word',state='disabled');self.output.pack(fill='x')
        bottom=ttk.Frame(f);bottom.pack(fill='x',pady=(8,0))
        self.button(bottom,'Recover interrupted import',self.recover)
        self.button(bottom,'Resume prepared merge…',self.resume)
        self.button(bottom,'Open reports and backups',lambda:os.startfile(h.ROOT))
        app.protocol('WM_DELETE_WINDOW',self.close)
        self.poll_id=app.after(100,self.poll)

    def button(self,parent,text,command):
        b=ttk.Button(parent,text=text,command=command);b.pack(side='left',padx=(0,6));self.buttons.append(b);return b

    def configure_profiles(self):
        self.profiles.set('  ↔  '.join(p['name']+' ('+p['account']+')' for p in config.CURRENT['profiles']))
        for button,profile in zip(self.launch_buttons,config.CURRENT['profiles']):
            button.configure(text='Open as '+profile['account'],
                             command=lambda name=profile['name']:self.launch(name))
        saved=h.ROOT/'selection.local.json'
        self.saved_selection=None
        if saved.exists():
            value=json.loads(saved.read_text(encoding='utf-8'))
            if value.get('profiles')=={p:str(h.PROFILES[p]) for p in latest.PROFILES}:self.saved_selection=value
        self.conflict_settings=policies.load()
        self.policy.set(policies.LABELS[self.conflict_settings['default']])

    def work(self,fn,done):
        if self.busy:return
        self.busy=True;self.cancel.clear();self.stop.configure(state='normal')
        self.policy_combo.configure(state='disabled')
        for b in self.buttons:b.configure(state='disabled')
        def run():
            try:self.events.put(('done',(done,fn(lambda text:self.events.put(('status',text))))))
            except Exception as e:self.events.put(('error',str(e)))
        threading.Thread(target=run,daemon=True).start()

    def poll(self):
        try:
            while True:
                kind,value=self.events.get_nowait()
                if kind=='status':self.status.set(value)
                else:
                    self.busy=False;self.stop.configure(state='disabled')
                    self.policy_combo.configure(state='readonly')
                    for b in self.buttons:b.configure(state='normal')
                    if kind=='error':self.status.set(value);self.show(value)
                    else:
                        done,result=value;done(result)
        except queue.Empty:pass
        self.poll_id=self.app.after(100,self.poll)

    def show(self,text):
        self.output.configure(state='normal');self.output.delete('1.0','end');self.output.insert('1.0',text);self.output.configure(state='disabled')

    def setup(self):
        existing=config.CURRENT
        value=config.wizard(self.app,existing)
        if value:
            config.activate(value);self.configure_profiles();self.catalog={'tasks':[],'projects':[]};self.tasks.clear();self.projects.clear();self.render();self.scan()

    def auto_setup(self):
        import setup_assistant
        value=setup_assistant.wizard(self.app,config.CURRENT)
        if value:
            config.activate(value);self.configure_profiles();self.catalog={'tasks':[],'projects':[]};self.tasks.clear();self.projects.clear();self.render();self.scan()

    def passwords(self):
        import setup_assistant
        setup_assistant.passwords(self.app,config.CURRENT)

    def launch(self,profile):
        self.work(lambda progress:config.launch(profile),
                  lambda result:self.status.set('Opened as '+result['account']+' without administrator privileges.'))

    def scan(self):
        def finished(value):
            if value.get('cancelled'):self.status.set('Scan cancelled. Previous selection kept.');return
            self.catalog=value
            if self.saved_selection is not None:
                self.tasks=set(self.saved_selection.get('tasks',[]));self.projects=set(self.saved_selection.get('projects',[]));self.saved_selection=None
            self.tasks &= {r['id'] for r in value['tasks']};self.projects &= {r['id'] for r in value['projects']}
            self.render();self.status.set('Scan complete. New tasks are excluded until you select them. Highlight one task to merge or add material.')
        self.work(lambda p:selection.scan(p,self.cancel),finished)

    def save_selection(self):
        h.atomic_json(h.ROOT/'selection.local.json',{'profiles':{p:str(h.PROFILES[p]) for p in latest.PROFILES},'tasks':sorted(self.tasks),'projects':sorted(self.projects)})

    def render(self):
        selected=set(self.tree.selection());search=self.search.get().casefold().strip()
        self.tree.delete(*self.tree.get_children());self.ptree.delete(*self.ptree.get_children())
        for p in self.catalog['projects']:
            self.ptree.insert('','end',iid=p['id'],values=('[x]' if p['id'] in self.projects else '[ ]',p['name']))
        for r in self.catalog['tasks']:
            if search and search not in (r['title']+' '+r['id']).casefold():continue
            when=datetime.fromtimestamp(r['updated']/1000).strftime('%d %b %H:%M') if r['updated'] else ''
            rule=policies.effective(self.conflict_settings,r['id'])
            policy_text={'later':'Decide later','latest':'Latest version','combine':'Combine messages'}[rule]
            if r['id'] not in self.conflict_settings['tasks']:policy_text='Default: '+{'later':'Later','latest':'Latest','combine':'Combine'}[rule]
            self.tree.insert('','end',iid=r['id'],values=('[x]' if r['id'] in self.tasks else '[ ]',('Archived: ' if r['archived'] else '')+' '.join(r['title'].split()),', '.join(r['profiles']),when,policy_text))
        self.tree.selection_set([i for i in selected if self.tree.exists(i)])
        self.count.set(f'{len(self.tasks)} tasks · {len(self.projects)} projects selected')

    def toggle_project(self,event):
        if self.busy or self.ptree.identify_column(event.x)!='#1':return
        pid=self.ptree.identify_row(event.y)
        if not pid:return
        members={r['id'] for r in self.catalog['tasks'] if pid in r['projects']}
        if pid in self.projects:self.projects.remove(pid);self.tasks-=members
        else:self.projects.add(pid);self.tasks|=members
        self.save_selection();self.render();return 'break'

    def toggle_task(self,event):
        if self.busy or self.tree.identify_column(event.x)!='#1':return
        tid=self.tree.identify_row(event.y)
        if tid:
            self.tasks.symmetric_difference_update({tid});self.save_selection();self.render()
        return 'break'

    def set_highlighted(self,value):
        if value:self.tasks.update(self.tree.selection())
        else:self.tasks.difference_update(self.tree.selection())
        self.save_selection();self.render()

    def select_all(self):
        self.tasks={r['id'] for r in self.catalog['tasks']};self.projects={r['id'] for r in self.catalog['projects']};self.save_selection();self.render()

    def clear(self):
        self.tasks.clear();self.projects.clear();self.save_selection();self.render()

    def one_task(self):
        rows=self.tree.selection()
        if len(rows)!=1:
            messagebox.showinfo('Select a task','Highlight exactly one task in the list.',parent=self.app);return None
        return rows[0]

    def set_global_policy(self,event=None):
        key=next(k for k,v in policies.LABELS.items() if v==self.policy.get())
        value=dict(self.conflict_settings,default=key)
        try:self.conflict_settings=policies.save(value)
        except Exception as e:
            self.policy.set(policies.LABELS[self.conflict_settings['default']])
            messagebox.showerror('Conflict policy',str(e),parent=self.app);return
        self.render()
        explanation={'later':'Conflicts will keep both copies for later.',
            'latest':'The newest saved conversation will win; both originals are backed up.',
            'combine':'Both histories will combine by message time; applying waits for both apps to close.'}[key]
        self.status.set('Default saved. '+explanation+' Click Sync to apply; task overrides take precedence.')

    def task_policy(self):
        ids=list(self.tree.selection())
        if not ids:
            messagebox.showinfo('Task policy','Highlight one or more tasks first.',parent=self.app);return
        win=tk.Toplevel(self.app);win.title('Conflict policy for selected tasks');win.geometry('680x350');win.grab_set()
        f=ttk.Frame(win,padding=18);f.pack(fill='both',expand=True)
        ttk.Label(f,text=f'Conflict policy for {len(ids)} highlighted task(s)',font=('Segoe UI',14,'bold')).pack(anchor='w')
        inherited='Use global default'
        current={self.conflict_settings['tasks'].get(tid) for tid in ids}
        initial=policies.LABELS[next(iter(current))] if len(current)==1 and None not in current else inherited
        choice=tk.StringVar(value=initial)
        ttk.Combobox(f,textvariable=choice,values=[inherited,*policies.LABELS.values()],state='readonly',width=50).pack(anchor='w',pady=16)
        ttk.Label(f,text='Decide later: keep both copies and list the conflict.\n\n'
            'Use latest version: back up both and use the branch with the latest saved message/activity. Unique work in the other branch stays in its backup.\n\n'
            'Combine messages chronologically: back up and combine both branches automatically. Sync waits for both apps to close before applying.',
            wraplength=630).pack(anchor='w')
        def save():
            value=dict(self.conflict_settings,tasks=dict(self.conflict_settings['tasks']))
            for tid in ids:
                if choice.get()==inherited:value['tasks'].pop(tid,None)
                else:value['tasks'][tid]=next(k for k,v in policies.LABELS.items() if v==choice.get())
            try:self.conflict_settings=policies.save(value)
            except Exception as e:messagebox.showerror('Task policy',str(e),parent=win);return
            win.destroy();self.render();self.status.set('Task policies saved. Click Sync to apply them to included tasks.')
        buttons=ttk.Frame(f);buttons.pack(fill='x',side='bottom')
        ttk.Button(buttons,text='Save policy',command=save).pack(side='right')
        ttk.Button(buttons,text='Cancel',command=win.destroy).pack(side='right',padx=8)

    def sync(self):
        tasks,projects=set(self.tasks),set(self.projects);metadata=self.metadata.get();reopen=self.reopen.get()
        if not tasks and not (metadata and projects):
            messagebox.showinfo('Choose what to sync','Include tasks or projects before syncing.',parent=self.app);return
        self.save_selection()
        settings=policies.validate(self.conflict_settings)
        def run(progress):
            return combined.synchronize_latest(progress,self.cancel,metadata,config.launch if reopen else None,
                selected_ids=tasks,project_ids=projects,conflict_settings=settings)
        self.work(run,lambda result:(self.show(combined.summary(result)),self.status.set('Sync finished. Review the report below.')))

    def choose_branch(self):
        root=self.one_task()
        if root:
            def done(entries):
                entry=next((e for e in entries if e['id']==root),None)
                if not entry or entry['status']!='conflict':
                    self.show('This task is not a ready conflict. Run selected sync, or finish its current reply and scan again.');return
                win=tk.Toplevel(self.app);win.title('Choose a branch');win.geometry('900x620');win.grab_set()
                text=tk.Text(win,wrap='word');text.pack(fill='both',expand=True)
                for p,v in entry['versions'].items():
                    text.insert('end',p+'\n'+'\n\n'.join(m['role']+': '+m['text'] for m in v['messages'])+'\n\n')
                text.configure(state='disabled')
                def apply(p):
                    request={'id':root,'title':entry['title'],'source':p,'tokens':{k:v['token'] for k,v in entry['versions'].items()}}
                    win.destroy()
                    def run(progress):
                        with combined.worker_lock():return choices.apply_choices([request],progress,self.cancel)
                    self.work(run,lambda r:self.show(choices.result_text(r)))
                buttons=ttk.Frame(win);buttons.pack(fill='x',pady=8)
                for p in latest.PROFILES:ttk.Button(buttons,text='Back up both and use '+p,command=lambda p=p:apply(p)).pack(side='left',padx=8)
                ttk.Button(buttons,text='Keep unchanged',command=win.destroy).pack(side='right',padx=8)
            self.work(lambda p:choices.review(p,self.cancel),done)

    def edit_task(self):
        root=self.one_task()
        if root:self.work(lambda progress:merge.preview(root,progress),self.editor)

    def editor(self,review):
        win=tk.Toplevel(self.app);win.title('Preview merge and add material');win.geometry('1000x760');win.grab_set()
        f=ttk.Frame(win,padding=15);f.pack(fill='both',expand=True)
        ttk.Label(f,text=review['title'],font=('Segoe UI',15,'bold'),wraplength=950).pack(anchor='w')
        ttk.Label(f,text='This rewrites this task and its supporting tasks in both profiles. Both apps must quit before applying; they can be reopened afterward.\nOriginal branches are retained. No tools run and no new answer is generated. Added text/files are labelled as imports.',wraplength=950).pack(anchor='w',pady=8)
        preview=tk.Text(f,height=12,wrap='word');preview.pack(fill='both',expand=True)
        for owner in review['tasks']:
            preview.insert('end','Task '+owner['id']+'\n')
            for t in owner['turns']:
                when=datetime.fromtimestamp(t['timestamp']).isoformat(' ',timespec='seconds') if t['timestamp'] is not None else 'Unknown time'
                preview.insert('end',f"{when} · {t['profile']}"+(' · separate variant' if t['variant'] else '')+'\n'+t['excerpt']+'\n\n')
        for warning in review['warnings']:preview.insert('end','REVIEW: '+warning+'\n')
        preview.configure(state='disabled')
        ttk.Label(f,text='Optional text to add as a labelled user context note:').pack(anchor='w',pady=(8,2))
        text=tk.Text(f,height=6,wrap='word');text.pack(fill='x')
        attachments=[];file_status=tk.StringVar(value='No files selected.')
        def add_files():
            for path in filedialog.askopenfilenames(parent=win):
                if path not in attachments:attachments.append(path)
            file_status.set('\n'.join(attachments) or 'No files selected.')
        def add_text_file():
            path=filedialog.askopenfilename(parent=win,filetypes=[('Text files','*.txt *.md *.csv *.json'),('All files','*.*')])
            if path:
                try:text.insert('end',Path(path).read_text(encoding='utf-8-sig'))
                except Exception as e:messagebox.showerror('Read text file',str(e),parent=win)
        buttons=ttk.Frame(f);buttons.pack(fill='x',pady=6)
        ttk.Button(buttons,text='Attach files…',command=add_files).pack(side='left')
        ttk.Button(buttons,text='Read text file…',command=add_text_file).pack(side='left',padx=8)
        ttk.Button(buttons,text='Clear files',command=lambda:(attachments.clear(),file_status.set('No files selected.'))).pack(side='left')
        ttk.Label(f,textvariable=file_status,wraplength=950).pack(anchor='w')
        accepted=tk.BooleanVar(value=False)
        ttk.Checkbutton(f,text='I reviewed the order and any separate variants. Prepare this combined version for both profiles.',variable=accepted).pack(anchor='w',pady=10)
        def prepare():
            if not accepted.get():messagebox.showinfo('Review merge','Review the preview and tick the confirmation above.',parent=win);return
            content=text.get('1.0','end-1c');paths=list(attachments);win.destroy()
            def run(progress):
                with combined.worker_lock():return merge.prepare(review,content,paths,progress)
            self.work(run,self.prepared)
        ttk.Button(f,text='Back up originals and prepare',command=prepare).pack(side='right')
        ttk.Button(f,text='Cancel',command=win.destroy).pack(side='right',padx=8)

    def prepared(self,plan):
        self.show('Prepared: '+plan['title']+'\n'+plan['directory']+'\nBoth original branches and the proposed rewrite are saved. No task history has changed yet.')
        if self.cancel.is_set():
            self.status.set('Preparation finished. The proposal is saved; use Resume prepared merge when ready.')
            return
        if messagebox.askyesno('Apply prepared merge','Apply this prepared version to both profiles?\n\nThe launcher will wait for both apps to quit with Ctrl+Q. Keep this launcher open.\n\n'+plan['title'],parent=self.app):
            self.apply_plan(Path(plan['directory'])/'plan.json')

    def apply_plan(self,path):
        reopen=self.reopen.get()
        def run(progress):
            with combined.worker_lock():
                progress('Quit both receiving apps with Ctrl+Q to apply this history rewrite. Keep this launcher open. Stop leaves the proposal saved.')
                if not sidebar.wait_for_profiles_exit(latest.PROFILES,self.cancel,progress):
                    return {'status':'paused','directory':str(path.parent)}
                result=merge.apply(path,progress,self.cancel)
                if reopen and result['status']=='completed':
                    errors=[]
                    for p in latest.PROFILES:
                        try:config.launch(p)
                        except Exception as e:errors.append(p+': '+str(e))
                    result['reopen_errors']=errors
                return result
        def done(result):
            self.show('History rewrite: '+result['status']+'\nBackups and proposal: '+result['directory']+
                      '\nUse selected sync with projects/search enabled if its listing needs refreshing.'+
                      ('\nReopen manually: '+'; '.join(result['reopen_errors']) if result.get('reopen_errors') else ''))
            self.status.set('Rewrite '+result['status']+'.')
        self.work(run,done)

    def resume(self):
        path=filedialog.askopenfilename(parent=self.app,initialdir=h.ROOT/'rewrites',title='Select the prepared merge plan.json',filetypes=[('Merge plan','plan.json')])
        if path:self.apply_plan(Path(path))

    def recover(self):
        def run(progress):
            with combined.worker_lock():return live.recover_live()
        self.work(run,lambda r:self.show(f'Recovered {len(r)} interrupted imports. If a merge was only partially applied, use Resume prepared merge next.'))

    def live_mode(self):
        if not self.tasks:
            messagebox.showinfo('Live mode','Select at least one task first.',parent=self.app);return
        import live_panel
        # The modal panel holds a fixed scope/configuration for its worker.
        self.live_panel_open=True
        try:live_panel.show(self.app,set(self.tasks),self.catalog['tasks'])
        finally:self.live_panel_open=False

    def close(self):
        if getattr(self,'live_panel_open',False):
            self.status.set('Close the Live mode panel before closing the launcher.');return
        if self.busy:self.cancel.set();self.status.set('Stopping after the current safe operation. Close again when it finishes.');return
        self.app.after_cancel(self.poll_id);self.app.destroy()


def main():
    app=tk.Tk();app.withdraw()
    try:
        try:data=config.load()
        except (ValueError, OSError) as exc:
            messagebox.showwarning('Repair setup',str(exc)+'\nChoose the correct settings in Setup.',parent=app)
            data=None
        if data is None:
            import setup_assistant
            data=setup_assistant.wizard(app)
        if data is None:app.destroy();return
        config.activate(data)
        ui=Workbench(app);ui.configure_profiles();app.deiconify();ui.scan();app.mainloop()
    except Exception as e:
        messagebox.showerror('Syncex',str(e),parent=app);app.destroy()


if __name__=='__main__':main()
