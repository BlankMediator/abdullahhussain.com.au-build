"""Standard-user launches and opt-in Windows Credential Manager credentials.

Passwords stay in native buffers/Credential Manager, never arguments or reports.
An account helper loads the target user's environment before opening the app.
"""
import argparse
import ctypes as c
from ctypes import wintypes as w
import json
import os
from pathlib import Path
import subprocess
import sys
import time
import uuid

PREFIX = 'CodexProfileSync/WindowsAccount/'


class LaunchError(RuntimeError):
    pass


class Credential(c.Structure):
    _fields_ = [('Flags', w.DWORD), ('Type', w.DWORD), ('TargetName', w.LPWSTR),
                ('Comment', w.LPWSTR), ('LastWritten', w.FILETIME),
                ('CredentialBlobSize', w.DWORD), ('CredentialBlob', c.c_void_p),
                ('Persist', w.DWORD), ('AttributeCount', w.DWORD),
                ('Attributes', c.c_void_p), ('TargetAlias', w.LPWSTR), ('UserName', w.LPWSTR)]


class CredUI(c.Structure):
    _fields_ = [('cbSize', w.DWORD), ('hwndParent', w.HWND), ('pszMessageText', w.LPCWSTR),
                ('pszCaptionText', w.LPCWSTR), ('hbmBanner', w.HBITMAP)]


class Startup(c.Structure):
    _fields_ = [('cb', w.DWORD), ('lpReserved', w.LPWSTR), ('lpDesktop', w.LPWSTR),
                ('lpTitle', w.LPWSTR), ('dwX', w.DWORD), ('dwY', w.DWORD),
                ('dwXSize', w.DWORD), ('dwYSize', w.DWORD), ('dwXCountChars', w.DWORD),
                ('dwYCountChars', w.DWORD), ('dwFillAttribute', w.DWORD), ('dwFlags', w.DWORD),
                ('wShowWindow', w.WORD), ('cbReserved2', w.WORD), ('lpReserved2', c.c_void_p),
                ('hStdInput', w.HANDLE), ('hStdOutput', w.HANDLE), ('hStdError', w.HANDLE)]


class ProcessInfo(c.Structure):
    _fields_ = [('hProcess', w.HANDLE), ('hThread', w.HANDLE),
                ('dwProcessId', w.DWORD), ('dwThreadId', w.DWORD)]


class Trustee(c.Structure):
    _fields_=[('multiple',c.c_void_p),('operation',c.c_int),('form',c.c_int),
              ('kind',c.c_int),('name',c.c_void_p)]


class ExplicitAccess(c.Structure):
    _fields_=[('permissions',w.DWORD),('mode',c.c_int),('inheritance',w.DWORD),('trustee',Trustee)]


def native():
    k, a = c.WinDLL('kernel32', use_last_error=True), c.WinDLL('advapi32', use_last_error=True)
    k.GetCurrentProcess.restype = w.HANDLE
    k.CloseHandle.argtypes = [w.HANDLE]
    k.WaitForSingleObject.argtypes = [w.HANDLE, w.DWORD]
    k.GetExitCodeProcess.argtypes = [w.HANDLE, c.POINTER(w.DWORD)]
    k.ResumeThread.argtypes = [w.HANDLE]
    k.ResumeThread.restype = w.DWORD
    k.TerminateProcess.argtypes = [w.HANDLE, w.UINT]
    a.OpenProcessToken.argtypes = [w.HANDLE, w.DWORD, c.POINTER(w.HANDLE)]
    a.GetTokenInformation.argtypes = [w.HANDLE, c.c_int, c.c_void_p, w.DWORD, c.POINTER(w.DWORD)]
    a.LogonUserW.argtypes = [w.LPCWSTR, w.LPCWSTR, w.LPCWSTR, w.DWORD, w.DWORD, c.POINTER(w.HANDLE)]
    a.CredReadW.argtypes = [w.LPCWSTR, w.DWORD, w.DWORD, c.POINTER(c.POINTER(Credential))]
    a.CredWriteW.argtypes = [c.POINTER(Credential), w.DWORD]
    a.CredDeleteW.argtypes = [w.LPCWSTR, w.DWORD, w.DWORD]
    a.CredFree.argtypes = [c.c_void_p]
    a.CreateProcessWithLogonW.argtypes = [w.LPCWSTR, w.LPCWSTR, w.LPCWSTR, w.DWORD,
        w.LPCWSTR, w.LPWSTR, w.DWORD, c.c_void_p, w.LPCWSTR, c.POINTER(Startup), c.POINTER(ProcessInfo)]
    k.CreateProcessW.argtypes = [w.LPCWSTR, w.LPWSTR, c.c_void_p, c.c_void_p, w.BOOL,
        w.DWORD, c.c_void_p, w.LPCWSTR, c.POINTER(Startup), c.POINTER(ProcessInfo)]
    return k, a


def winerror():
    return c.WinError(c.get_last_error())


def elevated(process=None):
    k, a = native()
    token = w.HANDLE()
    if not a.OpenProcessToken(process or k.GetCurrentProcess(), 8, c.byref(token)):
        raise winerror()
    try:
        value, size = w.DWORD(), w.DWORD()
        if not a.GetTokenInformation(token, 20, c.byref(value), c.sizeof(value), c.byref(size)):
            raise winerror()
        return bool(value.value)
    finally:
        k.CloseHandle(token)


def require_standard(process=None):
    if elevated(process):
        raise LaunchError('Administrator privileges detected. The app was not started. '
                          'Open the sync utility normally, or sign in with the intended user’s Windows password.')


def canonical(account):
    import repair_sidebar
    return repair_sidebar.canonical_account(account)


def current_account():
    import repair_sidebar
    return repair_sidebar.process_owner(os.getpid())


class Secret:
    """Mutable, zeroed native password buffer; no Python password string needed."""
    def __init__(self):
        self.buffer = c.create_unicode_buffer(1024)
        self.remember = False

    def clear(self):
        c.memset(c.addressof(self.buffer), 0, c.sizeof(self.buffer))

    def __enter__(self):
        return self

    def __exit__(self, *args):
        self.clear()


def credential_key(account):
    return PREFIX + account.casefold()


def read_credential(account):
    _, a = native()
    value = c.POINTER(Credential)()
    if not a.CredReadW(credential_key(account), 1, 0, c.byref(value)):
        if c.get_last_error() == 1168:
            return None
        raise winerror()
    try:
        record = value.contents
        if (record.UserName or '').casefold() != account.casefold():
            raise LaunchError('Saved Windows credential belongs to a different account. Use Windows passwords to replace it.')
        secret = Secret()
        if record.CredentialBlobSize >= c.sizeof(secret.buffer) or record.CredentialBlobSize % 2:
            secret.clear()
            raise LaunchError('Saved credential has an unsupported format. Replace it in Windows passwords.')
        c.memmove(secret.buffer, record.CredentialBlob, record.CredentialBlobSize)
        return secret
    finally:
        if value.contents.CredentialBlob:
            c.memset(value.contents.CredentialBlob, 0, value.contents.CredentialBlobSize)
        a.CredFree(value)


def has_credential(account):
    value = read_credential(canonical(account))
    if value is None:
        return False
    value.clear()
    return True


def save_credential(account, secret):
    _, a = native()
    length = 0
    while secret.buffer[length] != '\0':
        length += 1
    value = Credential(Type=1, TargetName=credential_key(account),
        Comment='Syncex: Windows sign-in for standard-user launches',
        CredentialBlobSize=length*c.sizeof(c.c_wchar),
        CredentialBlob=c.addressof(secret.buffer), Persist=2, UserName=account)
    if not a.CredWriteW(c.byref(value), 0):
        raise winerror()


def forget_credential(account):
    _, a = native()
    if not a.CredDeleteW(credential_key(canonical(account)), 1, 0) and c.get_last_error() != 1168:
        raise winerror()


def prompt_credential(account, error=0, creating=False):
    ui = c.WinDLL('credui', use_last_error=True)
    ui.CredUIPromptForCredentialsW.argtypes = [c.POINTER(CredUI), w.LPCWSTR, c.c_void_p,
        w.DWORD, w.LPWSTR, w.ULONG, w.LPWSTR, w.ULONG, c.POINTER(w.BOOL), w.DWORD]
    message = ('Choose the Windows password for the NEW standard user '+account+'. '
        'Windows password policy applies. Existing accounts and passwords will not be changed.' if creating else
        'Open as '+account+' without administrator privileges. Use the Windows password, not a PIN. '
        'Save stores it in this Windows user’s Credential Manager for future launches. It does not grant elevation.')
    info = CredUI(cbSize=c.sizeof(CredUI), pszCaptionText='Syncex — Windows password',
        pszMessageText=message)
    name, secret, remember = c.create_unicode_buffer(account, 514), Secret(), w.BOOL(False)
    # Generic, keep account fixed, explicitly manage persistence only after authentication.
    flags = 0x40000 | 0x100000 | 0x80 | 0x2 | (0 if creating else 0x40)
    result = ui.CredUIPromptForCredentialsW(c.byref(info), credential_key(account), None,
        error, name, len(name), secret.buffer, len(secret.buffer), c.byref(remember), flags)
    if result or name.value.casefold() != account.casefold():
        secret.clear()
        if result == 1223:
            raise LaunchError('Windows sign-in cancelled. No app was opened.')
        if result:
            raise c.WinError(result)
        raise LaunchError('Windows sign-in account did not match the selected profile.')
    secret.remember = bool(remember.value)
    return secret


def verify_credential(account, secret):
    k, a = native()
    domain, username = account.split('\\', 1)
    token = w.HANDLE()
    if not a.LogonUserW(username, domain, secret.buffer, 2, 0, c.byref(token)):
        raise winerror()
    k.CloseHandle(token)


def set_credential(account):
    account = canonical(account)
    with prompt_credential(account) as secret:
        verify_credential(account, secret)
        if secret.remember:
            save_credential(account, secret)
            return 'Saved in this Windows user’s Credential Manager.'
        return 'Password verified. Save was not selected; any previously saved password is unchanged.'


def standard_environment(home):
    # This affects this launch only; it does not edit compatibility flags or UAC.
    env = {k:v for k,v in os.environ.items() if k.upper() not in {'__COMPAT_LAYER', 'CODEX_HOME'}}
    env['CODEX_HOME'] = str(home)
    return env


def repair_user_compatibility(app, reports):
    """Remove only this executable's per-user RUNASADMIN flag, with a backup."""
    import winreg
    key_path = r'Software\Microsoft\Windows NT\CurrentVersion\AppCompatFlags\Layers'
    try:
        key = winreg.OpenKey(winreg.HKEY_CURRENT_USER, key_path, 0, winreg.KEY_QUERY_VALUE | winreg.KEY_SET_VALUE)
    except FileNotFoundError:
        return None
    with key:
        try:
            before, kind = winreg.QueryValueEx(key, str(Path(app)))
        except FileNotFoundError:
            return None
        if kind != winreg.REG_SZ or 'RUNASADMIN' not in before.upper().split():
            return None
        after = ' '.join(flag for flag in before.split() if flag.upper() != 'RUNASADMIN')
        record = {'account': current_account(), 'hive': 'HKEY_CURRENT_USER', 'key': key_path,
                  'name': str(Path(app)), 'before': before, 'after': after if after.strip(' ~') else None}
        report = Path(reports) / ('compatibility-' + uuid.uuid4().hex + '.json')
        report.parent.mkdir(parents=True, exist_ok=True)
        report.write_text(json.dumps(record, indent=2), encoding='utf-8')
        if record['after'] is None:
            winreg.DeleteValue(key, str(Path(app)))
        else:
            winreg.SetValueEx(key, str(Path(app)), 0, winreg.REG_SZ, after)
        return str(report)


def visible_app_windows(app):
    """Find visible app windows owned by this account, not another user's UI."""
    import repair_sidebar as sidebar
    import handoff as h
    user = c.WinDLL('user32', use_last_error=True)
    user.IsWindowVisible.argtypes = [w.HWND]
    user.GetWindowThreadProcessId.argtypes = [w.HWND, c.POINTER(w.DWORD)]
    user.GetWindowTextLengthW.argtypes = [w.HWND]
    user.GetClassNameW.argtypes = [w.HWND, w.LPWSTR, c.c_int]
    callback_type = c.WINFUNCTYPE(w.BOOL, w.HWND, w.LPARAM)
    user.EnumWindows.argtypes = [callback_type, w.LPARAM]
    kernel, _ = native()
    kernel.OpenProcess.argtypes = [w.DWORD, w.BOOL, w.DWORD]
    kernel.OpenProcess.restype = w.HANDLE
    kernel.QueryFullProcessImageNameW.argtypes = [w.HANDLE, w.DWORD, w.LPWSTR, c.POINTER(w.DWORD)]
    account = current_account().casefold()
    result = []
    @callback_type
    def window(hwnd, unused):
        try:
            if not user.IsWindowVisible(hwnd) or not user.GetWindowTextLengthW(hwnd):
                return True
            klass = c.create_unicode_buffer(256)
            user.GetClassNameW(hwnd, klass, len(klass))
            if not klass.value.startswith('Chrome_WidgetWin_'):
                return True
            pid = w.DWORD()
            user.GetWindowThreadProcessId(hwnd, c.byref(pid))
            if (sidebar.process_owner(pid.value) or '').casefold() != account:
                return True
            handle = kernel.OpenProcess(0x1000, False, pid.value)
            if not handle:
                return True
            try:
                path, size = c.create_unicode_buffer(32768), w.DWORD(32768)
                if kernel.QueryFullProcessImageNameW(handle, 0, path, c.byref(size)) and Path(path.value).name.casefold() == Path(app).name.casefold():
                    require_standard(handle)
                    result.append({'pid': pid.value, 'hwnd': int(hwnd), 'executable': path.value})
            finally:
                kernel.CloseHandle(handle)
        except (OSError, h.HandoffError, LaunchError):
            pass
        return True
    if not user.EnumWindows(window, 0):
        raise winerror()
    return result


def wait_for_app_window(app, pid, process_handle, timeout=20):
    kernel, _ = native()
    deadline = time.monotonic() + timeout
    first = None
    exit_code = None
    while time.monotonic() < deadline:
        windows = visible_app_windows(app)
        match = next((item for item in windows if item['pid'] == pid), None)
        # Electron may forward a launch to an existing account-local instance.
        if match is None and exit_code == 0:
            match = next(iter(windows), None)
        if match:
            if first is None:
                first = time.monotonic()
            elif time.monotonic() - first >= 1:
                return match
        else:
            first = None
        code = w.DWORD()
        if kernel.GetExitCodeProcess(process_handle, c.byref(code)) and code.value != 259:
            exit_code = code.value
            if exit_code:
                raise LaunchError(f'The app exited before opening a usable window (exit code {exit_code}). See the launch report and app startup logs.')
        time.sleep(.2)
    raise LaunchError('The app did not open a usable window within 20 seconds' +
                      (f' (process exited with code {exit_code})' if exit_code is not None else f' (process {pid} is still running)') +
                      '. It was not reported as opened. Check the app startup logs; no running app was terminated.')


def check_existing_apps(app):
    """Do not hand a launch request to an existing elevated instance."""
    import handoff as h
    import repair_sidebar as sidebar
    previous=getattr(h,'APPS',None)
    try:
        h.APPS={'selected':Path(app)}
        tree=sidebar.app_process_tree()
    finally:
        if previous is None:del h.APPS
        else:h.APPS=previous
    account=current_account().casefold()
    k,_=native()
    k.OpenProcess.argtypes=[w.DWORD,w.BOOL,w.DWORD];k.OpenProcess.restype=w.HANDLE
    for pid,parent in tree.items():
        if parent in tree:continue
        try:owner=sidebar.process_owner(pid)
        except (OSError,h.HandoffError):continue
        if not owner or owner.casefold()!=account:continue
        process=k.OpenProcess(0x1000,False,pid)
        if not process:
            if c.get_last_error()==87:continue
            raise LaunchError('Cannot verify the existing app. Quit this account’s app before reopening it.')
        try:
            if elevated(process):
                raise LaunchError('An app is already running as administrator under '+owner+'. '
                                  'Quit that app with Ctrl+Q, then open it again here without elevation.')
        finally:k.CloseHandle(process)


def start_standard_app(app, home, reports=None, open_url=None):
    require_standard()
    app, home = Path(app), Path(home)
    if not app.is_file():
        raise LaunchError('App executable is missing: '+str(app))
    check_existing_apps(app)
    repair_user_compatibility(app, reports or Path(__file__).parent/'launch-status')
    k, _ = native()
    env = standard_environment(home)
    block = c.create_unicode_buffer('\0'.join(k+'='+v for k,v in sorted(env.items(), key=lambda x:x[0].upper()))+'\0')
    command = c.create_unicode_buffer(subprocess.list2cmdline([str(app)] + ([open_url] if open_url else [])))
    startup, process = Startup(cb=c.sizeof(Startup)), ProcessInfo()
    if not k.CreateProcessW(str(app), command, None, None, False, 0x4 | 0x400 | 0x08000000,
            block, str(app.parent), c.byref(startup), c.byref(process)):
        error = winerror()
        if error.winerror == 740:
            raise LaunchError('Windows still requires elevation for this executable. No UAC fallback was used. '
                              'Use Setup to select a standard-user app installation.') from error
        raise error
    try:
        try:
            require_standard(process.hProcess)
            if k.ResumeThread(process.hThread) == 0xFFFFFFFF:
                raise winerror()
        except BaseException:
            k.TerminateProcess(process.hProcess, 1)
            raise
        window = wait_for_app_window(app, process.dwProcessId, process.hProcess)
        return dict(window, started_pid=process.dwProcessId, ready='visible-window')
    finally:
        k.CloseHandle(process.hThread)
        k.CloseHandle(process.hProcess)


def grant_window_object(handle,sid_text,permissions):
    """Merge a selected user's UI rights; preserve the existing desktop DACL."""
    k,a=native();k.LocalFree.argtypes=[c.c_void_p]
    a.ConvertStringSidToSidW.argtypes=[w.LPCWSTR,c.POINTER(c.c_void_p)]
    a.GetSecurityInfo.argtypes=[w.HANDLE,c.c_int,w.DWORD,c.c_void_p,c.c_void_p,
                               c.POINTER(c.c_void_p),c.c_void_p,c.POINTER(c.c_void_p)]
    a.SetSecurityInfo.argtypes=[w.HANDLE,c.c_int,w.DWORD,c.c_void_p,c.c_void_p,c.c_void_p,c.c_void_p]
    a.SetEntriesInAclW.argtypes=[w.ULONG,c.POINTER(ExplicitAccess),c.c_void_p,c.POINTER(c.c_void_p)]
    a.GetExplicitEntriesFromAclW.argtypes=[c.c_void_p,c.POINTER(w.ULONG),c.POINTER(c.POINTER(ExplicitAccess))]
    a.EqualSid.argtypes=[c.c_void_p,c.c_void_p]
    sid,descriptor,old_acl,new_acl=c.c_void_p(),c.c_void_p(),c.c_void_p(),c.c_void_p()
    entries=c.POINTER(ExplicitAccess)();count=w.ULONG()
    if not a.ConvertStringSidToSidW(sid_text,c.byref(sid)):raise winerror()
    try:
        code=a.GetSecurityInfo(handle,7,4,None,None,c.byref(old_acl),None,c.byref(descriptor))
        if code:raise c.WinError(code)
        if not old_acl:return  # A null DACL already allows access; do not replace it.
        code=a.GetExplicitEntriesFromAclW(old_acl,c.byref(count),c.byref(entries))
        if code:raise c.WinError(code)
        for i in range(count.value):
            entry=entries[i]
            if (entry.mode in (1,2) and entry.trustee.form==0 and a.EqualSid(entry.trustee.name,sid)
                    and (entry.permissions & permissions==permissions or entry.permissions & 0x10000000)):
                return
        access=ExplicitAccess(permissions=permissions,mode=1,inheritance=0,
                              trustee=Trustee(form=0,kind=1,name=sid.value))
        code=a.SetEntriesInAclW(1,c.byref(access),old_acl,c.byref(new_acl))
        if code:raise c.WinError(code)
        code=a.SetSecurityInfo(handle,7,4,None,None,new_acl,None)
        if code:raise c.WinError(code)
    finally:
        for memory in (entries,new_acl,descriptor,sid):
            if memory:k.LocalFree(c.cast(memory,c.c_void_p))


def allow_desktop_access(account):
    from setup_support import account_sid
    u=c.WinDLL('user32',use_last_error=True);k,_=native()
    u.GetProcessWindowStation.restype=w.HANDLE
    u.GetThreadDesktop.argtypes=[w.DWORD];u.GetThreadDesktop.restype=w.HANDLE
    k.GetCurrentThreadId.restype=w.DWORD
    station=u.GetProcessWindowStation();desktop=u.GetThreadDesktop(k.GetCurrentThreadId())
    if not station or not desktop:raise winerror()
    sid=account_sid(account)
    try:
        # UI object rights only: no WRITE_DAC, WRITE_OWNER, machine policy or file grants.
        grant_window_object(station,sid,0x37F)
        grant_window_object(desktop,sid,0x1FF)
    except OSError as exc:
        raise LaunchError('Windows could not grant '+account+' access to this desktop. '
                          'Open the sync utility from the Windows user currently signed into this desktop and retry. '
                          'No app was started. Windows error '+str(exc.winerror)+'.') from exc


def spawn_account_helper(account, secret, command):
    verify_credential(account,secret)
    allow_desktop_access(account)
    k, a = native()
    domain, username = account.split('\\', 1)
    startup, process = Startup(cb=c.sizeof(Startup)), ProcessInfo()
    args = c.create_unicode_buffer(subprocess.list2cmdline(command))
    # NULL environment + LOGON_WITH_PROFILE gives the target user's profile/environment.
    if not a.CreateProcessWithLogonW(username, domain, secret.buffer, 1, command[0], args,
            0x08000000, None, str(Path(command[0]).parent), c.byref(startup), c.byref(process)):
        raise winerror()
    k.CloseHandle(process.hThread)
    k.CloseHandle(process.hProcess)


def probe(profile, folders):
    require_standard()
    result = {'account':current_account(), 'elevated':False, 'windows_home':str(Path.home()),
              'home':profile['home'], 'app_found':Path(profile['app']).is_file(), 'folders':[]}
    for name in folders:
        folder = Path(name)
        item = {'path':str(folder), 'writable':False}
        scratch = folder/('.profile-sync-probe-'+uuid.uuid4().hex)
        try:
            with scratch.open('xb') as f:
                f.write(b'profile-sync-access-check')
            item['writable'] = True
        except OSError as e:
            item['error'] = str(e)
        finally:
            try:
                scratch.unlink(missing_ok=True)
            except OSError:
                item['writable'] = False
                item['error'] = 'Could not remove access-check file: '+str(scratch)
        result['folders'].append(item)
    home = Path(profile['home'])
    result['databases_ready'] = all((home/n).is_file() for n in
        ('state_5.sqlite','thread_history_1.sqlite','sqlite/codex-dev.db'))
    result['database_access'] = True
    for name in ('state_5.sqlite','thread_history_1.sqlite','sqlite/codex-dev.db'):
        path=home/name
        if not path.is_file():continue
        try:
            with path.open('r+b'):pass
        except OSError as exc:
            result['database_access']=False
            result.setdefault('database_errors',[]).append(str(exc))
    result['sign_in_data_present'] = (home/'auth.json').is_file()
    return result


def account_action(profile, shared, mode='launch', folders=(), allow_prompt=True, open_url=None):
    if open_url is not None:
        import handoff
        if not open_url.startswith('codex://threads/'):
            raise LaunchError('Only a selected local task can be opened by the live launcher.')
        handoff.checked_id(open_url.removeprefix('codex://threads/'))
    account = canonical(profile['account'])
    root = Path(shared)/'launch-status'
    root.mkdir(parents=True, exist_ok=True)
    report = root/(uuid.uuid4().hex+'.json')
    if current_account().casefold() == account.casefold() and not elevated():
        if mode == 'probe':
            return probe(profile, folders)
        try:
            result = dict(start_standard_app(profile['app'],profile['home'],reports=root,open_url=open_url), account=account,elevated=False)
        except Exception as exc:
            report.write_text(json.dumps({'ok':False,'account':account,'app':profile['app'],'error':str(exc)}),encoding='utf-8')
            raise LaunchError(str(exc)+'\nLaunch report: '+str(report)) from exc
        report.write_text(json.dumps({'ok':True,'result':result}),encoding='utf-8')
        return result
    python = Path(sys.executable).with_name('pythonw.exe')
    if not python.is_file():
        raise LaunchError('A shared Windows Python installation with pythonw.exe is required.')
    command = [str(python), str(Path(__file__).resolve()), '--child', mode,
        '--account', account, '--app', str(profile['app']), '--home', str(profile['home']), '--report', str(report)]
    for folder in folders:
        command.extend(['--folder',str(folder)])
    if open_url:command.extend(['--open-url',open_url])
    secret = read_credential(account)
    if secret is None:
        if not allow_prompt:
            raise LaunchError('No saved Windows password for '+account+'. Set it in Windows passwords before unattended use.')
        secret = prompt_credential(account)
    with secret:
        try:
            spawn_account_helper(account, secret, command)
        except OSError as exc:
            if getattr(exc,'winerror',None) in (1326,1330,1909):
                raise LaunchError('Windows sign-in failed for '+account+'. Update its saved password in Windows passwords. '
                                  'Windows error '+str(exc.winerror)+'.') from exc
            raise
        if secret.remember:
            save_credential(account,secret)
    deadline = time.monotonic()+60
    while time.monotonic()<deadline:
        if report.exists():
            result=json.loads(report.read_text(encoding='utf-8'))
            if not result.get('ok'):
                raise LaunchError(result.get('error','Account helper failed.')+'\nLaunch report: '+str(report))
            if result['result']['account'].casefold()!=account.casefold() or result['result']['elevated']:
                raise LaunchError('Account helper identity/privilege check failed.')
            return result['result']
        time.sleep(.1)
    raise LaunchError('The account helper did not report back. Use Automatic setup to verify access to the utility, '
                      'Python and shared folder before retrying. Do not assume the app opened.')


def child_main():
    parser=argparse.ArgumentParser()
    parser.add_argument('--child',choices=['launch','probe'],required=True)
    for arg in ('account','app','home','report'):
        parser.add_argument('--'+arg,required=True)
    parser.add_argument('--folder',action='append',default=[])
    parser.add_argument('--open-url')
    args=parser.parse_args()
    try:
        require_standard()
        if current_account().casefold()!=canonical(args.account).casefold():
            raise LaunchError('The helper is running as a different Windows account.')
        profile={'account':args.account,'home':args.home,'app':args.app}
        if args.child=='probe':
            result=probe(profile,args.folder)
        else:
            result=dict(start_standard_app(args.app,args.home,reports=Path(args.report).parent,open_url=args.open_url),account=current_account(),elevated=False)
        value={'ok':True,'result':result}
    except Exception as exc:
        value={'ok':False,'error':str(exc)}
    report=Path(args.report)
    temporary=report.with_suffix('.tmp')
    temporary.write_text(json.dumps(value,ensure_ascii=False),encoding='utf-8')
    os.replace(temporary,report)


if __name__=='__main__':
    child_main()
