"""Manual per-task two-way sync, with the original directional workflow available."""
import contextlib
from datetime import datetime
import os
import queue
import threading
import uuid
import handoff as h
import sync_live as live
import repair_sidebar as sidebar
import sync_latest as latest

RUNS = h.ROOT / 'profile-sync'


@contextlib.contextmanager
def worker_lock():
    import msvcrt
    path = h.ROOT / 'one-time-sync' / 'worker.lock'
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open('a+b') as stream:
        if stream.tell() == 0:
            stream.write(b'0')
            stream.flush()
        stream.seek(0)
        try:
            msvcrt.locking(stream.fileno(), msvcrt.LK_NBLCK, 1)
        except OSError:
            raise h.HandoffError('Another sync launcher is using these profiles. Close it and retry.')
        yield




def synchronize_latest(progress=lambda text: None, cancel=None, metadata=True, reopen=None, selected_ids=None, project_ids=None, conflict_settings=None):
    cancel = cancel or threading.Event()
    run = RUNS / (datetime.now().strftime('%Y%m%d-%H%M%S') + '-' + uuid.uuid4().hex[:8])
    report = {'mode': 'latest_both_ways', 'started': h.now(), 'status': 'running', 'phase': 'history',
              'history_passes': [], 'metadata': {}, 'reopen_errors': [], 'metadata_requested': metadata}
    winners = {}
    def save():
        h.atomic_json(run / 'report.json', report)
        h.atomic_json(RUNS / 'latest-result.json', report)
    def stopped():
        if not cancel.is_set():
            return False
        report.update(status='cancelled', finished=h.now())
        save()
        return True
    def history(target=None):
        result = latest.sync(progress, cancel, target_only=target, selected_ids=selected_ids)
        report['history_passes'].append(result)
        winners.update(result['winners'])
        save()
        return result
    with worker_lock():
        winners.update(latest.last_sources())
        if selected_ids is not None:
            import selection
            scoped_catalog = selection.scan(progress, cancel)
            project_ids = set(project_ids or ()) | {pid for task in scoped_catalog['tasks']
                if task['id'] in selected_ids for pid in task['projects']}
        save()
        try:
            if stopped():
                return report
            progress('Comparing every task on both sides. Completed tasks copy in whichever direction has the newer history.')
            first = history()
            if conflict_settings is not None and first['conflicts'] and not cancel.is_set():
                import conflict_policy
                report['phase'] = 'conflict_resolution'
                report['conflict_resolution'] = conflict_policy.new_report(conflict_settings)
                save()
                resolved = conflict_policy.resolve(first['conflicts'], report['conflict_resolution'], progress, cancel, save)
                winners.update({r['id']: r['source'] for r in resolved['applied'] if r['policy'] == 'latest'})
                if not cancel.is_set() and resolved['applied']:
                    history()
                if not metadata and reopen and resolved['rewrote_histories']:
                    for profile in latest.PROFILES:
                        try: reopen(profile)
                        except Exception as exc: report['reopen_errors'].append(f'{profile}: {exc}')
                    save()
            if stopped():
                return report
            if metadata:
                for target in reversed(latest.PROFILES):
                    source = next(p for p in latest.PROFILES if p != target)
                    report.update(phase='waiting_for_receiver', receiving=target)
                    save()
                    progress(f'Fully quit ONLY {target} with Ctrl+Q. Keep {source} and this launcher open. Projects and search will update after {target} exits.')
                    if not sidebar.wait_for_profiles_exit((target,), cancel, progress):
                        stopped()
                        return report
                    sidebar.require_profile_closed(target)
                    report['phase'] = 'retry_history'
                    final = history(target)
                    if stopped():
                        return report
                    # Only equal/just-imported groups are eligible. A newer task
                    # on the closed side stays authoritative until the next pass.
                    allowed = {tid for tid in final['safe_ids'] if winners.get(tid, latest.PROFILES[0]) == source}
                    report['phase'] = 'projects_and_search'
                    save()
                    progress(f'Updating {target} projects, task names and search…')
                    report['metadata'][target] = sidebar.repair(source_profile=source, target_profile=target, allowed_ids=allowed,
                        project_ids=project_ids if selected_ids is not None else None, scoped=selected_ids is not None)
                    save()
                    if reopen:
                        progress(f'{target} is ready. Reopening it before continuing; Windows may request its password.')
                        try:
                            reopen(target)
                        except Exception as exc:
                            report['reopen_errors'].append(f'{target}: {exc}')
                        save()
            # A final read-only scan reports unresolved tasks across BOTH sides,
            # including work done during the staged restarts. It never overwrites.
            report['remaining'] = latest.sync(progress, cancel, preview=True, selected_ids=selected_ids)
            if stopped():
                return report
            outstanding = any(report['remaining'][k] for k in ('planned', 'conflicts', 'deferred'))
            report.update(status='completed_with_deferred_tasks' if outstanding else 'completed', phase='finished', finished=h.now())
            save()
            return report
        except Exception as exc:
            report.update(status='failed', error=str(exc), finished=h.now())
            save()
            raise


def latest_summary(report):
    lines = ['Latest task histories — both ways']
    imported = {(r['target'], r['id']): r for p in report['history_passes'] for r in p['imported']}
    last_failures = {}
    for result in report['history_passes']:
        for row in result['imported']:
            last_failures.pop((row['id'], row['source'], row['target']), None)
        for row in result['deferred']:
            if row.get('source') and row.get('target'):
                last_failures[(row['id'], row['source'], row['target'])] = row.get('reason')
    for source in latest.PROFILES:
        target = next(p for p in latest.PROFILES if p != source)
        items = [r for r in imported.values() if r['source'] == source]
        lines.append(f'{source} → {target}: {len(items)} task(s) copied')
        for row in items:
            lines.append('  ' + ' '.join(row['title'].split())[:100])
    for profile, result in report['metadata'].items():
        lines.append(f"{profile}: {result['projects']} projects; {len(result['names'])} names/search entries refreshed")
    resolution = report.get('conflict_resolution', {})
    if resolution:
        lines.append(f"Conflict resolutions: {len(resolution['applied'])} applied; {len(resolution['later'])} left for later; {len(resolution['deferred'])} deferred")
    for row in resolution.get('applied', []):
        action = 'used latest version from ' + row['source'] if row['policy'] == 'latest' else 'combined messages chronologically in both profiles'
        lines.append('Resolved: ' + row['title'] + ' — ' + action)
        for warning in row.get('warnings', []): lines.append('  Ordering note: ' + warning)
    for row in resolution.get('deferred', []):
        lines.append('Preset could not resolve: ' + row['title'] + '\n  ' + row['reason'])
    for row in resolution.get('prepared', []):
        if row['status'] != 'completed': lines.append('Saved merge proposal: ' + row['title'] + '\n  ' + row['path'])
    if not report['metadata_requested']:
        lines.append('History-only run. Restart a receiving app if it shows stale messages. Run with projects/search enabled to refresh its project list.')
    if report['status'] == 'cancelled':
        lines.append('Stopped. Completed imports remain saved; run Sync again to finish.')
    final = report.get('remaining') or (report['history_passes'][-1] if report['history_passes'] else {})
    for key, label in (('conflicts', 'Needs review — both copies kept'), ('deferred', 'Not copied'), ('planned', 'Still needs sync')):
        for row in final.get(key, []):
            if key == 'planned' and 'remaining' not in report and (row['target'], row['id']) in imported:
                continue
            deferred_ids = {r['id'] for r in resolution.get('later', [])}
            heading = 'Decide later — both copies kept' if key == 'conflicts' and row['id'] in deferred_ids else label
            lines.append(heading + ': ' + ' '.join(row['title'].split())[:100])
            if row.get('reason'):
                lines.append('  ' + row['reason'])
            elif key == 'planned':
                if row.get('source') and row.get('target'):
                    lines.append('  ' + row['source'] + ' → ' + row['target'])
                failure = last_failures.get((row['id'], row.get('source'), row.get('target')))
                if failure:
                    lines.append('  Last copy attempt: ' + failure)
    lines.extend('Reopen manually: ' + error for error in report['reopen_errors'])
    lines.append('Reports and backups: ' + str(RUNS.parent))
    return '\n'.join(lines)


def summary(report):
    if report.get('mode') == 'latest_both_ways':
        return latest_summary(report)
    lines = [f"{report['source']} → {report['target']}"]
    passes = report['history_passes']
    imported = {row['id']: row for item in passes for row in item['imported']}
    lines.append(f'Updated histories: {len(imported)}')
    for row in imported.values():
        detail = f" ({row['history_files']} linked files)" if row.get('history_files', 1) > 1 else ''
        lines.append('Copied: ' + ' '.join(row['title'].split())[:100] + detail)
    if report.get('metadata'):
        lines.append(f"Project listings: {report['metadata']['projects']}; task names/search entries: {len(report['metadata']['names'])}")
    if report['status'] == 'cancelled':
        lines.append('Stopped. Completed history imports remain saved. Run Sync again to finish projects and search.')
    if passes:
        final = passes[-1]
        lines.append(f"Kept newer receiving tasks: {len(final['preserved_newer_target'])}")
        for row in final['deferred']:
            lines.append('Not copied: ' + ' '.join(row['title'].split())[:100] + '\n  ' + row['reason'])
    lines.append('Reports and backups: ' + str(RUNS.parent))
    return '\n'.join(lines)




if __name__ == '__main__':
    from desktop_app import main
    main()
