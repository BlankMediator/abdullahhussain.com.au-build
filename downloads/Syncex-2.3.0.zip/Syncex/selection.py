"""Read-only catalog scan and explicit project/task scope (no implicit new tasks)."""
import copy
import handoff as h
import sync_latest as latest
import repair_sidebar as sidebar


def project_for(row, glob, home, roots):
    mapping = glob.get('app-server-project-id-by-legacy-project-id-by-host', {}).get('local:' + str(home), {})
    legacy = glob.get('thread-project-assignments', {}).get(row['id'], {}).get('projectId')
    if legacy:
        return mapping.get(legacy, legacy)
    if row.get('project_id'):
        return row['project_id']
    cwd = h.norm(row.get('cwd', ''))
    return next((r['project_id'] for r in sorted(roots, key=lambda r: len(r['path']), reverse=True)
                 if cwd == h.norm(r['path']) or cwd.startswith(h.norm(r['path']) + '\\')), None)


def scope_global(glob, home, projects, tasks, roots):
    result = copy.deepcopy(glob)
    key = 'app-server-project-id-by-legacy-project-id-by-host'
    mapping = glob.get(key, {}).get('local:' + str(home), {})
    ids = set(projects) | {k for k, v in mapping.items() if v in projects}
    result['local-projects'] = {k: v for k, v in glob.get('local-projects', {}).items() if k in ids}
    result[key] = {'local:' + str(home): {k: v for k, v in mapping.items() if v in projects}}
    result['project-order'] = [k for k in glob.get('project-order', []) if k in ids]
    paths = {h.norm(r['path']) for r in roots}
    result['electron-saved-workspace-roots'] = [p for p in glob.get('electron-saved-workspace-roots', []) if h.norm(p) in paths]
    result['electron-workspace-root-labels'] = {p: v for p, v in glob.get('electron-workspace-root-labels', {}).items() if h.norm(p) in paths}
    result['thread-project-assignments'] = {k: v for k, v in glob.get('thread-project-assignments', {}).items() if k in tasks}
    result['project-appearances'] = {k: v for k, v in glob.get('project-appearances', {}).items() if k in ids}
    # Do not import ordering entries for unselected tasks within a selected project.
    result['sidebar-project-thread-orders'] = {
        k: [tid for tid in v if tid in tasks] for k, v in glob.get('sidebar-project-thread-orders', {}).items()
        if k in ids and isinstance(v, list)}
    return result


def scan(progress=lambda text: None, cancel=None):
    tasks, projects = {}, {}
    for profile in latest.PROFILES:
        progress('Reading projects and task names in ' + profile + '…')
        home = h.PROFILES[profile]
        glob = sidebar.load_json(home / sidebar.GLOBAL)
        with h.read_db(home / 'state_5.sqlite') as conn:
            roots = h.table_rows(conn, 'project_roots')
            for row in h.table_rows(conn, 'projects'):
                pid = row['id']
                entry = projects.setdefault(pid, {'id': pid, 'name': row.get('name') or pid, 'profiles': [], 'roots': []})
                entry['profiles'].append(profile)
                entry['roots'] = sorted(set(entry['roots']) | {r['path'] for r in roots if r['project_id'] == pid})
            rows = h.table_rows(conn, 'threads', "source='vscode'")
        with h.read_db(home / 'sqlite/codex-dev.db') as conn:
            names = {r['thread_id']: r['display_title'] for r in conn.execute("SELECT thread_id,display_title FROM local_thread_catalog WHERE host_id='local'")}
        for row in rows:
            if cancel and cancel.is_set():
                return {'tasks': [], 'projects': [], 'cancelled': True}
            pid = project_for(row, glob, home, roots)
            entry = tasks.setdefault(row['id'], {'id': row['id'], 'title': '', 'updated': 0, 'projects': [], 'profiles': [], 'archived': True})
            if latest.version(row)[0] >= entry['updated']:
                entry['title'] = row.get('name') or names.get(row['id']) or row['title'] or 'Untitled task'
                entry['updated'] = latest.version(row)[0]
            entry['profiles'].append(profile)
            entry['archived'] &= bool(row['archived'])
            if pid and pid not in entry['projects']:
                entry['projects'].append(pid)
                projects.setdefault(pid, {'id': pid, 'name': pid, 'profiles': [], 'roots': []})
    return {'tasks': sorted(tasks.values(), key=lambda r: (-r['updated'], r['id'])),
            'projects': sorted(projects.values(), key=lambda r: r['name'].casefold()), 'scanned_at': h.now()}
