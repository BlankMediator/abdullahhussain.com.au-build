"""Launch failures, compatibility repair and live startup sequencing."""
import itertools
import json
from pathlib import Path
import tempfile
from types import SimpleNamespace
import threading
import unittest
from unittest.mock import Mock, patch, MagicMock
import windows_launch as launch
import live_connection as connection

TASK='11111111-1111-4111-8111-111111111111'


class ReadinessTests(unittest.TestCase):
    def fake_kernel(self,exit_code):
        def exit(process,output):output._obj.value=exit_code;return True
        return SimpleNamespace(GetExitCodeProcess=exit)

    def test_process_creation_without_window_is_failure(self):
        with patch.object(launch,'native',return_value=(self.fake_kernel(259),None)), \
             patch.object(launch,'visible_app_windows',return_value=[]), \
             patch.object(launch.time,'monotonic',side_effect=itertools.count()),patch.object(launch.time,'sleep'):
            with self.assertRaisesRegex(launch.LaunchError,'did not open a usable window'):
                launch.wait_for_app_window('ChatGPT.exe',12,11,timeout=3)

    def test_nonzero_startup_exit_reports_code(self):
        with patch.object(launch,'native',return_value=(self.fake_kernel(18),None)), \
             patch.object(launch,'visible_app_windows',return_value=[]),patch.object(launch.time,'sleep'):
            with self.assertRaisesRegex(launch.LaunchError,'exit code 18'):
                launch.wait_for_app_window('ChatGPT.exe',12,11)

    def test_visible_new_window_confirmed(self):
        window={'pid':12,'hwnd':99,'executable':'ChatGPT.exe'}
        with patch.object(launch,'native',return_value=(self.fake_kernel(259),None)), \
             patch.object(launch,'visible_app_windows',return_value=[window]), \
             patch.object(launch.time,'monotonic',side_effect=itertools.count()),patch.object(launch.time,'sleep'):
            self.assertEqual(launch.wait_for_app_window('ChatGPT.exe',12,11),window)

    def test_existing_window_accepted_only_after_clean_handoff(self):
        window={'pid':20,'hwnd':99,'executable':'ChatGPT.exe'}
        with patch.object(launch,'native',return_value=(self.fake_kernel(0),None)), \
             patch.object(launch,'visible_app_windows',return_value=[window]), \
             patch.object(launch.time,'monotonic',side_effect=itertools.count()),patch.object(launch.time,'sleep'):
            self.assertEqual(launch.wait_for_app_window('ChatGPT.exe',12,11),window)

    def test_registry_repair_preserves_other_flags_and_backs_up(self):
        import winreg
        with tempfile.TemporaryDirectory() as folder,patch.object(winreg,'OpenKey',return_value=MagicMock()), \
             patch.object(winreg,'QueryValueEx',return_value=('~ RUNASADMIN HIGHDPIAWARE',winreg.REG_SZ)), \
             patch.object(winreg,'SetValueEx') as write,patch.object(launch,'current_account',return_value=r'PC\User'):
            report=launch.repair_user_compatibility('selected.exe',folder)
            self.assertEqual(write.call_args.args[-1],'~ HIGHDPIAWARE')
            self.assertEqual(json.loads(Path(report).read_text())['before'],'~ RUNASADMIN HIGHDPIAWARE')

    def test_failed_backup_never_changes_registry(self):
        import winreg
        with patch.object(winreg,'OpenKey',return_value=MagicMock()), \
             patch.object(winreg,'QueryValueEx',return_value=('~ RUNASADMIN',winreg.REG_SZ)), \
             patch.object(winreg,'DeleteValue') as delete,patch.object(Path,'mkdir'), \
             patch.object(Path,'write_text',side_effect=OSError('full')), \
             patch.object(launch,'current_account',return_value=r'PC\User'):
            with self.assertRaises(OSError):launch.repair_user_compatibility('selected.exe','unused')
            delete.assert_not_called()


class ConnectionTests(unittest.TestCase):
    def setUp(self):
        self.stack=__import__('contextlib').ExitStack();self.addCleanup(self.stack.close)
        for obj,name,value in [(connection.h,'APPS',{'Left':Path('left.exe'),'Right':Path('right.exe')}),
                               (connection.h,'ACCOUNTS',{'Left':r'PC\Left','Right':r'PC\Right'}),
                               (connection.sync_latest,'PROFILES',('Left','Right'))]:
            self.stack.enter_context(patch.object(obj,name,value,create=True))
        self.stack.enter_context(patch.object(connection.live_bridge,'check_bundle'))
        self.wait=self.stack.enter_context(patch.object(connection.repair_sidebar,'wait_for_profiles_exit',return_value=True))
        self.stack.enter_context(patch.object(connection.repair_sidebar,'require_profile_closed'))
        self.engine=Mock();self.engine.tick.return_value={'tasks':[{'id':TASK,'state':'synced'}],'errors':[]}
        self.stack.enter_context(patch.object(connection.live_mode,'Engine',return_value=self.engine))
        self.server=Mock();self.server.discover_owner.return_value='owner-client'
        self.server.start.return_value=self.server
        self.factory=self.stack.enter_context(patch.object(connection.live_bridge,'PipeServer',return_value=self.server))
        self.launch=self.stack.enter_context(patch.object(connection.profile_config,'launch'))
        self.cancel=threading.Event()

    def run_connection(self):return connection.connect({TASK},'Left',self.cancel,lambda text:None,lambda report:None)

    def test_owner_verified_before_follower_launch_and_always_cleanup(self):
        order=[]
        self.launch.side_effect=lambda p,**kw:order.append(p)
        self.server.discover_owner.side_effect=lambda *a,**kw:order.append('verified') or 'owner-client'
        self.run_connection()
        self.assertEqual(order,['Left','verified','Right'])
        self.assertEqual(self.launch.call_args.kwargs['open_url'],'codex://threads/'+TASK)
        self.server.close.assert_called_once()

    def test_quit_wait_cancelled_does_not_start_relay_or_app(self):
        self.wait.return_value=False
        self.assertEqual(self.run_connection()['status'],'cancelled')
        self.factory.assert_not_called();self.launch.assert_not_called()

    def test_history_conflict_stops_before_relay_or_launch(self):
        self.engine.tick.return_value={'tasks':[{'id':TASK,'title':'Task','state':'conflict','detail':'Branches differ'}],'errors':[]}
        self.assertEqual(self.run_connection()['status'],'needs_review')
        self.factory.assert_not_called();self.launch.assert_not_called()

    def test_failed_first_launch_never_opens_follower(self):
        self.launch.side_effect=launch.LaunchError('no window')
        with self.assertRaises(launch.LaunchError):self.run_connection()
        self.assertEqual(self.launch.call_count,1);self.server.close.assert_called_once()

    def test_unconfirmed_owner_never_opens_follower(self):
        self.server.discover_owner.return_value=None
        with patch.object(connection.time,'monotonic',side_effect=itertools.count(0,10)),patch.object(self.cancel,'wait',return_value=False):
            with self.assertRaisesRegex(connection.live_bridge.BridgeError,'ownership'):
                self.run_connection()
        self.assertEqual(self.launch.call_count,1);self.server.close.assert_called_once()


if __name__=='__main__':unittest.main(verbosity=2)
